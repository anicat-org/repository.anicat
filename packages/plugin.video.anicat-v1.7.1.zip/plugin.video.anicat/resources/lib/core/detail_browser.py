# -*- coding: utf-8 -*-
"""Lazy Drive hierarchy for the two-column series detail (UI independent)."""
from resources.lib.core.name_parser import parse_folder_name, natural_sort_key
from resources.lib.core.content_resolver import get_episodes_from_folder


class DetailBrowser:
    def __init__(self, folder_id, title, loader):
        self.loader = loader
        self.cache = {}
        self.stack = []
        self.positions = {}
        self.folder_id, self.title = folder_id, title
        self.options, self.episodes = [], []
        self.selected = 0
        self._open(folder_id, title)

    def _contents(self, folder_id):
        if folder_id not in self.cache:
            self.cache[folder_id] = self.loader(folder_id)
        return self.cache[folder_id]

    def _open(self, folder_id, title):
        self.folder_id, self.title = folder_id, title
        contents = self._contents(folder_id)
        options = []
        if self.stack:
            options.append({'label': '← ' + self.stack[-1][1], 'parent': True})
        if contents.get('files'):
            options.append({'label': 'Episodis', 'id': folder_id, 'direct': True})
        for folder in sorted(contents.get('folders', []), key=lambda f: natural_sort_key(f['name'])):
            options.append({'label': folder['name'], 'id': folder['id'],
                            'season': parse_folder_name(folder['name']).get('season_num', 0)})
        self.options = options
        self.selected = min(self.positions.get(folder_id, int(bool(self.stack))), max(0, len(options) - 1))
        self.episodes = []
        if options:
            self._preview(self.selected)

    def _preview(self, index):
        option = self.options[index]
        if option.get('parent'):
            self.episodes = []
            return
        contents = self._contents(option['id'])
        self.episodes = get_episodes_from_folder(contents)
        for episode in self.episodes:
            if not episode.get('season_number'):
                ancestors = [self.title] + [title for _, title in reversed(self.stack)]
                episode['season_number'] = option.get('season') or next(
                    (parse_folder_name(title)['season_num'] for title in ancestors
                     if parse_folder_name(title)['season_num']), 0)
        self.has_children = bool(contents.get('folders')) and not option.get('direct')

    def select(self, index):
        if not 0 <= index < len(self.options):
            return
        self.selected = index
        self.positions[self.folder_id] = index
        option = self.options[index]
        if option.get('parent'):
            folder_id, title = self.stack.pop()
            self._open(folder_id, title)
        elif not option.get('direct') and self._contents(option['id']).get('folders'):
            self.stack.append((self.folder_id, self.title))
            self._open(option['id'], option['label'])
        else:
            self._preview(index)

    def preview(self, index):
        if 0 <= index < len(self.options):
            self.selected = index
            self.positions[self.folder_id] = index
            self._preview(index)

    def snapshot(self):
        return {'options': self.options, 'selected': self.selected,
                'episodes': self.episodes, 'path': self.title}
