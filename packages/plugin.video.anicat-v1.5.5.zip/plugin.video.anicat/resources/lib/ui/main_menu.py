# -*- coding: utf-8 -*-
"""Menú principal de AniCat."""

import xbmcaddon
import xbmcgui
from resources.lib.ui.helpers import (
    get_handle, add_directory_item, end_directory, notify_error
)

addon = xbmcaddon.Addon()


def show(args):
    handle = get_handle()
    movies_folder_id = addon.getSetting('movies_folder_id')
    series_folder_id = addon.getSetting('series_folder_id')
    is_configured = bool(movies_folder_id and series_folder_id)

    if not is_configured:
        add_directory_item(
            handle,
            addon.getLocalizedString(30018),
            {'mode': 'setup_drive'},
            is_folder=False,
        )
    else:
        add_directory_item(
            handle,
            addon.getLocalizedString(30001),  # Seguir viendo
            {'mode': 'continue_watching'},
            is_folder=True,
        )
        add_directory_item(
            handle,
            addon.getLocalizedString(30020),  # Ver más tarde
            {'mode': 'watch_later'},
            is_folder=True,
        )
        add_directory_item(
            handle,
            addon.getLocalizedString(30002),  # Películas
            {'mode': 'movies'},
            is_folder=True,
        )
        add_directory_item(
            handle,
            addon.getLocalizedString(30003),  # Series
            {'mode': 'series'},
            is_folder=True,
        )

    add_directory_item(
        handle,
        addon.getLocalizedString(30015),  # Configuración de Drive
        {'mode': 'drive_config'},
        is_folder=True,
    )

    end_directory(handle)
