# -*- coding: utf-8 -*-
import xbmcgui
import traceback

from resources.lib.ui.windows.context_menu import toggle_watchlist, watchlist_option, icon_path

WINDOW_XML = 'anicat_detail.xml'


class DetailWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self.source = kwargs.pop('source')
        self.view = kwargs.pop('view')
        self.episodes = kwargs.pop('episodes')
        self._select_section = kwargs.pop('select_section')
        self._changing_section = False
        self.result = None
        super(DetailWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        self.setProperty('DetailTitle', self.source.get('display_title') or self.source['name'])
        self.setProperty('DetailOverview', self.source.get('meta', ''))
        self.setProperty('SelectedFanart', self.source.get('fanart', ''))
        self.setProperty('DetailPath', self.view['path'])
        self._update_watchlist_button()
        self._populate_sections()
        self._populate_episodes()
        self.setFocusId(50 if self.view['options'] else 8)

    def _populate_sections(self):
        sections = self.getControl(50)
        sections.reset()
        sections.addItems([xbmcgui.ListItem(option['label']) for option in self.view['options']])
        if self.view['options']:
            sections.selectItem(self.view['selected'])

    def _update_watchlist_button(self):
        option = watchlist_option(self.source['id'])
        self.getControl(8).setLabel(option['label'])
        self.setProperty('WatchlistIcon', icon_path(option['icon']))

    def _populate_episodes(self):
        episodes = self.getControl(100)
        episodes.reset()
        for data in self.episodes:
            number = data.get('episode_number', 0)
            label = ('%02d · ' % number if number else '') + data['name']
            item = xbmcgui.ListItem(label)
            from resources.lib.ui.windows.card_art import set_card_art
            set_card_art(item, data.get('thumb') or self.source.get('thumb', ''))
            resume, total = data.get('resume_time') or 0, data.get('total_time') or 0
            completed = bool(data.get('completed'))
            percent = 100 if completed else max(0, min(100, int(resume / total * 100))) if total > 0 else 0
            item.getVideoInfoTag().setResumePoint(float(percent), 100.0)
            item.setProperty('Progress', str(percent))
            item.setProperty('PercentPlayed', str(percent))
            item.setProperty('Subtitle', 'Completat' if completed else
                             '%d%% reproduït' % percent if resume > 0 else
                             'Següent episodi · Per començar' if data.get('queued') else 'No vist')
            episodes.addItem(item)
        self.setProperty('EmptyEpisodes', '' if self.episodes else 'true')

    def _change_section(self, index, enter):
        if self._changing_section:
            return
        self._changing_section = True
        self.setProperty('DetailLoading', 'true')
        try:
            view, episodes = self._select_section(index, enter)
            changed = view['options'] != self.view['options']
            self.view, self.episodes = view, episodes
            self.setProperty('DetailPath', view['path'])
            if changed:
                self._populate_sections()
            self._populate_episodes()
        except Exception:
            import xbmc
            xbmc.log('[AniCat] Error loading detail section %s:\n%s' % (index, traceback.format_exc()), xbmc.LOGERROR)
            xbmcgui.Dialog().notification('AniCat', 'No s’ha pogut carregar aquesta carpeta. Torna-ho a provar.')
        finally:
            self.clearProperty('DetailLoading')
            self._changing_section = False

    def onClick(self, control_id):
        if control_id == 9:
            self.close()
        elif control_id == 8:
            if toggle_watchlist(self.source):
                self._update_watchlist_button()
            else:
                xbmcgui.Dialog().notification('AniCat', 'No s’ha pogut actualitzar la llista')
        elif control_id == 50:
            self._change_section(self.getControl(50).getSelectedPosition(), True)
        elif control_id == 100 and self.episodes:
            self.result = {'action': 'play', 'index': self.getControl(100).getSelectedPosition(),
                           'episodes': self.episodes}
            self.close()

    def onAction(self, action):
        if action.getId() in (10, 92, 13):
            self.close()
        elif self.getFocusId() == 50 and action.getId() in (3, 4, 5, 6, 104, 105, 107):
            selected = self.getControl(50).getSelectedPosition()
            if selected != self.view['selected']:
                self._change_section(selected, False)
