#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
Servei de AniCat per a Kodi.
Manté el AniCatPlayer viu en background perquè els callbacks de reproducció funcionin.
El plugin (addon.py) comunica el file_id via propietats de la finestra de Kodi.
"""

import sys
import os
import xbmc
import xbmcaddon

_addon_dir = os.path.dirname(os.path.abspath(__file__))
if _addon_dir not in sys.path:
    sys.path.insert(0, _addon_dir)

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')

_MAINTENANCE_INTERVAL = 300  # 5 minuts


def run_service():
    xbmc.log(f'[{addon_name} Service] Iniciant servei...', xbmc.LOGINFO)

    # Inicialitzar la BD
    try:
        from resources.lib.core.progress import init_database
        init_database()
        xbmc.log(f'[{addon_name} Service] Base de dades inicialitzada', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[{addon_name} Service] Error inicialitzant BD: {e}', xbmc.LOGERROR)

    # Instanciar el player AÇÍ — en el service — perquè visqui tot el temps
    try:
        from resources.lib.core.player import anicat_player
        player = anicat_player
        xbmc.log(f'[{addon_name} Service] AniCatPlayer creat i actiu', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[{addon_name} Service] Error creant AniCatPlayer: {e}', xbmc.LOGERROR)
        player = None

    monitor = xbmc.Monitor()
    xbmc.log(f'[{addon_name} Service] Servei en execució', xbmc.LOGINFO)

    tick = 0
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
        tick += 1
        # Manteniment cada 5 minuts (300s / 10s = 30 ticks)
        if tick % 30 == 0:
            _perform_maintenance()

    xbmc.log(f'[{addon_name} Service] Servei aturat', xbmc.LOGINFO)
    del player


def _perform_maintenance():
    try:
        from resources.lib.core.progress import cleanup_old_records
        cleanup_old_records(days=30)
    except Exception as e:
        xbmc.log(f'[{addon_name} Service] Error en manteniment: {e}', xbmc.LOGERROR)


run_service()
