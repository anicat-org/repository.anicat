"""Addon-owned progress dialog used by the Drive assistants."""
import os
import xbmcaddon
import xbmcgui
import xbmcvfs


class SetupProgress(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.heading = ''
        self.message = ''
        self.canceled = False
        super().__init__(*args, **kwargs)

    def create(self, heading, message):
        self.heading, self.message = heading, message
        self.canceled = False
        # show() is non-modal: Kodi can paint before Python's onInit callback runs.
        state = xbmcgui.Window(10000)
        state.setProperty('AniCat.SetupHeading', heading)
        state.setProperty('AniCat.SetupMessage', message.replace('\n', '[CR]'))
        self.show()

    def onInit(self):
        self.setFocusId(9009)

    def close(self):
        try:
            super().close()
        finally:
            state = xbmcgui.Window(10000)
            state.clearProperty('AniCat.SetupHeading')
            state.clearProperty('AniCat.SetupMessage')

    def iscanceled(self):
        return self.canceled

    def onAction(self, action):
        if action.getId() in (10, 92, 13):
            self.canceled = True
            self.close()

    def onClick(self, control_id):
        if control_id == 9009:
            self.canceled = True
            self.close()


def progress_dialog():
    path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    return SetupProgress('anicat_setup_progress.xml', os.path.abspath(path), 'Default', '720p')
