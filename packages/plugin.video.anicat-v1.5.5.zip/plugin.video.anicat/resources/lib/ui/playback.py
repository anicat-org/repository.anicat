# -*- coding: utf-8 -*-
"""Lógica de reproducción de vídeo."""

import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.core import progress
from resources.lib.core.gdrive import build_play_url

addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])



def play_video(args):
    """
    Inicia la reproducció d'un arxiu de Google Drive.
    Escriu les metadades a pending_playback (BD) perquè el service (AniCatPlayer)
    les pugui llegir a onPlayBackStarted.
    """
    file_id        = args.get('file_id', [None])[0]
    drive_id       = args.get('drive_id', [None])[0]
    content_type   = args.get('content_type', ['movie'])[0]
    folder_id      = args.get('folder_id', [None])[0]
    episode_number = int(args.get('episode_number', [0])[0] or 0)
    season_number  = int(args.get('season_number', [0])[0] or 0)

    xbmc.log(f'[AniCat] play_video: file_id={file_id}, drive_id={drive_id}, type={content_type}', xbmc.LOGINFO)

    if not file_id:
        xbmcgui.Dialog().notification(addon.getAddonInfo('name'), 'ID de fitxer no proporcionat', xbmcgui.NOTIFICATION_ERROR)
        return

    if not drive_id:
        drive_id = addon.getSetting('series_drive_id') if content_type in ('episode', 'series', 'episodes') else addon.getSetting('movies_drive_id')

    if not drive_id:
        xbmcgui.Dialog().notification(addon.getAddonInfo('name'), 'Drive no configurat', xbmcgui.NOTIFICATION_ERROR)
        return

    file_type   = 'episode' if content_type in ('episode', 'series', 'episodes') else 'movie'
    series_id    = folder_id or ''
    folder_name  = args.get('folder_name', [None])[0] or ''
    episode_title = args.get('episode_title', [None])[0] or ''

    # Buscar metadades a la BD (TMDB cache) — només per a sèries
    thumbnail, fanart = '', ''
    series_title = ''
    if file_type == 'episode' and series_id:
        mapping = progress.get_series_map(series_id)
        if mapping:
            series_title = mapping.get('title', '')
            thumbnail    = mapping.get('thumb_url', '')
            fanart       = mapping.get('fanart_url', '')

    # Construir el títol final
    if file_type == 'movie':
        # Per pel·lícules: sempre el nom del fitxer (folder_name conté f['name'])
        title = folder_name or 'Vídeo'
        from resources.lib.core.tmdb_client import resolve_metadata, cached_metadata
        metadata = cached_metadata(file_id, 'movie') or resolve_metadata(file_id, drive_id, folder_name, 'movie') or {}
        title = metadata.get('title') or title
        thumbnail = metadata.get('thumb_url', '')
        fanart = metadata.get('fanart_url', '')
    elif file_type == 'episode':
        # Per sèries: usar el nom real evita títols Ep. 0 quan el parser no troba número
        base = series_title or folder_name
        title = episode_title or (
            f'{base} — Ep. {episode_number}' if base else f'Ep. {episode_number}'
        )
    else:
        title = folder_name or 'Vídeo'

    # Escriure a la BD perquè el service (AniCatPlayer) ho llegeixi a onPlayBackStarted
    resume_time = progress.get_resume_time(file_id)

    # Escriure a la BD perquè el service (AniCatPlayer) ho llegeixi a onPlayBackStarted.
    # resume_time s'inclou aquí — el player farà el seek silenciós sense diàleg de Kodi.
    progress.write_pending_playback(
        file_id=file_id,
        title=title,
        thumbnail=thumbnail,
        fanart=fanart,
        file_type=file_type,
        series_id=series_id,
        season_id='',
        episode_number=episode_number,
        resume_time=resume_time,
    )

    play_url = build_play_url(file_id, drive_id)
    xbmc.log(f'[AniCat] play_url: {play_url}, resume={resume_time:.0f}s', xbmc.LOGINFO)

    li = xbmcgui.ListItem(path=play_url)
    li.setProperty('IsPlayable', 'true')
    info = {'title': title, 'mediatype': file_type}
    if file_type == 'episode':
        info.update({
            'tvshowtitle': series_title or folder_name,
            'episode': episode_number,
            'season': season_number,
        })
    li.setInfo('video', info)
    if thumbnail:
        li.setArt({'thumb': thumbnail, 'poster': thumbnail})
    if fanart:
        li.setArt({'fanart': fanart})
    # NO posem ResumeTime a la ListItem — evitem el diàleg de Kodi.
    # El seek el fa el player del service directament.

    direct_playback = args.get('direct_playback', ['false'])[0] == 'true'
    if direct_playback:
        progress.clear_active_episode_playlist()
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
        xbmc.Player().play(play_url, li)
    else:
        xbmcplugin.setResolvedUrl(_handle, True, listitem=li)
    xbmc.log(f'[AniCat] Reproducció iniciada: {file_id}', xbmc.LOGINFO)


def play_episode_playlist(episodes, start_index=0):
    if not episodes:
        return False

    active_episodes = []
    for episode in episodes:
        data = dict(episode)
        data['resume_time'] = progress.get_resume_time(data.get('id', ''))
        active_episodes.append(data)

    series_id = active_episodes[0].get('series_id', '')
    progress.save_episode_playlist(series_id, active_episodes)
    progress.save_active_episode_playlist(active_episodes)

    playlist_urls = []
    m3u_lines = ['#EXTM3U']
    for episode in active_episodes:
        url = build_play_url(
            episode.get('id', ''),
            episode.get('drive_id', ''),
        )
        title = (episode.get('name', '') or 'Episodi').replace('\r', ' ').replace('\n', ' ')
        playlist_urls.append(url)
        m3u_lines.extend((f'#EXTINF:-1,{title}', url))

    profile_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    playlist_path = os.path.join(profile_path, 'episode_playlist.m3u8')
    with open(playlist_path, 'w', encoding='utf-8', newline='\n') as playlist_file:
        playlist_file.write('\n'.join(m3u_lines) + '\n')

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    if not playlist.load(playlist_path):
        for url in playlist_urls:
            playlist.add(url)

    start_index = max(0, min(int(start_index), len(episodes) - 1))
    xbmc.Player().play(playlist, startpos=start_index)
    xbmc.log(
        '[AniCat] Playlist de episodios iniciada: %d elementos, posición %d' % (
            len(episodes),
            start_index,
        ),
        xbmc.LOGINFO,
    )
    return True


def mark_watched(args):
    file_id = args.get('file_id', [None])[0]
    if file_id:
        progress.mark_as_watched(file_id)
        xbmc.executebuiltin('Container.Refresh')


def mark_unwatched(args):
    file_id = args.get('file_id', [None])[0]
    if file_id:
        progress.mark_as_unwatched(file_id)
        xbmc.executebuiltin('Container.Refresh')
