# -*- coding: utf-8 -*-
# Default entry point for Kodi
# This file ensures compatibility with Kodi's addon structure requirements

import addon
