# -*- coding: utf-8 -*-

import xbmcgui


WINDOW_XML = 'anicat_loading.xml'


class LoadingWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self._message = kwargs.pop('message', 'Carregant...')
        self.cancelled = False
        super(LoadingWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        self.getControl(10).setLabel(self._message)

    def onAction(self, action):
        if action.getId() in (10, 92):
            self.cancelled = True
            self.getControl(10).setLabel('Obrint el catàleg...')
