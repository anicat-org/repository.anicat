# -*- coding: utf-8 -*-
"""
Módulo de compatibilidad con Trakt y otros plugins de seguimiento.
Proporciona métodos alternativos para asegurar el tracking de progreso.
"""

import xbmc
import xbmcaddon
import time
import threading
from resources.lib import progress_tracker

class TraktCompatibleTracker:
    """
    Tracker de progreso compatible con Trakt y otros plugins.
    Usa múltiples estrategias para asegurar que el progreso se guarde.
    """
    
    def __init__(self):
        self.tracking_active = False
        self.current_file_id = None
        self.tracking_thread = None
        self.monitor = xbmc.Monitor()
        self.last_position = 0
        self.last_update = 0
        
        # Detectar si Trakt está activo
        self.trakt_active = self._detect_trakt()
        xbmc.log(f"[AniCat] Trakt detectado: {self.trakt_active}", xbmc.LOGINFO)
    
    def _detect_trakt(self):
        """Detecta si el plugin de Trakt está activo."""
        try:
            # Verificar si el plugin de Trakt está instalado
            json_response = xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Addons.GetAddonDetails","params":{"addonid":"script.trakt"},"id":1}')
            response = xbmc.getJSON(json_response)
            return 'result' in response and 'addon' in response['result']
        except:
            return False
    
    def start_tracking(self, file_id):
        """Inicia el seguimiento compatible con Trakt."""
        if self.tracking_active:
            self.stop_tracking()
        
        self.current_file_id = file_id
        self.tracking_active = True
        self.last_position = 0
        self.last_update = time.time()
        
        xbmc.log(f"[AniCat] Iniciando tracking compatible con Trakt para: {file_id}", xbmc.LOGINFO)
        
        # Iniciar seguimiento en hilo separado
        self.tracking_thread = threading.Thread(target=self._track_with_fallback)
        self.tracking_thread.daemon = True
        self.tracking_thread.start()
    
    def _track_with_fallback(self):
        """
        Sistema de tracking con múltiples estrategias.
        Prioridad: JSON-RPC > Player API > Window Properties
        """
        player = xbmc.Player()
        update_interval = 2  # Actualizar cada 2 segundos
        
        while self.tracking_active and not self.monitor.abortRequested():
            try:
                # Esperar a que comience la reproducción
                if not player.isPlayingVideo():
                    if self.monitor.waitForAbort(1):
                        break
                    continue
                
                current_time = self._get_current_position(player)
                total_time = self._get_total_duration(player)
                
                if current_time > 0 and total_time > 0:
                    # Actualizar solo si ha pasado tiempo suficiente o hay cambio significativo
                    time_diff = abs(current_time - self.last_position)
                    time_since_update = time.time() - self.last_update
                    
                    if time_diff >= 5 or time_since_update >= update_interval:
                        self._update_progress_safe(current_time, total_time)
                        self.last_position = current_time
                        self.last_update = time.time()
                
                if self.monitor.waitForAbort(1):
                    break
                    
            except Exception as e:
                xbmc.log(f"[AniCat] Error en tracking compatible: {e}", xbmc.LOGWARNING)
                if self.monitor.waitForAbort(2):
                    break
        
        # Actualización final
        try:
            if player.isPlayingVideo():
                current_time = self._get_current_position(player)
                total_time = self._get_total_duration(player)
                if current_time > 0 and total_time > 0:
                    self._update_progress_safe(current_time, total_time)
                    # Marcar como visto si se completó
                    if current_time / total_time > 0.90:
                        progress_tracker.mark_as_watched(self.current_file_id)
        except:
            pass
        
        xbmc.log(f"[AniCat] Tracking compatible finalizado para: {self.current_file_id}", xbmc.LOGINFO)
        self.tracking_active = False
    
    def _get_current_position(self, player):
        """Obtiene la posición actual usando múltiples métodos."""
        try:
            # Método 1: Player API directo
            position = player.getTime()
            if position > 0:
                return position
        except:
            pass
        
        try:
            # Método 2: JSON-RPC (más compatible con Trakt)
            json_query = '''
            {
                "jsonrpc": "2.0",
                "method": "Player.GetProperties",
                "params": {
                    "playerid": 1,
                    "properties": ["time"]
                },
                "id": 1
            }
            '''
            response = xbmc.executeJSONRPC(json_query)
            data = xbmc.getJSON(response)
            
            if 'result' in data and 'time' in data['result']:
                time_data = data['result']['time']
                if isinstance(time_data, dict):
                    hours = time_data.get('hours', 0)
                    minutes = time_data.get('minutes', 0)
                    seconds = time_data.get('seconds', 0)
                    return hours * 3600 + minutes * 60 + seconds
        except:
            pass
        
        return 0
    
    def _get_total_duration(self, player):
        """Obtiene la duración total usando múltiples métodos."""
        try:
            # Método 1: Player API directo
            duration = player.getTotalTime()
            if duration > 0:
                return duration
        except:
            pass
        
        try:
            # Método 2: JSON-RPC
            json_query = '''
            {
                "jsonrpc": "2.0",
                "method": "Player.GetProperties",
                "params": {
                    "playerid": 1,
                    "properties": ["totaltime"]
                },
                "id": 1
            }
            '''
            response = xbmc.executeJSONRPC(json_query)
            data = xbmc.getJSON(response)
            
            if 'result' in data and 'totaltime' in data['result']:
                time_data = data['result']['totaltime']
                if isinstance(time_data, dict):
                    hours = time_data.get('hours', 0)
                    minutes = time_data.get('minutes', 0)
                    seconds = time_data.get('seconds', 0)
                    return hours * 3600 + minutes * 60 + seconds
        except:
            pass
        
        return 0
    
    def _update_progress_safe(self, current_time, total_time):
        """Actualiza el progreso de forma segura con reintentos."""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                progress_tracker.register_playback_start(
                    self.current_file_id,
                    '',  # title se actualizará si ya existe
                    '',  # thumbnail
                    '',  # fanart
                    '',  # type
                    '',  # series_id
                    '',  # season_id
                    0    # episode_number
                )
                
                # Actualizar directamente en la base de datos para evitar conflictos
                conn = progress_tracker.get_db_connection()
                cursor = conn.cursor()
                
                cursor.execute('''
                UPDATE progress 
                SET resume_time = ?, total_time = ?, last_played = ? 
                WHERE file_id = ?
                ''', (current_time, total_time, int(time.time()), self.current_file_id))
                
                conn.commit()
                conn.close()
                
                xbmc.log(f"[AniCat] Progreso actualizado (intento {attempt + 1}): {current_time}s/{total_time}s", xbmc.LOGDEBUG)
                return True
                
            except Exception as e:
                xbmc.log(f"[AniCat] Error actualizando progreso (intento {attempt + 1}): {e}", xbmc.LOGWARNING)
                if attempt < max_retries - 1:
                    time.sleep(0.5)
        
        return False
    
    def stop_tracking(self):
        """Detiene el seguimiento."""
        xbmc.log("[AniCat] Deteniendo tracking compatible con Trakt", xbmc.LOGINFO)
        self.tracking_active = False
        if self.tracking_thread and self.tracking_thread.is_alive():
            self.tracking_thread.join(timeout=2)
        self.current_file_id = None

# Instancia global
trakt_compatible_tracker = TraktCompatibleTracker()
