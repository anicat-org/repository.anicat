# -*- coding: utf-8 -*-
"""
Módulo de seguimiento de progreso local (SQLite).
Gestiona "seguir viendo", "ver más tarde" y watchlist.
"""

import json
import os

import xbmc
import xbmcaddon
import xbmcvfs
import time
import sqlite3
import threading

addon = xbmcaddon.Addon()
_user_data_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

if not xbmcvfs.exists(_user_data_dir):
    xbmcvfs.mkdirs(_user_data_dir)

DB_PATH = os.path.join(_user_data_dir, 'progress.db')
_db_lock = threading.RLock()
COMPLETION_THRESHOLD = 0.90


# ------------------------------------------------------------------
# Conexión y esquema
# ------------------------------------------------------------------

def get_db_connection():
    from resources.lib.core.library_sync import database_path
    conn = sqlite3.connect(database_path(DB_PATH), timeout=10)
    conn.row_factory = sqlite3.Row
    if not conn.execute("SELECT 1 FROM sqlite_master WHERE name='progress'").fetchone():
        conn.close()
        init_database()
        conn = sqlite3.connect(database_path(DB_PATH), timeout=10)
        conn.row_factory = sqlite3.Row
    return conn


def init_database():
    """Crea las tablas si no existen. Idempotente."""
    try:
        with _db_lock:
            from resources.lib.core.library_sync import database_path
            conn = sqlite3.connect(database_path(DB_PATH), timeout=10)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.executescript('''
                CREATE TABLE IF NOT EXISTS progress (
                    file_id       TEXT PRIMARY KEY,
                    title         TEXT,
                    resume_time   REAL DEFAULT 0,
                    total_time    REAL DEFAULT 0,
                    last_played   INTEGER DEFAULT 0,
                    thumbnail     TEXT DEFAULT '',
                    fanart        TEXT DEFAULT '',
                    type          TEXT DEFAULT 'movie',
                    series_id     TEXT DEFAULT '',
                    season_id     TEXT DEFAULT '',
                    episode_number INTEGER DEFAULT 0,
                    tmdb_id       INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS watchlist (
                    folder_id   TEXT PRIMARY KEY,
                    drive_id    TEXT,
                    title       TEXT,
                    thumbnail   TEXT DEFAULT '',
                    fanart      TEXT DEFAULT '',
                    added_date  INTEGER DEFAULT 0,
                    tmdb_id     INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS tmdb_cache (
                    cache_key   TEXT PRIMARY KEY,
                    data_json   TEXT,
                    expires_at  INTEGER
                );

                CREATE TABLE IF NOT EXISTS series_map (
                    folder_id   TEXT PRIMARY KEY,
                    drive_id    TEXT,
                    tmdb_id     INTEGER DEFAULT 0,
                    title       TEXT,
                    thumb_url   TEXT DEFAULT '',
                    fanart_url  TEXT DEFAULT '',
                    updated_at  INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS episode_playlists (
                    series_id     TEXT PRIMARY KEY,
                    episodes_json TEXT NOT NULL,
                    updated_at    INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS active_episode_playlist (
                    id            INTEGER PRIMARY KEY DEFAULT 1,
                    episodes_json TEXT NOT NULL,
                    updated_at    INTEGER DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS pending_playback (
                    id             INTEGER PRIMARY KEY DEFAULT 1,
                    file_id        TEXT,
                    title          TEXT DEFAULT '',
                    thumbnail      TEXT DEFAULT '',
                    fanart         TEXT DEFAULT '',
                    file_type      TEXT DEFAULT 'movie',
                    series_id      TEXT DEFAULT '',
                    season_id      TEXT DEFAULT '',
                    episode_number INTEGER DEFAULT 0,
                    resume_time    REAL DEFAULT 0,
                    written_at     INTEGER DEFAULT 0
                );
            ''')
            progress_columns = {
                row['name'] for row in cursor.execute('PRAGMA table_info(progress)')
            }
            if 'tmdb_id' not in progress_columns:
                cursor.execute(
                    'ALTER TABLE progress ADD COLUMN tmdb_id INTEGER DEFAULT 0'
                )
            if 'completed' not in progress_columns:
                cursor.execute('ALTER TABLE progress ADD COLUMN completed INTEGER NOT NULL DEFAULT 0')
                # Legacy completion cleared resume_time but retained duration.
                cursor.execute('''UPDATE progress SET completed=1, resume_time=0
                                  WHERE total_time>0 AND (resume_time=0 OR 1.0*resume_time/total_time>=0.90)''')
            if 'queued' not in progress_columns:
                cursor.execute('ALTER TABLE progress ADD COLUMN queued INTEGER NOT NULL DEFAULT 0')
            # The original schema had no numeric defaults. Repair successors
            # inserted by 1.5.3 without resetting existing playback positions.
            cursor.execute('''UPDATE progress SET resume_time=COALESCE(resume_time, 0),
                              total_time=COALESCE(total_time, 0)
                              WHERE resume_time IS NULL OR total_time IS NULL''')

            watchlist_columns = {row['name'] for row in cursor.execute('PRAGMA table_info(watchlist)')}
            for name, declaration in (
                ('content_type', "TEXT NOT NULL DEFAULT 'series'"),
                ('is_folder', 'INTEGER NOT NULL DEFAULT 1'),
                ('parent_id', "TEXT NOT NULL DEFAULT ''"),
                ('source_name', "TEXT NOT NULL DEFAULT ''"),
            ):
                if name not in watchlist_columns:
                    cursor.execute('ALTER TABLE watchlist ADD COLUMN %s %s' % (name, declaration))

            legacy_watchlist = cursor.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='watchlist_folders'"
            ).fetchone()
            if legacy_watchlist:
                cursor.execute('''
                    INSERT OR IGNORE INTO watchlist
                        (folder_id, drive_id, title, thumbnail, fanart, added_date)
                    SELECT folder_id, drive_id, title, thumbnail, fanart, added_date
                    FROM watchlist_folders
                ''')

            # Migració: afegir columna resume_time si no existeix (BD antigues)
            try:
                cursor.execute('ALTER TABLE pending_playback ADD COLUMN resume_time REAL DEFAULT 0')
                conn.commit()
            except Exception:
                pass  # Ja existeix, ignorar

            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error init_database: {e}', xbmc.LOGERROR)


# Inicializar al importar el módulo
init_database()


# ------------------------------------------------------------------
# Progreso de reproducción
# ------------------------------------------------------------------

def register_playback_start(file_id, title='', thumbnail='', fanart='',
                             file_type='movie', series_id='', season_id='',
                             episode_number=0):
    """
    Registra el inicio de reproducción.
    Conserva resume_time existente para no perder la posición guardada.
    """
    if not file_id:
        xbmc.log('[AniCat] register_playback_start: file_id vacío', xbmc.LOGERROR)
        return

    try:
        with _db_lock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT resume_time, total_time FROM progress WHERE file_id = ?', (file_id,))
            row = cursor.fetchone()
            existing_resume = (row['resume_time'] or 0) if row else 0
            existing_total = (row['total_time'] or 0) if row else 0

            cursor.execute('''
                INSERT INTO progress
                    (file_id, title, resume_time, total_time, last_played,
                     thumbnail, fanart, type, series_id, season_id, episode_number)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(file_id) DO UPDATE SET
                    title          = excluded.title,
                    completed      = 0,
                    last_played    = excluded.last_played,
                    thumbnail      = CASE WHEN excluded.thumbnail != '' THEN excluded.thumbnail ELSE thumbnail END,
                    fanart         = CASE WHEN excluded.fanart != '' THEN excluded.fanart ELSE fanart END,
                    type           = excluded.type,
                    series_id      = CASE WHEN excluded.series_id != '' THEN excluded.series_id ELSE series_id END,
                    season_id      = CASE WHEN excluded.season_id != '' THEN excluded.season_id ELSE season_id END,
                    episode_number = CASE WHEN excluded.episode_number > 0 THEN excluded.episode_number ELSE episode_number END
            ''', (
                file_id, title, existing_resume, existing_total,
                int(time.time()), thumbnail, fanart,
                file_type, series_id, season_id, episode_number,
            ))
            conn.commit()
            conn.close()
        xbmc.log(f'[AniCat] Reproducción registrada: {file_id} ({title})', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[AniCat] Error en register_playback_start: {e}', xbmc.LOGERROR)


def update_progress(file_id, current_time, total_time):
    """Actualiza la posición actual y duración total."""
    if not file_id or current_time <= 0 or total_time <= 0:
        return
    try:
        with _db_lock:
            conn = get_db_connection()
            cursor = conn.cursor()
            previous = cursor.execute('SELECT completed FROM progress WHERE file_id=?', (file_id,)).fetchone()
            completed = bool(previous and previous['completed']) or current_time / total_time >= COMPLETION_THRESHOLD
            cursor.execute('''
                UPDATE progress
                SET resume_time = ?, total_time = ?, last_played = CASE WHEN completed=1 THEN last_played ELSE ? END,
                    completed=?, queued=CASE WHEN ? THEN 0 ELSE queued END
                WHERE file_id = ?
            ''', (0 if completed else current_time, total_time, int(time.time()), int(completed),
                  completed or current_time / total_time > 0.02, file_id))
            if cursor.rowcount == 0:
                # El registro no existe todavía (edge case), insertarlo
                cursor.execute('''
                    INSERT INTO progress (file_id, resume_time, total_time, last_played, title, completed)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (file_id, 0 if completed else current_time, total_time, int(time.time()), 'Video', int(completed)))
            if completed and not (previous and previous['completed']):
                _queue_next_episode(conn, file_id)
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error en update_progress: {e}', xbmc.LOGWARNING)


def get_resume_time(file_id):
    """Devuelve el tiempo de reanudación en segundos (0 si no hay)."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT resume_time FROM progress WHERE file_id = ?', (file_id,))
        row = cursor.fetchone()
        conn.close()
        return (row['resume_time'] or 0) if row else 0
    except Exception as e:
        xbmc.log(f'[AniCat] Error en get_resume_time: {e}', xbmc.LOGWARNING)
        return 0


def mark_as_watched(file_id):
    """Marca como completamente visto (resume_time = 0)."""
    try:
        with _db_lock:
            conn = get_db_connection()
            previous = conn.execute('SELECT completed FROM progress WHERE file_id=?', (file_id,)).fetchone()
            conn.execute('''UPDATE progress SET resume_time=0, completed=1, queued=0,
                            last_played=CASE WHEN completed=1 THEN last_played ELSE ? END WHERE file_id=?''',
                         (int(time.time()), file_id))
            if previous and not previous['completed']:
                _queue_next_episode(conn, file_id)
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error en mark_as_watched: {e}', xbmc.LOGERROR)


def mark_as_unwatched(file_id):
    """Elimina el registro de progreso."""
    try:
        with _db_lock:
            conn = get_db_connection()
            conn.execute('DELETE FROM progress WHERE file_id = ?', (file_id,))
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error en mark_as_unwatched: {e}', xbmc.LOGERROR)


def get_continue_watching_items(limit=20):
    """
    Devuelve reproducciones entre 2% y 90%, y sucesores pendientes desde el inicio.
    Solo considera el estado más reciente de cada serie, incluidos sus completados.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM progress ORDER BY last_played DESC, completed ASC, queued DESC, rowid DESC')
        rows = cursor.fetchall()
        conn.close()

        series_seen = {}
        result = []

        for row in rows:
            item = dict(row)
            if item['type'] == 'episode' and item.get('series_id'):
                sid = item['series_id']
                if sid in series_seen:
                    continue
                series_seen[sid] = item
            ratio = item['resume_time'] / item['total_time'] if item['total_time'] else 0
            if item['completed'] or not (item['queued'] or 0.02 < ratio < COMPLETION_THRESHOLD):
                continue
            item['progress_percent'] = max(0, min(100, int(ratio * 100)))
            result.append(item)

        return result[:limit]

    except Exception as e:
        xbmc.log(f'[AniCat] Error en get_continue_watching_items: {e}', xbmc.LOGERROR)
        return []


# ------------------------------------------------------------------
# Playlists de episodios
# ------------------------------------------------------------------

def get_progress_state(file_id):
    conn = get_db_connection()
    try:
        row = conn.execute('SELECT resume_time, total_time, completed, queued FROM progress WHERE file_id=?',
                           (file_id,)).fetchone()
        return {key: row[key] or 0 for key in row.keys()} if row else {
            'resume_time': 0, 'total_time': 0, 'completed': 0, 'queued': 0}
    finally:
        conn.close()


def _queue_next_episode(conn, file_id):
    """Complete and prepare the immediate successor in the same transaction."""
    current = conn.execute('SELECT * FROM progress WHERE file_id=?', (file_id,)).fetchone()
    if not current or current['type'] != 'episode' or not current['series_id']:
        return
    playlists = conn.execute('SELECT episodes_json FROM active_episode_playlist WHERE id=1').fetchall()
    playlists += conn.execute('SELECT episodes_json FROM episode_playlists WHERE series_id=?',
                              (current['series_id'],)).fetchall()
    for stored in playlists:
        episodes = json.loads(stored['episodes_json'])
        index = next((i for i, ep in enumerate(episodes) if ep.get('id') == file_id), -1)
        if index < 0:
            continue
        if index + 1 == len(episodes):
            return
        following = episodes[index + 1]
        if following.get('series_id') != current['series_id']:
            return
        # Modern playlists carry folder IDs; do not cross seasons or versions.
        if episodes[index].get('folder_id') != following.get('folder_id'):
            return
        conn.execute('''INSERT INTO progress
                        (file_id, title, thumbnail, fanart, type, series_id, season_id,
                         episode_number, last_played, queued, resume_time, total_time)
                        VALUES (?, ?, ?, ?, 'episode', ?, ?, ?, ?, 1, 0, 0)
                        ON CONFLICT(file_id) DO UPDATE SET queued=1, last_played=excluded.last_played
                        WHERE progress.completed=0''',
                     (following['id'], following.get('name', ''), following.get('thumb', ''),
                      following.get('fanart', ''), current['series_id'], following.get('folder_id', ''),
                      following.get('episode_number', 0), int(time.time())))
        return


def save_episode_playlist(series_id, episodes):
    if not series_id or not episodes:
        return
    try:
        with _db_lock:
            conn = get_db_connection()
            conn.execute('''
                INSERT INTO episode_playlists (series_id, episodes_json, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(series_id) DO UPDATE SET
                    episodes_json = excluded.episodes_json,
                    updated_at = excluded.updated_at
            ''', (series_id, json.dumps(episodes, ensure_ascii=False), int(time.time())))
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error en save_episode_playlist: {e}', xbmc.LOGERROR)


def get_episode_playlist(series_id):
    if not series_id:
        return []
    try:
        conn = get_db_connection()
        row = conn.execute(
            'SELECT episodes_json FROM episode_playlists WHERE series_id = ?',
            (series_id,),
        ).fetchone()
        conn.close()
        return json.loads(row['episodes_json']) if row else []
    except Exception as e:
        xbmc.log(f'[AniCat] Error en get_episode_playlist: {e}', xbmc.LOGWARNING)
        return []


def save_active_episode_playlist(episodes):
    try:
        with _db_lock:
            conn = get_db_connection()
            conn.execute('''
                INSERT INTO active_episode_playlist (id, episodes_json, updated_at)
                VALUES (1, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    episodes_json = excluded.episodes_json,
                    updated_at = excluded.updated_at
            ''', (json.dumps(episodes, ensure_ascii=False), int(time.time())))
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error en save_active_episode_playlist: {e}', xbmc.LOGERROR)


def get_active_episode_playlist():
    try:
        conn = get_db_connection()
        row = conn.execute(
            'SELECT episodes_json FROM active_episode_playlist WHERE id = 1'
        ).fetchone()
        conn.close()
        return json.loads(row['episodes_json']) if row else []
    except Exception as e:
        xbmc.log(f'[AniCat] Error en get_active_episode_playlist: {e}', xbmc.LOGWARNING)
        return []


def clear_active_episode_playlist():
    try:
        with _db_lock:
            conn = get_db_connection()
            conn.execute('DELETE FROM active_episode_playlist WHERE id = 1')
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error en clear_active_episode_playlist: {e}', xbmc.LOGWARNING)


# ------------------------------------------------------------------
# Watchlist / Ver más tarde
# ------------------------------------------------------------------

def add_to_watchlist(folder_id, drive_id, title, thumbnail='', fanart='', tmdb_id=0,
                     content_type='series', is_folder=True, parent_id='', source_name=''):
    try:
        with _db_lock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT folder_id FROM watchlist WHERE folder_id = ?', (folder_id,))
            if cursor.fetchone():
                conn.close()
                return False
            cursor.execute('''
                INSERT INTO watchlist (folder_id, drive_id, title, thumbnail, fanart, added_date,
                                       tmdb_id, content_type, is_folder, parent_id, source_name)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (folder_id, drive_id, title, thumbnail, fanart, int(time.time()), tmdb_id,
                  content_type, int(is_folder), parent_id, source_name))
            conn.commit()
            conn.close()
        return True
    except Exception as e:
        xbmc.log(f'[AniCat] Error en add_to_watchlist: {e}', xbmc.LOGERROR)
        return False


def remove_from_watchlist(folder_id):
    try:
        with _db_lock:
            conn = get_db_connection()
            conn.execute('DELETE FROM watchlist WHERE folder_id = ?', (folder_id,))
            legacy_watchlist = conn.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='watchlist_folders'"
            ).fetchone()
            if legacy_watchlist:
                conn.execute(
                    'DELETE FROM watchlist_folders WHERE folder_id = ?',
                    (folder_id,),
                )
            conn.commit()
            conn.close()
        return True
    except Exception as e:
        xbmc.log(f'[AniCat] Error en remove_from_watchlist: {e}', xbmc.LOGERROR)
        return False


def get_watchlist():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM watchlist ORDER BY added_date DESC')
        items = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return items
    except Exception as e:
        xbmc.log(f'[AniCat] Error en get_watchlist: {e}', xbmc.LOGERROR)
        return []


def is_in_watchlist(folder_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT 1 FROM watchlist WHERE folder_id = ?', (folder_id,))
        result = cursor.fetchone() is not None
        conn.close()
        return result
    except Exception as e:
        xbmc.log(f'[AniCat] Error en is_in_watchlist: {e}', xbmc.LOGWARNING)
        return False


# ------------------------------------------------------------------
# Series map (Drive folder → TMDB)
# ------------------------------------------------------------------

def get_series_map(folder_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM series_map WHERE folder_id = ?', (folder_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None
    except Exception as e:
        xbmc.log(f'[AniCat] Error en get_series_map: {e}', xbmc.LOGWARNING)
        return None


def save_series_map(folder_id, drive_id, tmdb_id, title, thumb_url='', fanart_url=''):
    try:
        with _db_lock:
            conn = get_db_connection()
            conn.execute('''
                INSERT INTO series_map (folder_id, drive_id, tmdb_id, title, thumb_url, fanart_url, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(folder_id) DO UPDATE SET
                    tmdb_id    = excluded.tmdb_id,
                    title      = excluded.title,
                    thumb_url  = excluded.thumb_url,
                    fanart_url = excluded.fanart_url,
                    updated_at = excluded.updated_at
            ''', (folder_id, drive_id, tmdb_id, title, thumb_url, fanart_url, int(time.time())))
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] Error en save_series_map: {e}', xbmc.LOGERROR)


# ------------------------------------------------------------------
# Mantenimiento
# ------------------------------------------------------------------

def cleanup_old_records(days=30):
    """Remove abandoned starts; retain watched history and queued episodes."""
    try:
        cutoff = int(time.time()) - (days * 86400)
        with _db_lock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                'DELETE FROM progress WHERE resume_time=0 AND completed=0 AND queued=0 AND last_played < ?',
                (cutoff,)
            )
            deleted = cursor.rowcount
            conn.commit()
            conn.close()
        if deleted > 0:
            xbmc.log(f'[AniCat] Limpiados {deleted} registros antiguos de progreso', xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f'[AniCat] Error en cleanup_old_records: {e}', xbmc.LOGERROR)


# ------------------------------------------------------------------
# IPC: pending_playback  (plugin → service)
# ------------------------------------------------------------------

def write_pending_playback(file_id, title='', thumbnail='', fanart='',
                            file_type='movie', series_id='', season_id='',
                            episode_number=0, resume_time=0):
    """
    Escriu les metadades de la reproducció pendent a la BD.
    El plugin ho crida just ABANS de setResolvedUrl.
    El service (AniCatPlayer) ho llegeix a onPlayBackStarted.
    Usa id=1 (upsert): només hi ha un element pendent a la vegada.
    """
    try:
        with _db_lock:
            conn = get_db_connection()
            conn.execute('''
                INSERT INTO pending_playback
                    (id, file_id, title, thumbnail, fanart,
                     file_type, series_id, season_id, episode_number, resume_time, written_at)
                VALUES (1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    file_id        = excluded.file_id,
                    title          = excluded.title,
                    thumbnail      = excluded.thumbnail,
                    fanart         = excluded.fanart,
                    file_type      = excluded.file_type,
                    series_id      = excluded.series_id,
                    season_id      = excluded.season_id,
                    episode_number = excluded.episode_number,
                    resume_time    = excluded.resume_time,
                    written_at     = excluded.written_at
            ''', (file_id, title, thumbnail, fanart, file_type,
                  series_id, season_id, episode_number, resume_time, int(time.time())))
            conn.commit()
            conn.close()
        xbmc.log(f'[AniCat] pending_playback escrit: {file_id}', xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f'[AniCat] Error write_pending_playback: {e}', xbmc.LOGERROR)


def read_and_clear_pending_playback():
    """
    Llegeix i esborra el registre pending_playback.
    Retorna un dict o None si no n'hi ha.
    Descarta entrades de més de 30 segons (stale).
    """
    try:
        with _db_lock:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM pending_playback WHERE id = 1')
            row = cursor.fetchone()
            if row:
                conn.execute('DELETE FROM pending_playback WHERE id = 1')
                conn.commit()
            conn.close()

        if not row:
            return None
        # Descartar si és massa antic (> 30 s)
        age = int(time.time()) - (row['written_at'] or 0)
        if age > 30:
            xbmc.log(f'[AniCat] pending_playback stale ({age}s), descartat', xbmc.LOGWARNING)
            return None
        return dict(row)
    except Exception as e:
        xbmc.log(f'[AniCat] Error read_and_clear_pending_playback: {e}', xbmc.LOGERROR)
        return None


def get_all_progress():
    """Retorna tots els registres de progress per al debug."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM progress ORDER BY last_played DESC')
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows
    except Exception as e:
        xbmc.log(f'[AniCat] Error get_all_progress: {e}', xbmc.LOGERROR)
        return []
