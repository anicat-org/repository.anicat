# -*- coding: utf-8 -*-
"""
Overlay visual para debugging del sistema de tracking en el reproductor Kodi.
Muestra información en tiempo real sobre el estado del seguimiento de progreso.
"""

import xbmc
import xbmcgui
import xbmcaddon
import time
import threading

class TrackingOverlay:
    """Overlay visual para mostrar información de tracking en tiempo real."""
    
    def __init__(self):
        self.window_id = 10150  # ID de ventana custom
        self.visible = False
        self.overlay_window = None
        self.update_thread = None
        self.monitor = xbmc.Monitor()
        
        # Configuración
        self.addon = xbmcaddon.Addon()
        self.addon_name = self.addon.getAddonInfo('name')
        
        # Estado actual
        self.current_file_id = None
        self.tracking_active = False
        self.trakt_detected = False
        self.last_update = 0
        self.current_time = 0
        self.total_time = 0
        self.update_count = 0
        self.errors = []
        
    def show_overlay(self, file_id=None):
        """Muestra el overlay de tracking."""
        if self.visible:
            return
            
        self.current_file_id = file_id
        self.visible = True
        self.tracking_active = True
        
        # Crear ventana de overlay
        self.overlay_window = xbmcgui.WindowXML(
            "tracking_overlay.xml", 
            self.addon.getAddonInfo('path'), 
            "Default", 
            self.window_id
        )
        
        # Iniciar thread de actualización
        self.update_thread = threading.Thread(target=self._update_loop)
        self.update_thread.daemon = True
        self.update_thread.start()
        
        xbmc.log(f"[{self.addon_name}] Tracking overlay iniciado", xbmc.LOGINFO)
    
    def hide_overlay(self):
        """Oculta el overlay de tracking."""
        self.visible = False
        self.tracking_active = False
        
        if self.update_thread and self.update_thread.is_alive():
            self.update_thread.join(timeout=1)
        
        if self.overlay_window:
            try:
                self.overlay_window.close()
            except:
                pass
            self.overlay_window = None
        
        xbmc.log(f"[{self.addon_name}] Tracking overlay detenido", xbmc.LOGINFO)
    
    def _update_loop(self):
        """Bucle de actualización del overlay."""
        while self.visible and not self.monitor.abortRequested():
            try:
                self._update_status()
                self._update_display()
                
                if self.monitor.waitForAbort(1):
                    break
                    
            except Exception as e:
                xbmc.log(f"[{self.addon_name}] Error en update_loop: {e}", xbmc.LOGERROR)
                self.errors.append(f"Update error: {e}")
    
    def _update_status(self):
        """Actualiza el estado del tracking."""
        try:
            # Verificar si hay reproducción activa
            player = xbmc.Player()
            is_playing = player.isPlayingVideo()
            
            # Método alternativo JSON-RPC
            if not is_playing:
                try:
                    json_query = '{"jsonrpc":"2.0","method":"Player.GetActivePlayers","id":1}'
                    response = xbmc.executeJSONRPC(json_query)
                    data = xbmc.getJSON(response)
                    if 'result' in data and len(data['result']) > 0:
                        is_playing = any(p.get('type') == 'video' for p in data['result'])
                except:
                    pass
            
            if is_playing:
                try:
                    self.current_time = player.getTime()
                    self.total_time = player.getTotalTime()
                    self.last_update = time.time()
                    self.update_count += 1
                except:
                    # Método alternativo JSON-RPC
                    try:
                        json_query = '''
                        {
                            "jsonrpc": "2.0",
                            "method": "Player.GetProperties",
                            "params": {"playerid": 1, "properties": ["time", "totaltime"]},
                            "id": 1
                        }
                        '''
                        response = xbmc.executeJSONRPC(json_query)
                        data = xbmc.getJSON(response)
                        if 'result' in data:
                            result = data['result']
                            time_data = result.get('time', {})
                            totaltime_data = result.get('totaltime', {})
                            
                            self.current_time = time_data.get('hours', 0) * 3600 + time_data.get('minutes', 0) * 60 + time_data.get('seconds', 0)
                            self.total_time = totaltime_data.get('hours', 0) * 3600 + totaltime_data.get('minutes', 0) * 60 + totaltime_data.get('seconds', 0)
                            self.last_update = time.time()
                            self.update_count += 1
                    except:
                        pass
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error actualizando estado: {e}", xbmc.LOGERROR)
            self.errors.append(f"Status error: {e}")
    
    def _update_display(self):
        """Actualiza la visualización del overlay."""
        if not self.overlay_window:
            return
            
        try:
            # Formatear información
            progress_percent = 0
            if self.total_time > 0:
                progress_percent = int((self.current_time / self.total_time) * 100)
            
            # Construir texto de estado
            status_text = f"=== TRACKING DEBUG ===\n"
            status_text += f"File ID: {self.current_file_id or 'N/A'}\n"
            status_text += f"Tracking: {'✅ ACTIVO' if self.tracking_active else '❌ INACTIVO'}\n"
            status_text += f"Updates: {self.update_count}\n"
            status_text += f"Time: {self._format_time(self.current_time)} / {self._format_time(self.total_time)}\n"
            status_text += f"Progress: {progress_percent}%\n"
            status_text += f"Last Update: {time.strftime('%H:%M:%S', time.localtime(self.last_update)) if self.last_update else 'Never'}\n"
            
            if self.errors:
                status_text += f"\nErrors ({len(self.errors)}):\n"
                for i, error in enumerate(self.errors[-3:]):  # Últimos 3 errores
                    status_text += f"  {error}\n"
            
            # Actualizar labels en la ventana
            self.overlay_window.setProperty('StatusText', status_text)
            self.overlay_window.setProperty('ProgressPercent', str(progress_percent))
            self.overlay_window.setProperty('TrackingActive', str(self.tracking_active))
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error actualizando display: {e}", xbmc.LOGERROR)
    
    def _format_time(self, seconds):
        """Formatea segundos en formato MM:SS."""
        if seconds <= 0:
            return "00:00"
        
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        else:
            return f"{minutes:02d}:{secs:02d}"
    
    def add_error(self, error_msg):
        """Añade un error al log."""
        self.errors.append(f"[{time.strftime('%H:%M:%S')}] {error_msg}")
        # Mantener solo los últimos 10 errores
        if len(self.errors) > 10:
            self.errors = self.errors[-10:]

# Instancia global
tracking_overlay = TrackingOverlay()
