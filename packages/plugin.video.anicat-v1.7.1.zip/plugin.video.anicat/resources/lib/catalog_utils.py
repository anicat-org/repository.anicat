# -*- coding: utf-8 -*-

import string
import unicodedata


def normalized_title(title):
    normalized = unicodedata.normalize('NFKD', title or '')
    return ''.join(
        character for character in normalized
        if not unicodedata.combining(character)
    ).casefold().strip()


def group_by_initial(items):
    groups = {}
    sorted_items = sorted(
        items,
        key=lambda value: normalized_title(value.get('name', ''))
    )
    for item in sorted_items:
        title = normalized_title(item.get('name', ''))
        initial = title[:1].upper()
        if len(initial) != 1 or initial not in string.ascii_uppercase:
            initial = '#'
        groups.setdefault(initial, []).append(item)
    return groups
