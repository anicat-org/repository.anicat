# -*- coding: utf-8 -*-
"""
AniCat Window Router — gestiona el flux de navegació amb WindowXML.
Cada funció show_* obre la finestra corresponent i executa l'acció
seleccionada cridant recursivament o llançant la reproducció.
"""

import sys

import xbmc
import xbmcaddon
import xbmcplugin
import xbmcvfs

addon = xbmcaddon.Addon()
_loading_window = None


def _addon_path():
    """Retorna el path absolut de l'addon, compatible amb totes les plataformes."""
    import os
    # Mètode 1: translatePath (Kodi 19+)
    p = xbmcvfs.translatePath(addon.getAddonInfo('path'))
    if p and os.path.isdir(p):
        return p
    # Mètode 2: path directe de l'addon info
    p = addon.getAddonInfo('path')
    if p and os.path.isdir(p):
        return p
    # Mètode 3: deduir del fitxer actual (__file__ és .../resources/lib/ui/windows/window_router.py)
    p = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
    xbmc.log(f'[AniCat] _addon_path fallback a __file__: {p}', xbmc.LOGWARNING)
    return p


# ------------------------------------------------------------------
# Helpers interns
# ------------------------------------------------------------------

def _hide_loading():
    global _loading_window
    if _loading_window:
        window = _loading_window
        _loading_window = None
        try:
            window.close()
        finally:
            xbmc.sleep(100)


def _show_loading(message='Carregant...'):
    global _loading_window
    _hide_loading()
    from resources.lib.ui.windows.loading_window import LoadingWindow, WINDOW_XML
    _loading_window = LoadingWindow(
        WINDOW_XML,
        _addon_path(),
        'Default',
        '720p',
        message=message,
    )
    _loading_window.show()
    xbmc.sleep(150)


def _show_modal(window):
    _hide_loading()
    xbmc.executebuiltin('Dialog.Close(busydialog)')
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    xbmc.sleep(100)
    try:
        window.doModal()
    finally:
        window.close()


def _play(file_id, drive_id, content_type, folder_id='', folder_name='',
          episode_number=0, season_number=0):
    """Llança play_video directament (sense passar per URL del plugin)."""
    from resources.lib.ui.playback import play_video
    _hide_loading()
    play_video({
        'file_id':        [file_id],
        'drive_id':       [drive_id],
        'content_type':   [content_type],
        'folder_id':      [folder_id] if folder_id else [None],
        'folder_name':    [folder_name],
        'episode_number': [str(episode_number)],
        'season_number':  [str(season_number)],
        'direct_playback': ['true'],
    })
    return True


def _get_resume(file_id):
    from resources.lib.core.progress import get_resume_time, get_db_connection
    rt = get_resume_time(file_id)
    try:
        conn = get_db_connection()
        row = conn.execute(
            'SELECT total_time FROM progress WHERE file_id=?', (file_id,)
        ).fetchone()
        conn.close()
        tt = row['total_time'] if row else 0
    except Exception:
        tt = 0
    return rt, tt


# ------------------------------------------------------------------
# HOME
# ------------------------------------------------------------------

def show_home():
    # A persistent addon window covers Kodi between full-window transitions.
    import xbmcgui
    backdrop = xbmcgui.WindowXML('anicat_backdrop.xml', _addon_path(), 'Default', '720p')
    try:
        backdrop.show()
        return _show_home_flow()
    finally:
        _hide_loading()
        backdrop.close()


def _show_home_flow():
    """Mostra la HomeWindow i dispara el mode seleccionat."""
    import os
    from resources.lib.ui.windows.home_window import HomeWindow, WINDOW_XML
    p = _addon_path()
    xml_full = os.path.join(p, 'resources', 'skins', 'Default', '720p', WINDOW_XML)
    xbmc.log(f'[AniCat] addon_path={p!r}', xbmc.LOGINFO)
    xbmc.log(f'[AniCat] xml_full={xml_full!r} exists={os.path.exists(xml_full)}', xbmc.LOGINFO)

    handle = int(sys.argv[1])
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

    while True:
        win = HomeWindow(WINDOW_XML, p, 'Default', '720p')
        _show_modal(win)
        result = win.get_result()
        del win

        if not result:
            # Usuari ha tancat la finestra i torna a la pantalla anterior.
            return

        action = result.get('action')
        if action == 'drive_setup':
            from resources.lib.ui.drive_local import show_menu
            show_menu()
            continue
        if action == 'reload_interface':
            from resources.lib.ui.recovery import clear_state
            clear_state()
            # Keep the current router owner while rebuilding the home window.
            import xbmcgui
            xbmcgui.Window(10000).setProperty('AniCat.HomeOpen', 'true')
            continue
        if action == 'watchlist_item':
            _show_loading()
            if open_watchlist_item(result['item']):
                return
            continue
        if action == 'close':
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.sleep(200)
            xbmc.executebuiltin('ActivateWindow(Home)')
            return
        if action == 'settings':
            from resources.lib.ui.drive_local import show_settings_menu
            show_settings_menu()
            continue
        if action in ('pair_device', 'sync_account'):
            from resources.lib.ui import pairing
            if action == 'pair_device':
                pairing.show()
            else:
                pairing.sync_account()
            continue

        # Les funcions de navegació obren la finestra seleccionada o reprodueixen.
        # El directori ja està finalitzat perquè Kodi no mantingui el diàleg de càrrega
        # mentre la interfície personalitzada roman oberta.
        _show_loading()
        if action == 'mode' and _dispatch_mode(result.get('mode')):
            return
        if action == 'play':
            if result.get('content_type') == 'episode':
                from resources.lib.core import progress
                from resources.lib.ui.playback import play_episode_playlist
                episodes = progress.get_episode_playlist(result.get('folder_id', ''))
                selected_index = next((
                    index for index, episode in enumerate(episodes)
                    if episode.get('id') == result.get('file_id')
                ), -1)
                if selected_index >= 0:
                    _hide_loading()
                    if play_episode_playlist(episodes, selected_index):
                        return
            if _play(
                file_id=result.get('file_id'),
                drive_id=result.get('drive_id'),
                content_type=result.get('content_type', 'movie'),
                folder_id=result.get('folder_id', ''),
                folder_name=result.get('folder_name', ''),
                episode_number=result.get('episode_number', 0),
            ):
                return
        if action == 'series' and show_series_detail(
            folder_id=result.get('folder_id'),
            drive_id=result.get('drive_id'),
            folder_name=result.get('folder_name', ''),
            series_title=result.get('series_title', ''),
            series_fanart=result.get('series_fanart', ''),
        ):
            return


def _dispatch_mode(mode):
    """Executa el mode seleccionat a la HomeWindow."""
    if mode == 'continue_watching':
        return show_continue_watching()
    if mode == 'movies':
        return show_movies()
    if mode == 'series':
        return show_series()
    if mode == 'watchlist':
        return show_watchlist()
    if mode == 'drive_config':
        from resources.lib.ui.drive_local import show_menu
        _hide_loading()
        show_menu()
        return False
    xbmc.log(f'[AniCat WindowRouter] mode desconegut: {mode}', xbmc.LOGWARNING)
    return False


# ------------------------------------------------------------------
# SEGUIR VEIENT
# ------------------------------------------------------------------

def show_continue_watching():
    from resources.lib.core.progress import get_continue_watching_items
    from resources.lib.ui.windows.episode_window import EpisodeWindow, WINDOW_XML

    raw = get_continue_watching_items(30)
    if not raw:
        xbmc.executebuiltin('Notification(AniCat,No hi ha contingut en progrés,3000)')
        return

    drive_id = addon.getSetting('series_drive_id') or addon.getSetting('movies_drive_id')

    episodes = []
    for item in raw:
        episodes.append({
            'id':             item['file_id'],
            'name':           item.get('title') or item['file_id'],
            'episode_number': item.get('episode_number', 0),
            'season_number':  0,
            'thumb':          item.get('thumbnail', ''),
            'fanart':         item.get('fanart', ''),
            'resume_time':    item.get('resume_time', 0),
            'total_time':     item.get('total_time', 0),
            'drive_id':       item.get('drive_id') or drive_id,
            'series_id':      item.get('series_id', ''),
            'content_type':   item.get('type', 'episode'),
        })

    win = EpisodeWindow(
        WINDOW_XML, _addon_path(), 'Default', '720p',
        episodes=episodes,
        series_title='Seguir veient',
        subtitle='Reprèn on ho vas deixar',
    )
    _show_modal(win)
    ep = win.get_result()
    del win

    if ep:
        _show_loading()
        return _play(
            file_id=ep['id'],
            drive_id=ep['drive_id'],
            content_type=ep.get('content_type', 'episode'),
            folder_id=ep.get('series_id', ''),
            folder_name=ep.get('name', ''),
            episode_number=ep.get('episode_number', 0),
        )


# ------------------------------------------------------------------
# PEL·LÍCULES
# ------------------------------------------------------------------

def _catalog_metadata(items):
    from resources.lib.core.tmdb_client import enrich_catalog
    _show_loading('Carregant TMDB... Prem Enrere per ometre la cerca.')
    return enrich_catalog(items, cancelled=lambda: bool(_loading_window and _loading_window.cancelled))


def _browse_catalog(items, section_title, open_item):
    """Restore the letter and each row's position when returning from a detail."""
    from resources.lib.ui.windows.catalog_window import CatalogWindow, WINDOW_XML
    state = None
    while True:
        win = CatalogWindow(
            WINDOW_XML, _addon_path(), 'Default', '720p',
            items=items, section_title=section_title, state=state,
        )
        _show_modal(win)
        result, state = win.get_result(), win.get_state()
        del win
        if not result:
            return False
        if result.get('_catalog_refresh'):
            continue
        _show_loading()
        if open_item(result):
            return True


def _open_catalog_movie(result):
    if result['is_folder']:
        return show_movies_subfolder(result['id'], result['drive_id'], result['name'])
    return _play(
        file_id=result['id'], drive_id=result['drive_id'],
        content_type='movie', folder_name=result['name'], folder_id=result.get('parent_id', ''),
    )


def _open_catalog_series(result):
    return show_series_detail(
        folder_id=result['id'], drive_id=result['drive_id'],
        folder_name=result.get('folder_name') or result['name'],
        series_title=result['name'], series_fanart=result.get('fanart', ''),
    )


def show_movies():
    from resources.lib.core import gdrive, progress

    movies_folder_id = addon.getSetting('movies_folder_id')
    movies_drive_id  = addon.getSetting('movies_drive_id')
    if not movies_folder_id:
        xbmc.executebuiltin('Notification(AniCat,Carpeta de pel·lícules no configurada,4000)')
        return

    contents = gdrive.get_folder_contents(movies_folder_id, movies_drive_id)

    items = []
    # Subcarpetes (agrupacions: Shin Chan, Doraemon…)
    for folder in contents['folders']:
        mapping = None
        items.append({
            'id':           folder['id'],
            'name':         folder['name'],
            'display_title': (mapping or {}).get('title', ''),
            'thumb':        (mapping or {}).get('thumb_url') or folder.get('thumbnail', ''),
            'fanart':       (mapping or {}).get('fanart_url', ''),
            'is_folder':    True,
            'drive_id':     movies_drive_id,
            'content_type': 'movies',
            'progress_pct': 0,
            'meta':         (mapping or {}).get('title', folder['name']),
        })
    # Fitxers directes
    for f in contents['files']:
        rt, tt = _get_resume(f['id'])
        pct = int(rt / tt * 100) if tt > 0 else 0
        items.append({
            'id':           f['id'],
            'parent_id':    movies_folder_id,
            'name':         f['name'],
            'thumb':        f.get('thumbnail', ''),
            'fanart':       '',
            'is_folder':    False,
            'drive_id':     movies_drive_id,
            'content_type': 'movie',
            'progress_pct': pct,
            'meta':         '',
        })

    if not items:
        xbmc.executebuiltin('Notification(AniCat,No hi ha pel·lícules,3000)')
        return

    return _browse_catalog(_catalog_metadata(items), 'Pel·lícules', _open_catalog_movie)


def show_movies_subfolder(folder_id, drive_id, folder_name):
    from resources.lib.core import gdrive
    contents = gdrive.get_folder_contents(folder_id, drive_id)
    items = []
    for is_folder, entries in ((True, contents.get('folders', [])), (False, contents.get('files', []))):
        for entry in entries:
            rt, tt = (0, 0) if is_folder else _get_resume(entry['id'])
            items.append({'id': entry['id'], 'name': entry['name'], 'drive_id': drive_id,
                          'parent_id': folder_id, 'is_folder': is_folder,
                          'content_type': 'movies' if is_folder else 'movie',
                          'progress_pct': int(rt / tt * 100) if tt else 0})
    if not items:
        _hide_loading()
        xbmc.executebuiltin('Notification(AniCat,Carpeta buida,3000)')
        return False
    return _browse_catalog(_catalog_metadata(items), folder_name, _open_catalog_movie)


# ------------------------------------------------------------------
# SÈRIES
# ------------------------------------------------------------------

def show_series():
    from resources.lib.core import gdrive, progress

    series_folder_id = addon.getSetting('series_folder_id')
    series_drive_id  = addon.getSetting('series_drive_id')
    if not series_folder_id:
        xbmc.executebuiltin('Notification(AniCat,Carpeta de sèries no configurada,4000)')
        return

    contents = gdrive.get_folder_contents(series_folder_id, series_drive_id)

    items = []
    for folder in contents['folders']:
        mapping = progress.get_series_map(folder['id'])
        items.append({
            'id':           folder['id'],
            'name':         (mapping or {}).get('title') or folder['name'],
            'display_title': (mapping or {}).get('title', ''),
            'thumb':        (mapping or {}).get('thumb_url') or folder.get('thumbnail', ''),
            'fanart':       (mapping or {}).get('fanart_url', ''),
            'is_folder':    True,
            'drive_id':     series_drive_id,
            'content_type': 'series',
            'folder_name':  folder['name'],
            'progress_pct': 0,
            'meta':         (mapping or {}).get('overview', '')[:80] if mapping else '',
        })

    if not items:
        xbmc.executebuiltin('Notification(AniCat,No hi ha sèries,3000)')
        return

    return _browse_catalog(_catalog_metadata(items), 'Sèries', _open_catalog_series)


def show_series_detail(folder_id, drive_id, folder_name, series_title='', series_fanart=''):
    from resources.lib.core import gdrive, progress
    from resources.lib.core.detail_browser import DetailBrowser
    from resources.lib.core.tmdb_client import resolve_metadata
    from resources.lib.ui.windows.detail_window import DetailWindow, WINDOW_XML
    mapping = (resolve_metadata(folder_id, drive_id, folder_name, 'series')
               or progress.get_series_map(folder_id) or {})
    source = {'id': folder_id, 'drive_id': drive_id, 'name': folder_name,
              'display_title': mapping.get('title') or series_title or folder_name,
              'thumb': mapping.get('thumb_url', ''),
              'fanart': mapping.get('fanart_url') or series_fanart,
              'meta': mapping.get('overview', ''), 'tmdb_id': mapping.get('tmdb_id', 0),
              'content_type': 'series', 'is_folder': True}
    browser = DetailBrowser(folder_id, source['display_title'],
                            lambda item_id: gdrive.get_folder_contents(item_id, drive_id))
    def episode_items(view):
        episodes = []
        for ep in view['episodes']:
            state = progress.get_progress_state(ep['id'])
            rt, tt = state['resume_time'], state['total_time']
            episodes.append({'id': ep['id'], 'name': ep.get('episode_title') or ep['name'],
                             'episode_number': ep.get('episode_number', 0),
                             'season_number': ep.get('season_number', 0),
                             'thumb': source['thumb'], 'fanart': source['fanart'],
                             'resume_time': rt, 'total_time': tt, 'drive_id': drive_id,
                             'completed': state['completed'], 'queued': state['queued'],
                             'folder_id': view['options'][view['selected']]['id'],
                             'series_id': folder_id, 'series_name': source['display_title'],
                             'content_type': 'episode'})
        return episodes

    def select_section(index, enter):
        if enter:
            browser.select(index)
        else:
            browser.preview(index)
        view = browser.snapshot()
        return view, episode_items(view)

    view = browser.snapshot()
    win = DetailWindow(WINDOW_XML, _addon_path(), 'Default', '720p', source=source,
                       view=view, episodes=episode_items(view), select_section=select_section)
    _show_modal(win)
    result = win.result
    del win
    if result and result['action'] == 'play':
        from resources.lib.ui.playback import play_episode_playlist
        return play_episode_playlist(result['episodes'], result['index'])
    return False


def _show_episodes_window(episodes_raw, drive_id, series_id, series_title,
                          series_thumb, series_fanart, subtitle=''):
    from resources.lib.core.progress import get_resume_time, get_db_connection
    from resources.lib.ui.windows.episode_window import EpisodeWindow, WINDOW_XML

    episodes = []
    for ep in episodes_raw:
        rt, tt = _get_resume(ep['id'])
        episodes.append({
            'id':             ep['id'],
            'name':           ep.get('episode_title') or ep.get('name', ''),
            'episode_number': ep.get('episode_number', 0),
            'season_number':  ep.get('season_number', 0),
            'thumb':          ep.get('thumbnail') or series_thumb,
            'fanart':         ep.get('fanart') or series_fanart,
            'resume_time':    rt,
            'total_time':     tt,
            'drive_id':       drive_id,
            'series_id':      series_id,
            'content_type':   'episode',
            'series_name':    series_title,
        })

    if not episodes:
        xbmc.executebuiltin('Notification(AniCat,No hi ha episodis,3000)')
        return

    win = EpisodeWindow(
        WINDOW_XML, _addon_path(), 'Default', '720p',
        episodes=episodes,
        series_title=series_title,
        subtitle=subtitle,
    )
    _show_modal(win)
    ep = win.get_result()
    del win

    if ep:
        from resources.lib.ui.playback import play_episode_playlist
        selected_index = episodes.index(ep)
        _show_loading()
        _hide_loading()
        return play_episode_playlist(episodes, selected_index)


# ------------------------------------------------------------------
# WATCHLIST
# ------------------------------------------------------------------

def watchlist_source(row):
    kind = row.get('content_type', 'series')
    return {'id': row['folder_id'], 'name': row.get('source_name') or row['title'],
            'display_title': row['title'], 'folder_name': row.get('source_name') or row['title'],
            'thumb': row.get('thumbnail', ''), 'fanart': row.get('fanart', ''),
            'is_folder': bool(row.get('is_folder', 1)), 'content_type': kind,
            'drive_id': row.get('drive_id') or addon.getSetting('series_drive_id' if kind == 'series' else 'movies_drive_id'),
            'parent_id': row.get('parent_id', '')}


def open_watchlist_item(item):
    return _open_catalog_series(item) if item.get('content_type') == 'series' else _open_catalog_movie(item)


def show_watchlist():
    from resources.lib.core.tmdb_client import get_watchlist_with_metadata
    items = [watchlist_source(row) for row in get_watchlist_with_metadata()]
    if not items:
        _hide_loading()
        return False
    return _browse_catalog(items, 'La meva llista', open_watchlist_item)
