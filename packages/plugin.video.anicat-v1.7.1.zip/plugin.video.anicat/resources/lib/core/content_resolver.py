# -*- coding: utf-8 -*-
"""
Resolución de contenido del Google Drive.
Detecta versiones alternativas (releases) vs carpetas de temporada,
agrupa episodios correctamente y selecciona la versión por defecto.
"""

import xbmc
from resources.lib.core.name_parser import (
    parse_folder_name, parse_episode_filename, natural_sort_key, display_label_for_release
)


def resolve_series_folder(folder_id, drive_id, folder_contents):
    """
    Analiza el contenido de una carpeta de serie y la clasifica.

    Args:
        folder_id   (str): ID de la carpeta en Google Drive
        drive_id    (str): ID del drive
        folder_contents (dict): resultado de gdrive.get_folder_contents()
                                {'folders': [...], 'files': [...]}

    Returns:
        dict:
            releases    (list): versiones alternativas (carpetas con calidad/multi-idioma)
            seasons     (list): carpetas de temporadas
            root_episodes (list): episodios en la raíz
            default_episodes (list): episodios de la versión por defecto (raíz o primera temporada)
            default_version_label (str): etiqueta de la versión por defecto
            has_versions (bool): True si hay múltiples versiones/releases
            has_seasons  (bool): True si hay temporadas detectadas
    """
    subfolders = folder_contents.get('folders', [])
    root_files = folder_contents.get('files', [])

    releases = []
    seasons = []
    unknown_folders = []

    for folder in subfolders:
        parsed = parse_folder_name(folder['name'])
        folder['_parsed'] = parsed

        if parsed['is_season']:
            seasons.append(folder)
        elif parsed['is_release']:
            releases.append(folder)
        else:
            unknown_folders.append(folder)

    # Heurística adicional: si hay subcarpetas sin clasificar y contienen
    # archivos de vídeo con numeración de episodios, tratarlas como temporadas
    for folder in unknown_folders:
        parsed = folder.get('_parsed', {})
        # Si el nombre tiene números solos (T1, S2, etc.) → temporada
        # Si no, comprobar si hay episodios numerados dentro (costoso, no lo hacemos aquí)
        # Por defecto, lo tratamos como release alternativa si no tiene pistas de temporada
        releases.append(folder)

    # Ordenar temporadas numéricamente
    seasons.sort(key=lambda f: f.get('_parsed', {}).get('season_num', 0))

    # Ordenar releases por calidad (mejor primero)
    _quality_order = {'4k': 0, '2160p': 0, '1080p': 1, '720p': 2, '480p': 3, 'sd': 4, '': 5}
    releases.sort(key=lambda f: _quality_order.get(
        f.get('_parsed', {}).get('quality', '').lower(), 5
    ))

    # Enriquecer episodios en raíz con info parseada
    root_episodes = _enrich_episodes(root_files)

    # Determinar versión por defecto
    default_episodes = root_episodes
    default_version_label = 'Versió original'

    if not root_episodes and seasons:
        default_version_label = seasons[0]['name']
        # Los episodios de la primera temporada se cargarán bajo demanda
        default_episodes = []
    elif not root_episodes and releases:
        default_version_label = display_label_for_release(releases[0].get('_parsed', {}))
        default_episodes = []

    xbmc.log(
        f'[AniCat] resolve_series_folder: {len(releases)} releases, '
        f'{len(seasons)} temporadas, {len(root_episodes)} episodios en raíz',
        xbmc.LOGDEBUG
    )

    return {
        'releases': releases,
        'seasons': seasons,
        'root_episodes': root_episodes,
        'default_episodes': default_episodes,
        'default_version_label': default_version_label,
        'has_versions': len(releases) > 0,
        'has_seasons': len(seasons) > 0,
    }


def get_episodes_from_folder(folder_contents):
    """
    Extrae y enriquece episodios de un folder_contents dado.
    Devuelve lista ordenada de episodios con info de episodio parseada.
    """
    files = folder_contents.get('files', [])
    return _enrich_episodes(files)


def _enrich_episodes(files):
    """
    Añade información de episodio parseada a cada archivo.
    Ordena por número de episodio de forma natural.
    """
    enriched = []
    for f in files:
        parsed_ep = parse_episode_filename(f.get('name', ''))
        enriched_file = dict(f)
        enriched_file['_episode'] = parsed_ep
        enriched_file['season_number'] = parsed_ep['season']
        enriched_file['episode_number'] = parsed_ep['episode']
        enriched_file['episode_title'] = parsed_ep['title']
        enriched.append(enriched_file)

    # Ordenar: primero por temporada, luego por episodio, luego natural
    enriched.sort(key=lambda f: (
        f['season_number'],
        f['episode_number'],
        natural_sort_key(f.get('name', ''))
    ))
    return enriched


def build_version_selector_items(resolved):
    """
    Construye la lista de ítems para el diálogo de selección de versión.

    Args:
        resolved (dict): resultado de resolve_series_folder()

    Returns:
        list of dicts: {label, folder_id, folder_name, is_root, quality, languages}
    """
    items = []

    # Versión raíz (si tiene episodios)
    if resolved['root_episodes']:
        items.append({
            'label': 'Versió original (arrel)',
            'folder_id': None,  # None = usar episodios de la raíz
            'folder_name': 'Arrel',
            'is_root': True,
            'quality': '',
            'languages': [],
        })

    # Releases
    for release in resolved['releases']:
        parsed = release.get('_parsed', {})
        items.append({
            'label': display_label_for_release(parsed) or release['name'],
            'folder_id': release['id'],
            'folder_name': release['name'],
            'is_root': False,
            'quality': parsed.get('quality', ''),
            'languages': parsed.get('languages', []),
        })

    return items


def build_season_selector_items(resolved):
    """
    Construye la lista de ítems para el selector de temporada.

    Returns:
        list of dicts: {label, folder_id, season_number}
    """
    items = []
    for season in resolved['seasons']:
        parsed = season.get('_parsed', {})
        items.append({
            'label': season['name'],
            'folder_id': season['id'],
            'season_number': parsed.get('season_num', 0),
        })
    return items
