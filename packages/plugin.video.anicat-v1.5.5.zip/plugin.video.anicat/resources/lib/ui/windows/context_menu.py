# -*- coding: utf-8 -*-
"""Shared, addon-owned contextual dialog."""
import xbmcaddon
import xbmcgui
import xbmcvfs
import os


def icon_path(name):
    path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    return os.path.join(path, 'resources', 'skins', 'Default', 'media', 'hq_action_%s_v2.png' % name)


class ContextMenu(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self._title = kwargs.pop('title', 'AniCat')
        self._options = kwargs.pop('options', [])
        self.result = -1
        super(ContextMenu, self).__init__(*args, **kwargs)

    def onInit(self):
        self.getControl(9010).setLabel(self._title)
        self.getControl(9050).reset()
        items = []
        for option in self._options:
            option = option if isinstance(option, dict) else {'label': option, 'icon': 'search'}
            item = xbmcgui.ListItem(option['label'])
            item.setArt({'icon': icon_path(option.get('icon', 'search'))})
            items.append(item)
        self.getControl(9050).addItems(items)
        self.setFocusId(9050)

    def onAction(self, action):
        if action.getId() in (10, 92, 13):
            self.close()

    def onClick(self, control_id):
        if control_id == 9050:
            self.result = self.getControl(9050).getSelectedPosition()
            self.close()
        elif control_id == 9009:
            self.close()


def choose(options, title='AniCat', owner=None):
    path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    dialog = ContextMenu('anicat_context.xml', path, 'Default', '720p', options=options, title=title)
    global_state = xbmcgui.Window(10000)
    global_state.setProperty('AniCat.ContextMenuOpen', 'true')
    if owner:
        owner.setProperty('ContextMenuOpen', 'true')
    try:
        dialog.doModal()
        return dialog.result
    finally:
        del dialog
        global_state.clearProperty('AniCat.ContextMenuOpen')
        if owner:
            owner.clearProperty('ContextMenuOpen')


def toggle_watchlist(source, title=None):
    from resources.lib.core import progress
    item_id = source['id']
    if progress.is_in_watchlist(item_id):
        return progress.remove_from_watchlist(item_id)
    return progress.add_to_watchlist(
        item_id, source.get('drive_id', ''), title or source.get('display_title') or source['name'],
        source.get('thumb', ''), source.get('fanart', ''), source.get('tmdb_id', 0),
        content_type=source.get('content_type', 'series'),
        is_folder=source.get('is_folder', True), parent_id=source.get('parent_id', ''),
        source_name=source.get('folder_name') or source['name'],
    )


def watchlist_label(item_id):
    from resources.lib.core import progress
    return 'Eliminar de La meva llista' if progress.is_in_watchlist(item_id) else 'Afegir a La meva llista'


def watchlist_option(item_id):
    from resources.lib.core import progress
    exists = progress.is_in_watchlist(item_id)
    return {'label': 'Eliminar de La meva llista' if exists else 'Afegir a La meva llista',
            'icon': 'remove' if exists else 'add'}


def correct_metadata(source, title):
    from resources.lib.core import tmdb_client
    query = xbmcgui.Dialog().input('Cercar a TMDB', defaultt=title).strip()
    if not query:
        return False
    kind = source.get('content_type', 'series')
    kinds = ['movie', 'series'] if kind == 'movies' else ['movie' if kind == 'movie' else 'series']
    results = []
    for media_type in kinds:
        search = tmdb_client.search_movie if media_type == 'movie' else tmdb_client.search_series
        results.extend(dict(item, content_type=media_type) for item in search(query))
    if not results:
        xbmcgui.Dialog().notification('AniCat', 'Sense resultats. Comprova el títol i la configuració de TMDB.')
        return False
    labels = [{'label': '%s · %s · %s' % (item['title'], item.get('year') or '—',
                                         'Pel·lícula' if item['content_type'] == 'movie' else 'Sèrie'),
               'icon': 'search'} for item in results]
    selected = choose(labels, 'Selecciona el títol correcte')
    if selected < 0:
        return False
    tmdb_client.save_manual_metadata(source, results[selected])
    return True
