# -*- coding: utf-8 -*-
# Paquete de recursos para el addon Anicat
