# -*- coding: utf-8 -*-
"""
AniCat ContentWindow — grid de pel·lícules o sèries amb poster cards.
Retorna el folder_id/file_id seleccionat per al router.
"""

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()
_addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))

WINDOW_XML = 'anicat_content.xml'

CTRL_GRID       = 50
CTRL_SECTION    = 10
CTRL_TITLE      = 200
CTRL_META       = 201
CTRL_CLOSE      = 9

# Amplada màxima de la barra de progrés al poster (px, ha de coincidir amb XML width=180)
_PROGRESS_BAR_WIDTH = 180


class ContentWindow(xbmcgui.WindowXML):
    """
    Finestra de grid de contingut (pel·lícules o sèries).

    Args:
        items:        llista de dicts amb claus:
                        id, name, thumb, fanart, progress_pct (0-100),
                        is_folder, drive_id, content_type
        section_title: text per a la capçalera
    """

    def __init__(self, *args, **kwargs):
        self._items        = kwargs.pop('items', [])
        self._section      = kwargs.pop('section_title', 'Contingut')
        self._result       = None
        super(ContentWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.getControl(CTRL_SECTION).setLabel(self._section)
        except Exception:
            pass
        self._populate_grid()
        self.setFocusId(CTRL_GRID)

    def _populate_grid(self):
        grid = self.getControl(CTRL_GRID)
        grid.reset()
        for item in self._items:
            pct = item.get('progress_pct', 0) or 0
            li = xbmcgui.ListItem(item.get('name', ''))
            li.setArt({
                'poster': item.get('thumb', ''),
                'fanart': item.get('fanart', ''),
                'thumb':  item.get('thumb', ''),
            })
            li.setProperty('ProgressWidth', str(int(_PROGRESS_BAR_WIDTH * pct / 100)) if pct > 0 else '0')
            li.setProperty('IsFolder',      '1' if item.get('is_folder') else '0')
            li.setProperty('ItemId',        item.get('id', ''))
            li.setProperty('DriveId',       item.get('drive_id', ''))
            li.setProperty('ContentType',   item.get('content_type', ''))
            grid.addItem(li)

        if self._items:
            self._update_info(0)

    def _update_info(self, index):
        if 0 <= index < len(self._items):
            item = self._items[index]
            try:
                self.getControl(CTRL_TITLE).setLabel(item.get('name', ''))
                meta = item.get('meta', '')
                self.getControl(CTRL_META).setLabel(meta)
            except Exception:
                pass

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_MOVE_LEFT, xbmcgui.ACTION_MOVE_RIGHT,
                         xbmcgui.ACTION_MOVE_UP, xbmcgui.ACTION_MOVE_DOWN,
                         xbmcgui.ACTION_PAGE_UP, xbmcgui.ACTION_PAGE_DOWN):
            try:
                idx = self.getControl(CTRL_GRID).getSelectedPosition()
                self._update_info(idx)
            except Exception:
                pass
        elif action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                           xbmcgui.ACTION_STOP):
            self._result = None
            self.close()

    def onClick(self, control_id):
        if control_id == CTRL_GRID:
            idx = self.getControl(CTRL_GRID).getSelectedPosition()
            if 0 <= idx < len(self._items):
                self._result = self._items[idx]
                self.close()
        elif control_id == CTRL_CLOSE:
            self._result = None
            self.close()

    def get_result(self):
        return self._result


def show_content(items, section_title='Contingut'):
    """
    Mostra la ContentWindow i retorna l'ítem seleccionat o None.
    Exemple: item = show_content(items, 'Sèries')
    """
    win = ContentWindow(
        WINDOW_XML, _addon_path, 'Default', '720p',
        items=items, section_title=section_title,
    )
    win.doModal()
    result = win.get_result()
    del win
    return result
