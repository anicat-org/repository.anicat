# -*- coding: utf-8 -*-
"""
Utilidades para interactuar con Google Drive a través de plugin.googledrive.
Versión limpia y simplificada.
"""

import json
import re
import xbmc
import xbmcaddon
import urllib.parse

addon = xbmcaddon.Addon()


def _jsonrpc(method, params):
    """Wrapper genérico para llamadas JSON-RPC."""
    request = {'jsonrpc': '2.0', 'method': method, 'params': params, 'id': 1}
    response = xbmc.executeJSONRPC(json.dumps(request))
    return json.loads(response)


def _list_directory(plugin_url):
    """
    Llama a Files.GetDirectory para listar el contenido de una URL de plugin.
    Devuelve lista de items o [] en caso de error.
    """
    result = _jsonrpc('Files.GetDirectory', {
        'directory': plugin_url,
        'media': 'files',
        'properties': ['title', 'file', 'thumbnail', 'fanart', 'mimetype', 'size', 'dateadded'],
    })
    if 'error' in result:
        xbmc.log(f'[AniCat] gdrive._list_directory error: {result["error"]} url={plugin_url}', xbmc.LOGWARNING)
        return []
    return result.get('result', {}).get('files', [])


def _build_url(params):
    return 'plugin://plugin.googledrive/?' + urllib.parse.urlencode(params)


def _extract_item_id(url):
    """Extrae item_id de una URL de plugin.googledrive."""
    if not url:
        return ''
    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query)
    for key in ('item_id', 'file_id'):
        if key in qs:
            return qs[key][0]
    # Fallback
    return url.split('=')[-1].split('&')[0]


def _extract_drive_id(url):
    """Extrae driveid de una URL de plugin.googledrive."""
    if not url:
        return ''
    parsed = urllib.parse.urlparse(url)
    qs = urllib.parse.parse_qs(parsed.query)
    for key in ('driveid', 'item_driveid'):
        if key in qs:
            return qs[key][0]
    return ''


_VIDEO_EXTS = {'.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm',
               '.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.m2ts'}


def _clean_name(label):
    """Elimina extensión del nombre de archivo."""
    dot = label.rfind('.')
    if dot > 0 and label[dot:].lower() in _VIDEO_EXTS:
        return label[:dot]
    return label


def _is_video(item):
    mime = item.get('mimetype', '')
    label = item.get('label', '').lower()
    if mime.startswith('video/'):
        return True
    return any(label.endswith(ext) for ext in _VIDEO_EXTS)


def _natural_sort_key(text):
    def _c(t):
        return int(t) if t.isdigit() else t.lower()
    return [_c(p) for p in re.split(r'(\d+)', text)]


# ------------------------------------------------------------------
# API pública
# ------------------------------------------------------------------

def get_drives():
    """
    Lista los drives disponibles en plugin.googledrive.
    Devuelve lista de {id, name, url, thumbnail}.
    """
    items = _list_directory('plugin://plugin.googledrive/')
    drives = []
    for item in items:
        if item.get('filetype') == 'directory':
            url = item.get('file', '')
            drives.append({
                'id': _extract_drive_id(url) or _extract_item_id(url),
                'name': item.get('label', ''),
                'url': url,
                'thumbnail': item.get('thumbnail', ''),
            })
    xbmc.log(f'[AniCat] gdrive.get_drives: {len(drives)} drives', xbmc.LOGINFO)
    return drives


def get_folder_contents(folder_id, drive_id):
    """
    Lista el contenido de una carpeta de Google Drive.
    Devuelve {'folders': [...], 'files': [...]}.

    Cada folder: {id, name, url, thumbnail}
    Cada file:   {id, name, url, thumbnail, fanart, mimetype, size}
    """
    params = {
        'action': '_list_folder',
        'item_id': folder_id,
        'driveid': drive_id,
        'item_driveid': drive_id,
    }
    plugin_url = _build_url(params)
    xbmc.log(f'[AniCat] gdrive.get_folder_contents: {plugin_url}', xbmc.LOGDEBUG)

    items = _list_directory(plugin_url)

    folders = []
    files = []

    for item in items:
        ftype = item.get('filetype', '')
        label = item.get('label', item.get('title', ''))
        url = item.get('file', '')

        if ftype == 'directory':
            folders.append({
                'id': _extract_item_id(url),
                'name': label,
                'url': url,
                'thumbnail': item.get('thumbnail', ''),
            })
        elif ftype == 'file' and _is_video(item):
            files.append({
                'id': _extract_item_id(url),
                'name': _clean_name(label),
                'url': url,
                'thumbnail': item.get('thumbnail', ''),
                'fanart': item.get('fanart', ''),
                'mimetype': item.get('mimetype', ''),
                'size': item.get('size', 0),
            })

    # Ordenamiento natural
    folders.sort(key=lambda x: _natural_sort_key(x['name']))
    files.sort(key=lambda x: _natural_sort_key(x['name']))

    xbmc.log(
        f'[AniCat] gdrive.get_folder_contents: {len(folders)} carpetas, {len(files)} archivos',
        xbmc.LOGDEBUG
    )
    return {'folders': folders, 'files': files}


def build_play_url(file_id, drive_id):
    """Construye la URL de reproducción para plugin.googledrive."""
    params = {
        'action': 'play',
        'content_type': 'video',
        'driveid': drive_id,
        'item_driveid': drive_id,
        'item_id': file_id,
    }
    return _build_url(params)


def find_drive_by_name(name_fragment):
    """
    Busca un drive cuyo nombre contenga name_fragment (case-insensitive).
    Devuelve el primer match o None.
    """
    drives = get_drives()
    fragment_lower = name_fragment.lower()
    for drive in drives:
        if fragment_lower in drive['name'].lower():
            return drive
    return None


def find_subfolder_by_name(folder_id, drive_id, name_candidates):
    """
    Busca una subcarpeta por nombre (lista de candidatos, case-insensitive).
    Devuelve la primera carpeta que coincida o None.
    """
    contents = get_folder_contents(folder_id, drive_id)
    candidates_lower = [c.lower() for c in name_candidates]
    for folder in contents['folders']:
        if folder['name'].lower() in candidates_lower:
            return folder
    return None
