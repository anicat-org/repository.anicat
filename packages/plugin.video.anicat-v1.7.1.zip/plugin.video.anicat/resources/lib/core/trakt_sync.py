# -*- coding: utf-8 -*-
"""
Integración con script.trakt para sincronización de progreso.

script.trakt escucha notificaciones del sistema de Kodi.
Enviamos scrobbles usando xbmc.Player callbacks + JSON-RPC notify.

Referencia: https://github.com/trakt/script.trakt
El addon de Trakt responde a los eventos estándar del Player de Kodi,
así que con un xbmc.Player real los scrobbles deberían funcionar automáticamente.
Este módulo añade la capa explícita de notificación por si Trakt no detecta
el contenido (porque viene de un plugin, no de la biblioteca local de Kodi).
"""

import json
import xbmc
import xbmcaddon

_TRAKT_ADDON_ID = 'script.trakt'
_trakt_available = None  # None = no verificado aún


def _is_trakt_available():
    """Comprueba si script.trakt está instalado y habilitado (con caché)."""
    global _trakt_available
    if _trakt_available is not None:
        return _trakt_available

    try:
        rpc = json.dumps({
            'jsonrpc': '2.0',
            'method': 'Addons.GetAddonDetails',
            'params': {'addonid': _TRAKT_ADDON_ID, 'properties': ['enabled']},
            'id': 1,
        })
        response = json.loads(xbmc.executeJSONRPC(rpc))
        addon_info = response.get('result', {}).get('addon', {})
        _trakt_available = addon_info.get('enabled', False)
    except Exception as e:
        xbmc.log(f'[AniCat] trakt_sync: error detectando Trakt: {e}', xbmc.LOGWARNING)
        _trakt_available = False

    xbmc.log(f'[AniCat] trakt_sync: script.trakt disponible = {_trakt_available}', xbmc.LOGINFO)
    return _trakt_available


def _get_tmdb_id(file_id, file_type='movie', series_id=''):
    """Obtiene el tmdb_id desde el series_map o progress de la BD."""
    try:
        from resources.lib.core import progress
        if file_type == 'episode' and series_id:
            mapping = progress.get_series_map(series_id)
            if mapping:
                return mapping.get('tmdb_id', 0)
        else:
            conn = progress.get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT tmdb_id FROM progress WHERE file_id = ?', (file_id,))
            row = cursor.fetchone()
            conn.close()
            if row:
                return row['tmdb_id'] or 0
    except Exception:
        pass
    return 0


def _notify_trakt(method, data):
    """
    Envía una notificación a script.trakt via JSON-RPC JSONRPC.NotifyAll.
    script.trakt escucha el canal 'AniCat'.
    """
    if not _is_trakt_available():
        return

    try:
        rpc = json.dumps({
            'jsonrpc': '2.0',
            'method': 'JSONRPC.NotifyAll',
            'params': {
                'sender': 'plugin.video.anicat',
                'message': method,
                'data': data,
            },
            'id': 1,
        })
        xbmc.executeJSONRPC(rpc)
        xbmc.log(f'[AniCat] trakt_sync: notificado {method}', xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f'[AniCat] trakt_sync: error notificando {method}: {e}', xbmc.LOGWARNING)


# ------------------------------------------------------------------
# API pública
# ------------------------------------------------------------------

def scrobble_start(file_id, title='', file_type='movie', series_id='',
                   episode_number=0):
    """Notifica a Trakt que se ha iniciado la reproducción."""
    if not _is_trakt_available():
        return

    tmdb_id = _get_tmdb_id(file_id, file_type, series_id)
    data = {
        'type': file_type,
        'tmdb_id': tmdb_id,
        'title': title,
        'episode': episode_number,
        'progress': 0,
    }
    _notify_trakt('scrobble_start', data)
    xbmc.log(f'[AniCat] Trakt scrobble start: {title} (tmdb={tmdb_id})', xbmc.LOGINFO)


def scrobble_progress(file_id, title='', file_type='movie', episode_number=0,
                      progress_pct=0.0):
    """Actualiza el progreso en Trakt (enviado periódicamente)."""
    if not _is_trakt_available():
        return

    # Trakt no necesita actualizaciones muy frecuentes
    _notify_trakt('scrobble_progress', {
        'type': file_type,
        'title': title,
        'episode': episode_number,
        'progress': round(progress_pct, 1),
    })


def scrobble_stop(file_id, title='', file_type='movie', episode_number=0,
                  progress_pct=0.0):
    """Notifica a Trakt que se ha detenido/completado la reproducción."""
    if not _is_trakt_available():
        return

    tmdb_id = _get_tmdb_id(file_id, file_type)
    _notify_trakt('scrobble_stop', {
        'type': file_type,
        'tmdb_id': tmdb_id,
        'title': title,
        'episode': episode_number,
        'progress': round(progress_pct, 1),
    })
    xbmc.log(f'[AniCat] Trakt scrobble stop: {title} @ {progress_pct:.0f}%', xbmc.LOGINFO)


def reset_cache():
    """Fuerza la re-detección de Trakt en el próximo uso."""
    global _trakt_available
    _trakt_available = None
