"""Small local video captures for Continue watching; no decoder dependencies."""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import uuid
import zlib

MAX_ENTRIES = 80
MAX_POSITION_GAP = 25


def cache_directory():
    import xbmcaddon
    import xbmcvfs
    return Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))) / 'resume_frames'


def _key(file_id):
    return hashlib.sha256(file_id.encode('utf-8')).hexdigest()


def _atomic_write(path, data):
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    try:
        temporary.write_bytes(data)
        os.replace(str(temporary), str(path))
    finally:
        if temporary.exists():
            temporary.unlink()


def _png_from_bgra(data, width, height):
    if len(data) != width * height * 4:
        return None
    # Some hardware renderers return black frames instead of capture errors.
    sample = range(0, len(data), max(4, len(data) // 4096 // 4 * 4))
    if sum(max(data[i:i+3]) for i in sample) / len(sample) < 8:
        return None
    rgb = bytearray(width * height * 3)
    rgb[0::3], rgb[1::3], rgb[2::3] = data[2::4], data[1::4], data[0::4]
    rows = b''.join(b'\x00' + rgb[y * width * 3:(y + 1) * width * 3] for y in range(height))
    def chunk(tag, payload):
        return struct.pack('>I', len(payload)) + tag + payload + struct.pack('>I', zlib.crc32(tag + payload) & 0xffffffff)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(rows, 2)) + chunk(b'IEND', b''))


def capture_png(capture):
    ratio = capture.getAspectRatio()
    ratio = ratio if math.isfinite(ratio) and 0.9 <= ratio <= 4 else 16 / 9
    width, height = 480, round(480 / ratio)
    capture.capture(width, height)
    data = capture.getImage(500)
    return _png_from_bgra(data, width, height) if data else None


def save_frame(file_id, position, png, directory=None):
    directory = Path(directory) if directory is not None else cache_directory()
    directory.mkdir(parents=True, exist_ok=True)
    key = _key(file_id)
    filename = key + '.' + uuid.uuid4().hex + '.png'
    _atomic_write(directory / filename, png)
    _atomic_write(directory / (key + '.json'), json.dumps({'position': position, 'image': filename}).encode('utf-8'))
    # A new URL avoids Kodi displaying a previously cached frame of this video.
    for old in directory.glob(key + '.*.png'):
        if old.name != filename:
            old.unlink()
    entries = [p for p in directory.glob('*.json') if re.fullmatch(r'[0-9a-f]{64}\.json', p.name)]
    for old in sorted(entries, key=lambda p: p.stat().st_mtime, reverse=True)[MAX_ENTRIES:]:
        for picture in directory.glob(old.stem + '.*.png'):
            picture.unlink()
        old.unlink()
    return str(directory / filename)


def frame_for_progress(data, directory=None):
    """Reject early, completed and stale frames, including frames before a seek."""
    resume, total = data.get('resume_time') or 0, data.get('total_time') or 0
    if total <= 0 or int(resume / total * 100) <= 1 or data.get('completed') or (data.get('queued') and resume <= 0):
        return ''
    try:
        directory = Path(directory) if directory is not None else cache_directory()
        key = _key(data['file_id'])
        saved = json.loads((directory / (key + '.json')).read_text(encoding='utf-8'))
        if abs(float(saved['position']) - resume) > MAX_POSITION_GAP:
            return ''
        if not re.fullmatch(re.escape(key) + r'\.[0-9a-f]{32}\.png', saved['image']):
            return ''
        image = directory / saved['image']
        return str(image) if image.is_file() else ''
    except (OSError, ValueError, KeyError, TypeError):
        return ''
