# -*- coding: utf-8 -*-
"""Vista "Seguir viendo"."""

import xbmcaddon
import xbmcplugin
from resources.lib.ui.helpers import (
    get_handle, add_directory_item, add_video_item, end_directory,
    set_content, notify_error, build_url,
    context_mark_watched, context_mark_unwatched,
)
from resources.lib.core import progress
from resources.lib.core.gdrive import build_play_url

addon = xbmcaddon.Addon()
_addon_path = addon.getAddonInfo('path')


def show(args):
    handle = get_handle()
    set_content(handle, 'episodes')

    items = progress.get_continue_watching_items(20)

    if not items:
        add_directory_item(
            handle,
            addon.getLocalizedString(30028),
            {'mode': 'dummy'},
            is_folder=False,
        )
        end_directory(handle)
        return

    drive_id = addon.getSetting('series_drive_id') or addon.getSetting('movies_drive_id')

    for item in items:
        pct = item.get('progress_percent', 0)
        ep_num = item.get('episode_number', 0)

        if item['type'] == 'episode' and ep_num > 0:
            label = f'{item["title"]} — Ep. {ep_num} ({pct}%)'
        else:
            label = f'{item["title"]} ({pct}%)'

        info = {
            'title': item['title'],
            'mediatype': item['type'],
            'playcount': 0,
        }
        if item['type'] == 'episode':
            info['episode'] = ep_num
            info['season'] = 0

        play_params = {
            'mode': 'play_video',
            'file_id': item['file_id'],
            'drive_id': drive_id,
            'content_type': item['type'],
        }
        if item.get('series_id'):
            play_params['folder_id'] = item['series_id']

        play_url = build_url(play_params)

        context_menu = [
            context_mark_watched(item['file_id']),
            context_mark_unwatched(item['file_id']),
        ]

        add_video_item(
            handle=handle,
            label=label,
            play_url=play_url,
            thumb=item.get('thumbnail', ''),
            fanart=item.get('fanart', ''),
            info=info,
            context_menu=context_menu,
        )

    end_directory(handle)
