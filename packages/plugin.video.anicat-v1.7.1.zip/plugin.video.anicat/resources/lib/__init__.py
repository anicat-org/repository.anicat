# -*- coding: utf-8 -*-
# Módulo de utilidades para el addon Anicat
