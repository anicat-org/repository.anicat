# -*- coding: utf-8 -*-
"""Configuración de Google Drive."""

import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.ui.helpers import (
    get_handle, add_directory_item, end_directory, notify, notify_error,
)
from resources.lib.core import gdrive

addon = xbmcaddon.Addon()


def show(args):
    handle = get_handle()

    movies_folder_id = addon.getSetting('movies_folder_id')
    series_folder_id = addon.getSetting('series_folder_id')
    is_configured = bool(movies_folder_id and series_folder_id)

    status_label = 'Estat: Configurat ✓' if is_configured else 'Estat: No configurat ✗'
    add_directory_item(handle, status_label, {'mode': 'show_current_config'}, is_folder=False)

    if is_configured:
        add_directory_item(handle, 'Reconfigurar Drive', {'mode': 'setup_drive'}, is_folder=False)
    else:
        add_directory_item(
            handle,
            addon.getLocalizedString(30010),
            {'mode': 'setup_drive'},
            is_folder=False,
        )

    add_directory_item(
        handle,
        addon.getLocalizedString(30013),
        {'mode': 'manual_drive_setup'},
        is_folder=False,
    )
    add_directory_item(
        handle,
        addon.getLocalizedString(30014),
        {'mode': 'settings'},
        is_folder=False,
    )

    add_directory_item(handle, '🔍 Debug: Progress DB', {'mode': 'debug_tracking'}, is_folder=False)
    add_directory_item(handle, '🔍 Debug: Pending Playback', {'mode': 'debug_pending'}, is_folder=False)

    end_directory(handle)


def setup_drive(args):
    """Configuración automática: busca el drive 'Animelliure' y sus carpetas."""
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create('AniCat', 'Configurant Google Drive...')

    try:
        progress_dialog.update(10, 'Obtenint drives disponibles...')
        drives = gdrive.get_drives()

        if not drives:
            progress_dialog.close()
            xbmcgui.Dialog().ok('Error', 'No s\'han trobat drives de Google Drive.')
            return False

        progress_dialog.update(30, 'Cercant drive "Animelliure"...')
        target_drive = gdrive.find_drive_by_name('animelliure')

        if not target_drive:
            progress_dialog.close()
            xbmc.log('[AniCat] Drive "Animelliure" no trobat', xbmc.LOGWARNING)
            drive_names = [f'{d["name"]} ({d["id"]})' for d in drives]
            selected = xbmcgui.Dialog().select(
                'Selecciona el drive',
                drive_names,
            )
            if selected < 0:
                return False
            target_drive = drives[selected]

        progress_dialog.update(50, f'Drive: {target_drive["name"]}')

        progress_dialog.update(70, 'Cercant carpetes Pelis i Sèries...')
        movies_folder = gdrive.find_subfolder_by_name(
            target_drive['id'], target_drive['id'],
            ['pelis', 'películas', 'pelicules', 'movies'],
        )
        series_folder = gdrive.find_subfolder_by_name(
            target_drive['id'], target_drive['id'],
            ['series', 'sèries', 'tv shows', 'shows'],
        )

        progress_dialog.update(90, 'Guardant configuració...')

        if movies_folder:
            addon.setSetting('movies_folder_id', movies_folder['id'])
            addon.setSetting('movies_drive_id', target_drive['id'])

        if series_folder:
            addon.setSetting('series_folder_id', series_folder['id'])
            addon.setSetting('series_drive_id', target_drive['id'])

        progress_dialog.update(100, 'Completat')
        progress_dialog.close()

        msg = f'Drive: {target_drive["name"]}\n'
        msg += f'Pel·lícules: {movies_folder["name"] if movies_folder else "No trobada"}\n'
        msg += f'Sèries: {series_folder["name"] if series_folder else "No trobada"}'
        xbmcgui.Dialog().ok('Configuració completada', msg)
        xbmc.executebuiltin('Container.Refresh')
        return True

    except Exception as e:
        progress_dialog.close()
        xbmc.log(f'[AniCat] Error en setup_drive: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error', f'Error configurant: {e}')
        return False


def show_current_config(args):
    movies_folder_id = addon.getSetting('movies_folder_id')
    series_folder_id = addon.getSetting('series_folder_id')
    movies_drive_id = addon.getSetting('movies_drive_id')
    series_drive_id = addon.getSetting('series_drive_id')

    msg = (
        f'Drive pel·lícules: {movies_drive_id or "—"}\n'
        f'Carpeta pel·lícules: {movies_folder_id or "—"}\n'
        f'Drive sèries: {series_drive_id or "—"}\n'
        f'Carpeta sèries: {series_folder_id or "—"}'
    )
    xbmcgui.Dialog().textviewer('Configuració actual', msg)


def manual_drive_setup(args):
    drives = gdrive.get_drives()
    if not drives:
        xbmcgui.Dialog().ok('Error', 'No s\'han trobat drives.')
        return

    drive_labels = [f'{d["name"]} ({d["id"]})' for d in drives]
    selected = xbmcgui.Dialog().select('Selecciona el drive', drive_labels)
    if selected < 0:
        return

    chosen_drive = drives[selected]
    drive_id = chosen_drive['id']

    # Seleccionar carpeta de películas
    contents = gdrive.get_folder_contents(drive_id, drive_id)
    folder_labels = [f['name'] for f in contents['folders']]

    movies_idx = xbmcgui.Dialog().select('Carpeta de Pel·lícules', folder_labels)
    if movies_idx >= 0:
        addon.setSetting('movies_folder_id', contents['folders'][movies_idx]['id'])
        addon.setSetting('movies_drive_id', drive_id)

    series_idx = xbmcgui.Dialog().select('Carpeta de Sèries', folder_labels)
    if series_idx >= 0:
        addon.setSetting('series_folder_id', contents['folders'][series_idx]['id'])
        addon.setSetting('series_drive_id', drive_id)

    notify('Configuració manual guardada')
    xbmc.executebuiltin('Container.Refresh')
