# Anicat Kodi Addon

Un addon para Kodi que proporciona una interfaz tipo Netflix para el contenido de anime compartido en Google Drive por Anicat.

## Características

- Integración con Google Drive para acceder a contenido compartido
- Navegación por películas y series
- Seguimiento del progreso de visualización
- Sección "Seguir viendo" para continuar donde lo dejaste
- Soporte para múltiples idiomas (Español, Catalán, Inglés)

## Requisitos

- Kodi 21 (Omega) o superior
- Addon de Google Drive para Kodi (`plugin.googledrive`)
- Módulo común de Cloud Drive (`script.module.clouddrive.common`)

## Instalación

1. Asegúrate de tener instalado el addon de Google Drive para Kodi
2. Descarga el archivo ZIP de este addon
3. En Kodi, ve a Ajustes > Addons > Instalar desde archivo ZIP
4. Selecciona el archivo ZIP descargado
5. Configura el addon con los IDs de carpeta de Google Drive para películas y series

## Configuración

Después de instalar el addon, necesitarás configurar los siguientes ajustes:

1. ID de la carpeta de películas en Google Drive
2. ID de la carpeta de series en Google Drive

Puedes encontrar estos IDs en la URL de Google Drive cuando navegas por las carpetas.

## Uso

Una vez configurado, el addon mostrará tres secciones principales:

- **Seguir viendo**: Muestra el contenido que has empezado a ver pero no has terminado
- **Películas**: Muestra todas las películas disponibles en la carpeta configurada
- **Series**: Muestra todas las series disponibles, organizadas por temporadas y episodios

## Desarrollo

### Catálogos personalizados

Películas y series usan `CatalogWindow` y `anicat_catalog_rows.xml`: filas por
inicial, con navegación horizontal entre tarjetas y vertical entre letras.
El índice superior permite saltar a una letra con Aceptar; Abajo vuelve a la
fila activa. Se omiten letras vacías, se normalizan acentos y se agrupan números
y símbolos en `#`. Al regresar del detalle se conserva la selección de cada fila.
El detalle de series muestra carpetas/temporadas/versiones a la izquierda y
episodios a la derecha. Al recorrer el selector cambia el listado de capítulos;
Aceptar entra en una carpeta anidada y la entrada de retorno permite subir un nivel.
La flecha superior vuelve al catálogo; la X de la portada cierra el addon.

El menú contextual del catálogo permite añadir o eliminar de Mi lista y corregir
la asociación con TMDB. Portada y catálogo usan un diálogo personalizado.
Mi lista admite series, carpetas de películas y películas sueltas; las entradas
anteriores se conservan mediante una migración aditiva de SQLite.

Las búsquedas TMDB requieren la clave configurada en los ajustes del addon.
Se distinguen películas y series, se limpian etiquetas de releases y se comparan
títulos y años para evitar asociaciones dudosas. Se cachean aciertos siete días y
fallos una hora; las selecciones manuales se conservan por elemento e idioma.
La primera carga puede tardar mientras consulta TMDB: Enrere permite omitir las
búsquedas pendientes (las peticiones ya enviadas terminan con su timeout).
Las películas sin coincidencia muestran el icono del addon, no fotogramas de Drive.

El XML se genera con `py tools/generate_catalog_layout.py`, que reutiliza los
layouts de póster de la portada. Ejecutarlo solo al cambiar el diseño del catálogo
o incorporar cambios visuales de la portada; no genera imágenes.

### Releases

La versión y las novedades se actualizan en `addon.xml` antes de crear una release.
Hasta confirmar las nuevas funcionalidades, las iteraciones incrementan el último
componente del número de versión (1.5.1, 1.5.2, etc.).
`py tools/build_addon_zip.py` (o `build_addon_zip.bat`) crea el ZIP versionado en
la carpeta superior y reutiliza las imágenes existentes. Tras cambiar el generador
de imágenes o su icono de origen, ejecutar con `--regenerate-assets`.
Los scripts de la carpeta superior delegan en estas herramientas versionadas.

En los contextuales, «Restablir metadades automàtiques» elimina las asociaciones
manuales del elemento (incluidos otros idiomas), limpia sus datos derivados y
vuelve a buscar usando el nombre original. Actualiza también su entrada en Mi lista.
Las carpetas de películas muestran una insignia y, si no encuentran una película
adecuada, buscan imágenes y metadatos de series. Esto no cambia su navegación:
siguen abriendo la carpeta de películas. La selección manual permite elegir ambos tipos.
`generate_context_assets()` regenera únicamente las texturas del menú e iconos;
sus proporciones coinciden con los controles para mantener radios uniformes.

Pruebas sin Kodi: `py -m unittest discover -s tests -v`.
En 1.5.5, Seguir viendo usa una captura del vídeo próxima a la reanudación. El
servicio intenta capturar con `xbmc.RenderCapture` durante el seguimiento (cada
10 segundos aproximadamente) y al pausar. No se extrae un frame después de Stop,
porque el renderizador puede haberse liberado. Con 0–1% visible, sin captura útil
o con una diferencia superior a 25 segundos, se usa el backdrop horizontal TMDB;
si falta, aparece el placeholder horizontal. El fondo general mantiene TMDB.
Las capturas se guardan solo en `profile/resume_frames`, con un máximo de 80 vídeos
y una imagen por fichero. No requieren Pillow/FFmpeg ni peticiones adicionales a
Drive. La captura depende del renderizador de Kodi: errores, imágenes vacías o
negras se descartan. Los progresos anteriores usan TMDB hasta volver a reproducir.
En 1.5.4 se corrigen las alturas del contextual y se ocultan las barras a cero;
las texturas de progreso no dependen de imágenes de gran tamaño. La inserción
del siguiente episodio escribe tiempos cero explícitos para funcionar con el
esquema original sin valores por defecto. Se reparan automáticamente los tiempos
nulos que hubiera dejado 1.5.3, conservando episodios completados y pendientes.
En 1.5.3, el 90% o el final natural marcan un episodio como completado. Se prepara
el siguiente de la misma playlist/carpeta en Seguir viendo, conservando su posición
si ya estaba empezado. No se avanza entre temporadas/versiones ni se reinician
episodios ya completados. Los estados se guardan en SQLite; la migración recupera
los completados antiguos (posición cero con duración conocida). El contextual
de Seguir viendo permite abrir el detalle de la serie. Los episodios sin empezar
no muestran barra y los terminados muestran «Completat».
En 1.5.2, Mi lista reutiliza la caché de TMDB del catálogo (también los resultados
de series para carpetas de películas) sin nuevas consultas de red. El indicador
de reproducción identifica películas que son ficheros directos. Los placeholders
usan fondos adaptados al formato y títulos multilínea. Las texturas del detalle
tienen proporciones propias para conservar sus radios; `generate_polish_assets()`
regenera únicamente estos assets, el placeholder y el panel del loader.
La revisión final en Kodi debe comprobar teclado/mando y ratón, desplazamiento
entre letras, salto desde el índice, retorno desde detalles y reproducción.

Este addon está desarrollado en Python y utiliza la API de Kodi para proporcionar una experiencia de usuario fluida. La estructura del proyecto es la siguiente:

```
anicat-addon/
├─ addon.xml                   # Manifiesto del addon
├─ addon.py                    # Punto de entrada principal
├─ LICENSE.txt                 # Licencia del addon
├─ language/                   # Traducciones
│   ├─ resource.language.en_gb/
│   │   └─ strings.po          # Traducciones en inglés
│   ├─ resource.language.es_es/
│   │   └─ strings.po          # Traducciones en español
│   └─ resource.language.ca_es/
│       └─ strings.po          # Traducciones en catalán
├─ resources/
│   ├─ lib/
│   │   ├─ __init__.py
│   │   ├─ gdrive_utils.py     # Utilidades para interactuar con Google Drive
│   │   └─ progress_tracker.py # Seguimiento del progreso de visualización
│   ├─ media/
│   │   ├─ icon.png            # Icono del addon
│   │   └─ fanart.jpg          # Imagen de fondo
│   └─ settings.xml            # Configuración del addon
└─ README.md                   # Este archivo
```

## Licencia

Este proyecto está licenciado bajo la Licencia MIT.
