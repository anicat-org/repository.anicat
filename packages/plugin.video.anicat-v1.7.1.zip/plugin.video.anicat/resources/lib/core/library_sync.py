"""Offline library cache. The server's per-item revisions arbitrate conflicts."""
import hashlib
import json
import os
import sqlite3
import threading
import tempfile
from contextlib import closing

_lock = threading.Lock()
TABLES = {'progress': 'file_id', 'watchlist': 'folder_id'}


def _session(profile):
    path = os.path.join(profile, 'pairing.db')
    if not os.path.isfile(path):
        return None
    with closing(sqlite3.connect(path, timeout=10)) as db:
        db.row_factory = sqlite3.Row
        columns = {row[1] for row in db.execute('PRAGMA table_info(session)')}
        if 'user_id' not in columns:
            return None
        row = db.execute('SELECT * FROM session WHERE id=1').fetchone()
        return dict(row) if row and row['user_id'] else None


def database_path(legacy):
    session = _session(os.path.dirname(legacy))
    if not session:
        return legacy
    owner = hashlib.sha256((session['host'] + '/' + session['user_id']).encode()).hexdigest()
    path = os.path.join(os.path.dirname(legacy), 'progress-' + owner + '.db')
    if os.path.isfile(path):
        return path
    # Serialize publishers without hard links (unsupported on Android shared storage).
    with closing(sqlite3.connect(legacy + '.init-lock', timeout=10)) as lease:
        lease.execute('BEGIN IMMEDIATE')
        if os.path.isfile(path):
            return path
        fd, temporary = tempfile.mkstemp(prefix='library-', suffix='.db', dir=os.path.dirname(path))
        os.close(fd)
        try:
            with closing(sqlite3.connect(legacy, timeout=10)) as source:
                source.execute('CREATE TABLE IF NOT EXISTS library_owner (id INTEGER PRIMARY KEY, owner TEXT)')
                source.execute('INSERT OR IGNORE INTO library_owner VALUES (1, ?)', (owner,))
                claimed = source.execute('SELECT owner FROM library_owner WHERE id=1').fetchone()[0]
                source.commit()
                with closing(sqlite3.connect(temporary)) as target:
                    source.backup(target)
                    if claimed != owner:
                        for table in ('progress', 'watchlist', 'watchlist_folders', 'pending_playback', 'active_episode_playlist'):
                            if target.execute('SELECT 1 FROM sqlite_master WHERE name=?', (table,)).fetchone():
                                target.execute('DELETE FROM ' + table)
                        target.commit()
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.remove(temporary)
    return path


def _json(data):
    return json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=True) if data is not None else None


def _rows(db):
    return {(table, row[key]): _json(_portable(dict(row))) for table, key in TABLES.items()
            for row in db.execute('SELECT * FROM ' + table)}


def _portable(row):
    numeric = {'resume_time', 'total_time', 'last_played', 'added_date', 'episode_number', 'tmdb_id', 'completed', 'queued', 'is_folder'}
    for key, value in row.items():
        if value is None:
            row[key] = 0 if key in numeric else ''
        elif isinstance(value, str):
            row[key] = value.replace('\r', ' ').replace('\n', ' ').replace('\t', ' ')[:2048]
        if key in ('thumbnail', 'fanart') and not str(row[key]).startswith('https://image.tmdb.org/'):
            # Device-local files and provider URLs with credentials are not portable.
            row[key] = ''
    return row


def _schema(db):
    db.executescript('''
        CREATE TABLE IF NOT EXISTS library_mirror(kind TEXT, item_id TEXT, revision INTEGER, data TEXT, PRIMARY KEY(kind,item_id));
        CREATE TABLE IF NOT EXISTS library_outbox(kind TEXT, item_id TEXT, base INTEGER, data TEXT, PRIMARY KEY(kind,item_id));
        CREATE TABLE IF NOT EXISTS library_cursor(id INTEGER PRIMARY KEY, revision INTEGER);
        INSERT OR IGNORE INTO library_cursor VALUES(1,0);
    ''')


def _apply(db, item):
    table, key = item['kind'], TABLES[item['kind']]
    db.execute('DELETE FROM ' + table + ' WHERE ' + key + '=?', (item['id'],))
    if table == 'watchlist' and db.execute("SELECT 1 FROM sqlite_master WHERE name='watchlist_folders'").fetchone():
        db.execute('DELETE FROM watchlist_folders WHERE folder_id=?', (item['id'],))
    if item['data'] is not None:
        columns = {r[1] for r in db.execute('PRAGMA table_info(' + table + ')')}
        data = item['data']
        if not isinstance(data, dict) or set(data) - columns or data.get(key) != item['id']:
            raise ValueError('Invalid library record')
        names = list(data)
        db.execute('INSERT INTO ' + table + '(' + ','.join(names) + ') VALUES (' + ','.join('?' for _ in names) + ')', [data[n] for n in names])


def exchange(db, request, user_id):
    """One bounded batch; network I/O never holds the progress write lock."""
    _schema(db)
    db.execute('BEGIN IMMEDIATE')
    try:
        snapshot = _rows(db)
        mirrors = {(r['kind'], r['item_id']): r for r in db.execute('SELECT * FROM library_mirror')}
        for key in snapshot.keys() | mirrors.keys():
            value = snapshot.get(key)
            mirror = mirrors.get(key)
            if value != (mirror['data'] if mirror else None):
                # Keep an in-flight operation stable until the server acknowledges it.
                db.execute('INSERT OR IGNORE INTO library_outbox VALUES(?,?,?,?)', (*key, mirror['revision'] if mirror else 0, value))
        pending = list(db.execute('SELECT * FROM library_outbox ORDER BY rowid'))
        changes = []
        for row in pending[:25]:
            change = {'kind': row['kind'], 'id': row['item_id'], 'base': row['base'], 'data': json.loads(row['data']) if row['data'] else None}
            # Stay below the API's existing 16 KiB request limit.
            if changes and len(_json(changes + [change])) > 14000:
                break
            changes.append(change)
        cursor = db.execute('SELECT revision FROM library_cursor WHERE id=1').fetchone()[0]
        db.commit()
    except Exception:
        db.rollback()
        raise
    response = request({'cursor': cursor, 'changes': changes})
    if response.get('version') != 1 or response.get('user_id') != user_id or not isinstance(response.get('cursor'), int) or response['cursor'] < cursor:
        raise ValueError('Invalid library response')
    sent = {(c['kind'], c['id']): c for c in changes}
    db.execute('BEGIN IMMEDIATE')
    try:
        current = _rows(db)
        pending_keys = {(r['kind'], r['item_id']) for r in pending}
        results = response['results']
        if {(r['kind'], r['id']) for r in results} != set(sent):
            raise ValueError('Missing library acknowledgements')
        for item in results + response['changes']:
            key = (item['kind'], item['id'])
            if item['kind'] not in TABLES or not isinstance(item['revision'], int) or item['revision'] <= 0:
                raise ValueError('Invalid library revision')
            previous = db.execute('SELECT revision FROM library_mirror WHERE kind=? AND item_id=?', key).fetchone()
            if previous and previous[0] >= item['revision']:
                continue
            # Edits made while the request was in flight remain local for the next batch.
            expected = _json(sent[key]['data']) if key in sent else snapshot.get(key)
            unchanged = current.get(key) == expected
            if unchanged and (key in sent or key not in pending_keys):
                _apply(db, item)
            db.execute('INSERT OR REPLACE INTO library_mirror VALUES(?,?,?,?)', (*key, item['revision'], _json(item['data'])))
        for key in sent:
            db.execute('DELETE FROM library_outbox WHERE kind=? AND item_id=?', key)
        db.execute('UPDATE library_cursor SET revision=? WHERE id=1', (response['cursor'],))
        db.commit()
    except Exception:
        db.rollback()
        raise
    return response.get('has_more', False) or len(pending) > len(changes)


def sync():
    if not _lock.acquire(False):
        return
    try:
        from resources.lib.core import pairing, progress
        pairing.ensure_library_identity()
        session = _session(os.path.dirname(progress.DB_PATH))
        if not session:
            return
        import time
        if session['expires_at'] <= time.time():
            return
        # get_db_connection selects the account on every call, including in the service.
        path = database_path(progress.DB_PATH)
        lease = sqlite3.connect(path + '.sync-lock', timeout=0)
        try:
            lease.execute('BEGIN IMMEDIATE')
        except sqlite3.OperationalError:
            lease.close()
            return
        db = None
        try:
            db = progress.get_db_connection()
            for _ in range(4):
                more = exchange(db, lambda body: pairing._request(session['host'], '/api/addon/library/sync', body, session['token']), session['user_id'])
                if not more:
                    break
            import xbmcgui
            xbmcgui.Window(10000).setProperty('AniCat.LibraryUpdated', str(time.time()))
        finally:
            if db is not None:
                db.close()
            lease.rollback()
            lease.close()
    finally:
        _lock.release()
