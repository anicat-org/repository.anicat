# -*- coding: utf-8 -*-
"""
Reproductor de AniCat con seguimiento de progreso.
Extiende xbmc.Player para usar callbacks nativos de Kodi.
"""

import json
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui

addon = xbmcaddon.Addon()
ADDON_ID = addon.getAddonInfo('id')


class AniCatPlayer(xbmc.Player):
    """
    Reproductor personalizado que extiende xbmc.Player.
    Usa callbacks nativos para un tracking fiable y sin condiciones de carrera.
    """

    def __init__(self):
        super(AniCatPlayer, self).__init__()
        self._file_id = None
        self._file_type = 'movie'
        self._series_id = ''
        self._season_id = ''
        self._episode_number = 0
        self._title = ''
        self._thumbnail = ''
        self._fanart = ''
        self._monitor = xbmc.Monitor()
        self._tracking_thread = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._last_known_time = 0.0
        self._last_known_total = 0.0
        self._pending_resume = 0.0
        self._restore_token = 0
        self._frame_lock = threading.Lock()
        self._frame_generation = 0

    def prepare_playback(self, file_id, title='', thumbnail='', fanart='',
                         file_type='movie', series_id='', season_id='',
                         episode_number=0):
        """
        Registra la información del archivo antes de iniciar la reproducción.
        Debe llamarse justo antes de player.play().
        """
        with self._lock:
            self._file_id = file_id
            self._title = title
            self._thumbnail = thumbnail
            self._fanart = fanart
            self._file_type = file_type
            self._series_id = series_id
            self._season_id = season_id
            self._episode_number = episode_number

        xbmc.log(
            f'[AniCat] Player preparado: file_id={file_id}, type={file_type}',
            xbmc.LOGINFO
        )

    # ------------------------------------------------------------------
    # Callbacks nativos de xbmc.Player
    # ------------------------------------------------------------------

    def onPlayBackStarted(self):
        # El plugin escriu les dades via propietats de Kodi abans de cridar setResolvedUrl.
        # Llegim aquí perquè el player viu al service (procés diferent del plugin).
        self._cancel_home_restore()
        metadata_loaded = self._read_metadata_from_properties()
        xbmc.log(f'[AniCat] onPlayBackStarted — file_id={self._file_id}', xbmc.LOGINFO)
        if not metadata_loaded:
            xbmc.log('[AniCat] onPlayBackStarted: file_id buit, ignorant', xbmc.LOGWARNING)
            return
        self._register_start()

    def _read_metadata_from_properties(self):
        """
        Llegeix les metadades que el plugin ha escrit a la taula pending_playback (BD).
        Funciona entre processos (plugin → service) perquè SQLite és un arxiu compartit.
        """
        try:
            from resources.lib.core.progress import (
                get_active_episode_playlist,
                read_and_clear_pending_playback,
            )
            pending_data = read_and_clear_pending_playback()
            episodes = get_active_episode_playlist()
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            position = playlist.getposition()
            if len(episodes) == playlist.size() and 0 <= position < len(episodes):
                episode = episodes[position]
                data = {
                    'file_id': episode.get('id', ''),
                    'title': episode.get('name', ''),
                    'thumbnail': episode.get('thumb', ''),
                    'fanart': episode.get('fanart', ''),
                    'file_type': 'episode',
                    'series_id': episode.get('series_id', ''),
                    'season_id': '',
                    'episode_number': episode.get('episode_number', 0),
                    'resume_time': episode.get('resume_time', 0),
                }
            else:
                data = pending_data
        except Exception as e:
            xbmc.log(f'[AniCat] Error llegint metadades de playback: {e}', xbmc.LOGERROR)
            data = None

        if data and data.get('file_id'):
            with self._lock:
                self._frame_generation += 1
                self._file_id        = data['file_id']
                self._title          = data.get('title', '')
                self._file_type      = data.get('file_type', 'movie')
                self._series_id      = data.get('series_id', '')
                self._season_id      = data.get('season_id', '')
                self._episode_number = data.get('episode_number', 0) or 0
                self._thumbnail      = data.get('thumbnail', '')
                self._fanart         = data.get('fanart', '')
                self._pending_resume = data.get('resume_time', 0) or 0
            xbmc.log(
                f'[AniCat] Metadata carregada de BD: {self._file_id} '
                f'type={self._file_type} resume={self._pending_resume:.0f}s',
                xbmc.LOGINFO
            )
            return True

        with self._lock:
            self._file_id = None
            self._pending_resume = 0.0
        xbmc.log('[AniCat] onPlayBackStarted: no hi ha pending_playback a la BD', xbmc.LOGWARNING)
        return False

    def onPlayBackStopped(self):
        xbmc.log(f'[AniCat] onPlayBackStopped — file_id={self._file_id}', xbmc.LOGINFO)
        self._stop_tracking_thread()
        self._save_final_progress()
        self._clear_active_playlist_data()
        self._schedule_home_restore(3.0)

    def onPlayBackEnded(self):
        xbmc.log(f'[AniCat] onPlayBackEnded — file_id={self._file_id}', xbmc.LOGINFO)
        self._stop_tracking_thread()
        self._mark_or_save_on_end()
        if not self._playlist_has_next():
            self._clear_active_playlist_data()
            self._schedule_home_restore(3.0)

    def onAVStarted(self):
        with self._lock:
            resume_to = self._pending_resume
            self._pending_resume = 0.0
        if resume_to > 5:
            try:
                players = json.loads(xbmc.executeJSONRPC(
                    '{"jsonrpc":"2.0","method":"Player.GetActivePlayers","id":1}'
                )).get('result', [])
                player_id = next(
                    player['playerid'] for player in players
                    if player.get('type') == 'video'
                )
                total_ms = int(resume_to * 1000)
                hours, remainder = divmod(total_ms, 3600000)
                minutes, remainder = divmod(remainder, 60000)
                seconds, milliseconds = divmod(remainder, 1000)
                request = {
                    'jsonrpc': '2.0',
                    'method': 'Player.Seek',
                    'params': {
                        'playerid': player_id,
                        'value': {
                            'time': {
                                'hours': hours,
                                'minutes': minutes,
                                'seconds': seconds,
                                'milliseconds': milliseconds,
                            },
                        },
                    },
                    'id': 1,
                }
                response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
                if 'error' in response:
                    raise RuntimeError(response['error'])
                xbmc.log(f'[AniCat] Seek automàtic a {resume_to:.0f}s', xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f'[AniCat] Error en seek: {e}', xbmc.LOGWARNING)
        if self._file_id:
            self._start_tracking_thread()

    def onPlayBackPaused(self):
        xbmc.log(f'[AniCat] onPlayBackPaused — file_id={self._file_id}', xbmc.LOGDEBUG)
        self._save_current_progress()

    def onPlayBackResumed(self):
        xbmc.log(f'[AniCat] onPlayBackResumed — file_id={self._file_id}', xbmc.LOGDEBUG)

    # ------------------------------------------------------------------
    # Lógica interna
    # ------------------------------------------------------------------

    def _clear_active_playlist_data(self):
        try:
            from resources.lib.core.progress import clear_active_episode_playlist
            clear_active_episode_playlist()
        except Exception as e:
            xbmc.log(f'[AniCat] Error limpiando playlist activa: {e}', xbmc.LOGWARNING)

    def _playlist_has_next(self):
        try:
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            position = playlist.getposition()
            return 0 <= position < playlist.size() - 1
        except Exception:
            return False

    def _cancel_home_restore(self):
        with self._lock:
            self._restore_token += 1
        home_state = xbmcgui.Window(10000)
        home_state.clearProperty('AniCat.HomeOpen')
        home_state.clearProperty('AniCat.RestoreInProgress')

    def _schedule_home_restore(self, delay):
        with self._lock:
            self._restore_token += 1
            token = self._restore_token

        def restore_home():
            if self._monitor.waitForAbort(delay):
                return
            with self._lock:
                if token != self._restore_token:
                    return
            try:
                if self.isPlayingVideo():
                    return
            except Exception:
                pass
            home_state = xbmcgui.Window(10000)
            if (
                home_state.getProperty('AniCat.HomeOpen') == 'true'
                or home_state.getProperty('AniCat.RestoreInProgress') == 'true'
            ):
                return
            home_state.setProperty('AniCat.RestoreInProgress', 'true')
            home_state.clearProperty('AniCat.HomeOpen')
            if xbmc.getCondVisibility('Window.IsActive(videos)'):
                xbmc.executebuiltin(
                    'Container.Update(plugin://plugin.video.anicat/?restore=1,replace)'
                )
            else:
                xbmc.executebuiltin(
                    'ActivateWindow(Videos,plugin://plugin.video.anicat/?restore=1)'
                )
            if not self._monitor.waitForAbort(5):
                home_state.clearProperty('AniCat.RestoreInProgress')

        thread = threading.Thread(
            target=restore_home,
            name='AniCatRestoreHome',
            daemon=True,
        )
        thread.start()

    def _register_start(self):
        """Registra el inicio en la BD y en Trakt."""
        try:
            from resources.lib.core import progress
            progress.register_playback_start(
                file_id=self._file_id,
                title=self._title,
                thumbnail=self._thumbnail,
                fanart=self._fanart,
                file_type=self._file_type,
                series_id=self._series_id,
                season_id=self._season_id,
                episode_number=self._episode_number,
            )
        except Exception as e:
            xbmc.log(f'[AniCat] Error en _register_start: {e}', xbmc.LOGERROR)

        # Notificar a Trakt si está disponible
        try:
            from resources.lib.core import trakt_sync
            trakt_sync.scrobble_start(
                file_id=self._file_id,
                title=self._title,
                file_type=self._file_type,
                series_id=self._series_id,
                episode_number=self._episode_number,
            )
        except Exception:
            pass

    def _start_tracking_thread(self):
        """Lanza el hilo de actualización periódica del progreso."""
        with self._lock:
            self._stop_event.clear()
            self._last_known_time = 0.0
            self._last_known_total = 0.0
            if self._tracking_thread and self._tracking_thread.is_alive():
                return
            self._tracking_thread = threading.Thread(
                target=self._tracking_loop,
                name='AniCatTracking',
                daemon=True,
            )
            self._tracking_thread.start()
        xbmc.log('[AniCat] Hilo de tracking iniciado', xbmc.LOGINFO)

    def _stop_tracking_thread(self):
        """Señala al hilo de tracking que debe detenerse inmediatamente."""
        self._stop_event.set()
        thread = self._tracking_thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1)
        self._tracking_thread = None
        xbmc.log('[AniCat] Señal de parada enviada al hilo de tracking', xbmc.LOGINFO)

    def _tracking_loop(self):
        """
        Bucle de actualización periódica del progreso.
        - Espera inicial de 5s per donar temps a plugin.googledrive a resoldre la URL.
        - Actualitza cada 10s usant threading.Event per parada instantània.
        - Guarda l'última posició coneguda per a _save_final_progress.
        """
        UPDATE_INTERVAL = 10
        INITIAL_DELAY   = 5   # esperar que googledrive resolgui i el player tingui temps vàlid

        xbmc.log('[AniCat] Bucle de tracking iniciat, esperant 5s...', xbmc.LOGINFO)

        # Espera inicial — sortir si s'ha demanat aturada o Kodi tanca
        if self._stop_event.wait(INITIAL_DELAY):
            xbmc.log('[AniCat] Tracking aturat durant l\'espera inicial', xbmc.LOGINFO)
            return
        if self._monitor.abortRequested():
            return

        file_id = self._file_id
        xbmc.log(f'[AniCat] Tracking loop actiu per file_id={file_id}', xbmc.LOGINFO)

        while not self._stop_event.is_set() and not self._monitor.abortRequested():
            try:
                if not self.isPlayingVideo():
                    xbmc.log('[AniCat] isPlayingVideo=False, aturant loop', xbmc.LOGINFO)
                    break

                current_time = self.getTime()
                total_time   = self.getTotalTime()

                if current_time > 0 and total_time > 0:
                    with self._lock:
                        self._last_known_time  = current_time
                        self._last_known_total = total_time
                    self._write_progress(file_id, current_time, total_time)
                    self._capture_resume_frame(file_id, current_time, total_time)
                    xbmc.log(
                        f'[AniCat] Progress: {current_time:.0f}s / {total_time:.0f}s '
                        f'({current_time/total_time*100:.1f}%)',
                        xbmc.LOGDEBUG
                    )
            except Exception as e:
                xbmc.log(f'[AniCat] Error en tracking_loop: {e}', xbmc.LOGWARNING)

            # Esperar UPDATE_INTERVAL o fins que es pari
            self._stop_event.wait(UPDATE_INTERVAL)

        xbmc.log('[AniCat] Bucle de tracking finalitzat', xbmc.LOGINFO)

    def _write_progress(self, file_id, current_time, total_time):
        """Escribe el progreso en la BD local y notifica a Trakt."""
        try:
            from resources.lib.core import progress
            progress.update_progress(file_id, current_time, total_time)
        except Exception as e:
            xbmc.log(f'[AniCat] Error escribiendo progreso: {e}', xbmc.LOGWARNING)

        # Scrobble a Trakt (silent)
        try:
            from resources.lib.core import trakt_sync
            pct = (current_time / total_time) * 100
            trakt_sync.scrobble_progress(
                file_id=file_id,
                title=self._title,
                file_type=self._file_type,
                episode_number=self._episode_number,
                progress_pct=pct,
            )
        except Exception:
            pass

    def _save_current_progress(self):
        """Guarda el progreso actual (p.ej. al pausar)."""
        if not self._file_id:
            return
        try:
            current_time = self.getTime()
            total_time = self.getTotalTime()
            if current_time > 0 and total_time > 0:
                self._write_progress(self._file_id, current_time, total_time)
                self._capture_resume_frame(self._file_id, current_time, total_time)
        except Exception as e:
            xbmc.log(f'[AniCat] Error en _save_current_progress: {e}', xbmc.LOGWARNING)

    def _capture_resume_frame(self, file_id, current_time, total_time):
        if total_time <= 0 or not .02 <= current_time / total_time < .90:
            return
        if not self._frame_lock.acquire(False):
            return
        try:
            with self._lock:
                generation = self._frame_generation
            if self._stop_event.is_set() or file_id != self._file_id or not self.isPlayingVideo():
                return
            from resources.lib.core.resume_frames import capture_png, save_frame
            capture = xbmc.RenderCapture()
            try:
                png = capture_png(capture)
            finally:
                del capture
            with self._lock:
                same_video = generation == self._frame_generation and file_id == self._file_id
            if (png and same_video and not self._stop_event.is_set() and self.isPlayingVideo()
                    and abs(self.getTime() - current_time) <= 2):
                save_frame(file_id, current_time, png)
        except Exception as error:
            xbmc.log('[AniCat] Resume frame unavailable: %s' % error, xbmc.LOGDEBUG)
        finally:
            self._frame_lock.release()

    def _get_current_times(self):
        """
        Intenta obtenir posició/durada actuals.
        Si falla (p.ex. reproducció ja acabada), usa l'última posició coneguda.
        """
        try:
            ct = self.getTime()
            tt = self.getTotalTime()
            if ct > 0 and tt > 0:
                return ct, tt
        except Exception:
            pass
        with self._lock:
            return self._last_known_time, self._last_known_total

    def _save_final_progress(self):
        """Guarda la posició en aturar manualment."""
        if not self._file_id:
            return
        try:
            from resources.lib.core import progress
            current_time, total_time = self._get_current_times()
            if current_time > 0 and total_time > 0:
                progress.update_progress(self._file_id, current_time, total_time)
                xbmc.log(
                    f'[AniCat] Progrés final guardat: {current_time:.0f}s/{total_time:.0f}s '
                    f'({current_time/total_time*100:.1f}%)',
                    xbmc.LOGINFO
                )
            else:
                xbmc.log(f'[AniCat] _save_final_progress: temps no disponibles (0/0)', xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log(f'[AniCat] Error en _save_final_progress: {e}', xbmc.LOGWARNING)

    def _mark_or_save_on_end(self):
        """A natural end completes the episode even if the last timer sample was early."""
        if not self._file_id:
            return
        try:
            from resources.lib.core import progress
            if self._file_id:
                progress.mark_as_watched(self._file_id)
                xbmc.log(f'[AniCat] Marcat com a vist: {self._file_id}', xbmc.LOGINFO)
                try:
                    from resources.lib.core import trakt_sync
                    trakt_sync.scrobble_stop(
                        file_id=self._file_id,
                        title=self._title,
                        file_type=self._file_type,
                        episode_number=self._episode_number,
                        progress_pct=100.0,
                    )
                except Exception:
                    pass
        except Exception as e:
            xbmc.log(f'[AniCat] Error en _mark_or_save_on_end: {e}', xbmc.LOGWARNING)


# Instancia global única (reuselanguageinvoker = true → persiste entre llamadas)
anicat_player = AniCatPlayer()
