# -*- coding: utf-8 -*-
"""
Parser de nombres de carpetas y archivos del Google Drive compartido.

Ejemplos reales del Drive de AniCat:
  Carpetas:
    "Bo-Bobo (2003) [cat]"
    "Bo-bobo (1080p) (Cat-Cast-Eng-Jap)"
    "Attack on Titan"
    "Naruto Shippuden - Temporada 2"

  Archivos/episodios:
    "Bo-Bobo -01- El dels pèls vivents, el dels superfuets!.avi"
    "Bobobo 01 (1080p) (Cat-Cast-Eng-Jap) by nchu [F0B44C6D].mkv"
    "One Piece S01E001 - Capítulo 1.mkv"
    "Dragon Ball Z Cap 001.avi"
    "Naruto 001 - Llegada de un ninja.mp4"
"""

import re
import unicodedata


def parse_search_name(raw):
    """Clean release noise without removing sequel numbers or meaningful subtitles."""
    name = unicodedata.normalize('NFKC', raw or '').strip()
    name = re.sub(r'\.(?:mkv|mp4|avi|mov|m4v|wmv|ts|m2ts|webm)$', '', name, flags=re.I)
    name = name.replace('_', ' ')
    # Dotted release names, but retain punctuation in ordinary titles.
    if ' ' not in name and name.count('.') > 1:
        name = name.replace('.', ' ')
    name = re.sub(r'(?<=[A-Za-zÀ-ÿ])\.(?=[A-Za-zÀ-ÿ])', ' ', name)
    year_match = re.search(r'[\[(]((?:19|20)\d{2})[\])]|\b((?:19|20)\d{2})(?=\s+(?:1080|720|2160|480|WEB|BluRay))', name, re.I)
    year = next((part for part in year_match.groups() if part), '') if year_match else ''
    if year_match:
        name = name[:year_match.start()] + ' ' + name[year_match.end():]
    name = re.sub(r'\[[^\]]*\]', ' ', name)
    name = re.sub(r'^\d{1,3}\s*[-.]\s+', '', name)
    technical = r'\b(?:2160p|1080[pi]|720p|480p|4k|x26[45]|h[ .]?26[45]|hevc|avc|10bit|8bit|aac(?:2[.]0)?|ac3|dts|flac|blu[ -]?ray|bdrip|brrip|web[ .-]?(?:dl|rip)|hdtv|dvdrip|dual|multi|remux)\b'
    name = re.sub(technical, ' ', name, flags=re.I)
    langs = r'(?:cat|ca|cast|esp|es|eng|en|jap|jp|ja|catala|català|catalan|castellano|sub|subs)'
    name = re.sub(r'\([^)]*\)', lambda m: ' ' if re.fullmatch(r'[\s,;/+\-]*' + langs + r'(?:[\s,;/+\-]+' + langs + r')*[\s,;/+\-]*', m.group()[1:-1], re.I) or not m.group()[1:-1].strip() else m.group(), name)
    name = re.sub(r'\bby\s+\S+\s*$', '', name, flags=re.I)
    name = re.sub(r'\s+', ' ', name).strip(' ._-')
    queries = [name]
    without_parentheses = re.sub(r'\([^)]*\)', '', name)
    without_parentheses = re.sub(r'\s+', ' ', without_parentheses).strip()
    if without_parentheses and without_parentheses != name:
        queries.append(without_parentheses)
    return {'title': name or (raw or '').strip(), 'year': year, 'queries': [q for q in queries if q]}

# ------------------------------------------------------------------
# Tags de idioma reconocidos
# ------------------------------------------------------------------
_LANG_TAGS = {
    'cat': 'ca', 'ca': 'ca', 'català': 'ca', 'catalan': 'ca',
    'cast': 'es', 'es': 'es', 'esp': 'es', 'español': 'es', 'spanish': 'es',
    'eng': 'en', 'en': 'en', 'english': 'en', 'anglès': 'en',
    'jap': 'ja', 'jp': 'ja', 'japanese': 'ja', 'japonès': 'ja',
    'lat': 'la', 'latino': 'la',
}

# Extensiones de vídeo
_VIDEO_EXTS = {'.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm',
               '.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.m2ts'}

# Patrones de calidad
_QUALITY_RE = re.compile(
    r'\b(4k|2160p|1080p|1080i|720p|720i|480p|480i|sd|hd|fhd|uhd|blu.?ray|dvd|web.?dl|hdtv)\b',
    re.IGNORECASE
)

# Patrones de año: (2003) o [2003]
_YEAR_RE = re.compile(r'[\(\[]((?:19|20)\d{2})[\)\]]')

# Tags en corchetes o paréntesis
_TAG_RE = re.compile(r'[\(\[](.*?)[\)\]]')

# Hash de checksum tipo [F0B44C6D]
_HASH_RE = re.compile(r'\[[0-9A-Fa-f]{6,8}\]')

# Indicador de uploader "by <nombre>"
_UPLOADER_RE = re.compile(r'\bby\s+(\w+)', re.IGNORECASE)

# ------------------------------------------------------------------
# Patrones de episodio (orden: del más específico al más general)
# ------------------------------------------------------------------
_EPISODE_PATTERNS = [
    # S01E01 o S01E001
    re.compile(r'[Ss](\d{1,2})[Ee](\d{1,3})'),
    # 1x01
    re.compile(r'(\d{1,2})x(\d{2,3})'),
    # T1E01 o T01E01
    re.compile(r'[Tt](\d{1,2})[Ee](\d{1,3})'),
    # Temporada X Episodio Y / Capítulo Y
    re.compile(r'[Tt]emporada\s*(\d+)\s*(?:[Ee]pisodio|[Cc]ap(?:ítulo)?)\s*(\d+)', re.IGNORECASE),
    # "- 01 -" o " -01- " (formato Bo-Bobo)
    re.compile(r'\s*-\s*(\d{1,3})\s*-\s*'),
    # "Cap 001" o "Capítol 001" o "Ep 01" o "Episode 01"
    re.compile(r'(?:cap(?:ítulo|ítol|itulo|itol)?|ep(?:isodio|isode)?|episodi)\s*(\d{1,3})', re.IGNORECASE),
    # Número suelto con espacios alrededor (último recurso): " 001 " o " 01 "
    re.compile(r'(?<!\d)\s(\d{1,3})\s(?!\d)'),
    # Número al inicio del nombre: "001 Título"
    re.compile(r'^(\d{1,3})\s'),
    # Número al final antes de la extensión o paréntesis
    re.compile(r'(\d{1,3})(?:\s*[\(\[\.][^\d]|$)'),
]

# Patrones de temporada en nombre de carpeta
_SEASON_FOLDER_PATTERNS = [
    re.compile(r'[Tt]emporada\s*(\d+)', re.IGNORECASE),
    re.compile(r'[Ss]eason\s*(\d+)', re.IGNORECASE),
    re.compile(r'^[Ss](\d{1,2})$'),
    re.compile(r'^[Tt](\d{1,2})$'),
    re.compile(r'[Ss](\d{2})\b'),
]


def _extract_tags(name):
    """Extrae todos los contenidos de paréntesis y corchetes."""
    return _TAG_RE.findall(name)


def _extract_languages(tags):
    """Detecta idiomas en los tags."""
    langs = []
    for tag in tags:
        # Los tags pueden ser "Cat-Cast-Eng-Jap" o "cat" o "català"
        parts = re.split(r'[-,/\s]+', tag)
        for part in parts:
            key = part.lower().strip()
            if key in _LANG_TAGS:
                lang = _LANG_TAGS[key]
                if lang not in langs:
                    langs.append(lang)
    return langs


def _clean_title(name):
    """
    Elimina tags, año, calidad, hash, uploader y extensión del nombre,
    dejando solo el título limpio para búsqueda en TMDB.
    """
    # Eliminar extensión
    for ext in _VIDEO_EXTS:
        if name.lower().endswith(ext):
            name = name[:-len(ext)]
            break

    # Eliminar hash [XXXXXXXX]
    name = _HASH_RE.sub('', name)
    # Eliminar "by uploader"
    name = _UPLOADER_RE.sub('', name)
    # Eliminar todos los contenidos entre () y []
    name = _TAG_RE.sub('', name)
    # Eliminar patrones de episodio
    for pat in _EPISODE_PATTERNS[:5]:  # solo los más agresivos
        name = pat.sub(' ', name)
    # Eliminar guiones múltiples al inicio/final
    name = re.sub(r'^[\s\-_]+|[\s\-_]+$', '', name)
    # Colapsar espacios
    name = re.sub(r'\s{2,}', ' ', name)
    return name.strip()


# ------------------------------------------------------------------
# API pública
# ------------------------------------------------------------------

def parse_folder_name(name):
    """
    Analiza el nombre de una carpeta del Drive.

    Returns:
        dict con:
            title       (str)  — título limpio para búsqueda TMDB
            year        (str)  — año si se detecta, '' si no
            quality     (str)  — '1080p', '720p', etc., '' si no
            languages   (list) — lista de códigos ISO 639-1
            uploader    (str)  — nombre del uploader si se detecta
            is_release  (bool) — True si parece ser una release alternativa
                                 (contiene calidad/idiomas pero no temporada)
            is_season   (bool) — True si parece ser una carpeta de temporada
            season_num  (int)  — número de temporada si is_season es True
            raw         (str)  — nombre original sin modificar
    """
    raw = name
    tags = _extract_tags(name)

    # Año
    year_match = _YEAR_RE.search(name)
    year = year_match.group(1) if year_match else ''

    # Calidad
    quality_match = _QUALITY_RE.search(name)
    quality = quality_match.group(0).lower() if quality_match else ''

    # Idiomas
    languages = _extract_languages(tags)

    # Uploader
    uploader_match = _UPLOADER_RE.search(name)
    uploader = uploader_match.group(1) if uploader_match else ''

    # ¿Es carpeta de temporada?
    is_season = False
    season_num = 0
    for pat in _SEASON_FOLDER_PATTERNS:
        m = pat.search(name)
        if m:
            is_season = True
            season_num = int(m.group(1))
            break

    # ¿Es una release alternativa?
    # Criterio: tiene calidad o múltiples idiomas Y no es una temporada
    has_quality = bool(quality)
    has_multi_lang = len(languages) > 1
    is_release = (has_quality or has_multi_lang) and not is_season

    # Título limpio
    title = _clean_title(name)

    return {
        'title': title,
        'year': year,
        'quality': quality,
        'languages': languages,
        'uploader': uploader,
        'is_release': is_release,
        'is_season': is_season,
        'season_num': season_num,
        'raw': raw,
    }


def parse_episode_filename(filename):
    """
    Extrae información de episodio de un nombre de archivo.

    Returns:
        dict con:
            season      (int)  — número de temporada (0 si no se detecta)
            episode     (int)  — número de episodio (0 si no se detecta)
            title       (str)  — título del episodio (si lo hay)
            raw         (str)  — nombre original sin extensión
    """
    # Eliminar extensión
    name = filename
    for ext in _VIDEO_EXTS:
        if name.lower().endswith(ext):
            name = name[:-len(ext)]
            break

    season = 0
    episode = 0
    ep_title = ''

    # Intentar los patrones en orden
    for pat in _EPISODE_PATTERNS:
        m = pat.search(name)
        if m:
            groups = m.groups()
            if len(groups) == 2:
                season = int(groups[0])
                episode = int(groups[1])
            elif len(groups) == 1:
                episode = int(groups[0])

            # Extraer título: lo que queda después del match
            ep_title = name[m.end():].strip()
            ep_title = re.sub(r'^[\s\-_]+', '', ep_title)
            # Limpiar tags del título
            ep_title = _TAG_RE.sub('', ep_title).strip()
            break

    # Si no se extrajo título, usar el nombre limpio
    if not ep_title:
        ep_title = _clean_title(name)

    return {
        'season': season,
        'episode': episode,
        'title': ep_title,
        'raw': filename,
    }


def natural_sort_key(text):
    """Clave de ordenamiento natural (números como enteros)."""
    def _convert(part):
        return int(part) if part.isdigit() else part.lower()
    return [_convert(p) for p in re.split(r'(\d+)', text)]


def display_label_for_release(parsed_folder):
    """
    Genera una etiqueta legible para mostrar en el selector de versiones.
    Ej: "1080p · Català, Castellà, Anglès, Japonès · nchu"
    """
    parts = []
    if parsed_folder.get('quality'):
        parts.append(parsed_folder['quality'].upper())

    lang_map = {'ca': 'Català', 'es': 'Castellà', 'en': 'Anglès',
                'ja': 'Japonès', 'la': 'Llatí/Llatinoamèricà'}
    if parsed_folder.get('languages'):
        lang_labels = [lang_map.get(l, l.upper()) for l in parsed_folder['languages']]
        parts.append(', '.join(lang_labels))

    if parsed_folder.get('uploader'):
        parts.append(f'by {parsed_folder["uploader"]}')

    return ' · '.join(parts) if parts else parsed_folder.get('raw', 'Versió per defecte')
