# -*- coding: utf-8 -*-
"""Alphabetical catalog; each letter owns an independent horizontal row."""

import os
import string

import xbmcgui
import xbmcaddon
import xbmcvfs

from resources.lib.catalog_utils import group_by_initial
from resources.lib.core.name_parser import parse_folder_name
from resources.lib.ui.windows.card_art import set_card_art, is_direct_movie

WINDOW_XML = 'anicat_catalog_rows.xml'
LETTERS = '#' + string.ascii_uppercase
CTRL_ALPHABET = 50
CTRL_BACK = 9
ROW_BASE = 100
ADDON_PATH = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
DEFAULT_POSTER = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
DEFAULT_FANART = os.path.join(ADDON_PATH, 'resources', 'media', 'fanart.jpg')


def catalog_groups(items):
    cards = []
    for source in items:
        raw = source.get('name', '')
        title = source.get('display_title') or parse_folder_name(raw)['title'] or raw
        cards.append({'name': title, 'source': source})
    grouped = group_by_initial(cards)
    return [(letter, grouped[letter]) for letter in LETTERS if letter in grouped]


class CatalogWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        self._groups = catalog_groups(kwargs.pop('items', []))
        self._section = kwargs.pop('section_title', '')
        self._state = kwargs.pop('state', None) or {}
        self._result = None
        self._rows = {}
        self._active_row = self._state.get('row', ROW_BASE)
        super(CatalogWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        self._result = None
        self.setProperty('CatalogSection', self._section)
        self.setProperty('SelectedFanart', DEFAULT_FANART)
        alphabet = self.getControl(CTRL_ALPHABET)
        alphabet.reset()
        self._rows = {}
        for slot in range(len(LETTERS)):
            self.clearProperty('CatalogRow%d' % slot)
        for slot, (letter, cards) in enumerate(self._groups):
            control_id = ROW_BASE + slot
            self._rows[control_id] = cards
            self.setProperty('CatalogRow%d' % slot, '%s · %d' % (letter, len(cards)))
            alphabet.addItem(xbmcgui.ListItem(letter))
            row = self.getControl(control_id)
            row.reset()
            entries = []
            for card in cards:
                source = card['source']
                item = xbmcgui.ListItem(card['name'])
                set_card_art(item, source.get('thumb'), source.get('fanart'))
                item.setProperty('IsDirectMovie', 'true' if is_direct_movie(source) else '')
                item.setProperty('Subtitle', source.get('meta') or '')
                item.setProperty('IsMovieFolder', 'true' if source.get('is_folder') and source.get('content_type') == 'movies' else '')
                percent = max(0, min(100, int(source.get('progress_pct') or 0)))
                item.setProperty('Progress', str(percent))
                item.getVideoInfoTag().setResumePoint(float(percent), 100.0)
                entries.append(item)
            row.addItems(entries)
            saved = self._state.get('positions', {}).get(control_id, 0)
            row.selectItem(max(0, min(saved, len(cards) - 1)))
        row_ids = list(self._rows)
        for index, control_id in enumerate(row_ids):
            row = self.getControl(control_id)
            row.controlUp(self.getControl(row_ids[index - 1] if index else CTRL_ALPHABET))
            row.controlDown(self.getControl(row_ids[index + 1] if index + 1 < len(row_ids) else CTRL_ALPHABET))
        if self._active_row not in self._rows:
            self._active_row = row_ids[0] if row_ids else CTRL_BACK
        alphabet.controlDown(self.getControl(self._active_row))
        if row_ids:
            alphabet.selectItem(row_ids.index(self._active_row))
        self.setFocusId(self._active_row)
        self._update_selection()

    def _update_selection(self):
        control_id = self.getFocusId()
        if control_id not in self._rows:
            return
        self._active_row = control_id
        item = self.getControl(control_id).getSelectedItem()
        if item:
            self.setProperty('SelectedTitle', item.getLabel())
            self.setProperty('SelectedSubtitle', item.getProperty('Subtitle'))
            self.setProperty('SelectedFanart', item.getArt('fanart') or DEFAULT_FANART)
        self.getControl(CTRL_ALPHABET).controlDown(self.getControl(control_id))
        self.getControl(CTRL_ALPHABET).selectItem(control_id - ROW_BASE)

    def onFocus(self, control_id):
        self._update_selection()

    def onAction(self, action):
        if action.getId() == 117:
            control_id = self.getFocusId()
            if control_id in self._rows:
                from resources.lib.ui.windows.context_menu import choose, toggle_watchlist, watchlist_option, correct_metadata
                from resources.lib.core.tmdb_client import has_manual_metadata, reset_manual_metadata
                card = self._rows[control_id][self.getControl(control_id).getSelectedPosition()]
                options = [watchlist_option(card['source']['id']),
                           {'label': 'Corregir metadades de TMDB', 'icon': 'edit'}]
                if has_manual_metadata(card['source']):
                    options.append({'label': 'Restablir metadades automàtiques', 'icon': 'reset'})
                choice = choose(options, card['name'], owner=self)
                if choice == 0:
                    if not toggle_watchlist(card['source'], card['name']):
                        xbmcgui.Dialog().notification('AniCat', 'No s’ha pogut actualitzar la llista')
                elif choice == 1 and correct_metadata(card['source'], card['name']):
                    self._result = {'_catalog_refresh': True}
                    self.close()
                elif choice == 2:
                    reset_manual_metadata(card['source'])
                    self._result = {'_catalog_refresh': True}
                    self.close()
            return
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                              xbmcgui.ACTION_STOP):
            self.close()
            return
        self._update_selection()

    def onClick(self, control_id):
        if control_id == CTRL_BACK:
            self.close()
        elif control_id == CTRL_ALPHABET:
            slot = self.getControl(CTRL_ALPHABET).getSelectedPosition()
            if ROW_BASE + slot in self._rows:
                self.setFocusId(ROW_BASE + slot)
                self._update_selection()
        elif control_id in self._rows:
            position = self.getControl(control_id).getSelectedPosition()
            if 0 <= position < len(self._rows[control_id]):
                self._result = self._rows[control_id][position]['source']
                self.close()

    def get_result(self):
        return self._result

    def close(self):
        self._state = {
            'row': self._active_row,
            'positions': {control_id: self.getControl(control_id).getSelectedPosition()
                          for control_id in self._rows},
        }
        super(CatalogWindow, self).close()

    def get_state(self):
        return self._state
