# -*- coding: utf-8 -*-
"""Vistas de series: lista de series, temporadas, versiones, episodios."""

import threading
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.ui.helpers import (
    get_handle, add_directory_item, add_video_item, end_directory,
    set_content, notify_error, build_url,
    context_mark_watched, context_mark_unwatched, context_add_watchlist,
)
from resources.lib.core import progress, gdrive
from resources.lib.core.content_resolver import (
    resolve_series_folder, get_episodes_from_folder,
    build_version_selector_items, build_season_selector_items,
)
addon = xbmcaddon.Addon()


def _fetch_tmdb_async(folder_id, drive_id, folder_name):
    """Fetch TMDB metadata en segon pla sense bloquejar."""
    try:
        from resources.lib.core.tmdb_client import resolve_and_cache_series
        resolve_and_cache_series(folder_id, drive_id, folder_name)
    except Exception:
        pass


# ------------------------------------------------------------------
# Lista de series
# ------------------------------------------------------------------

def show_series_list(args):
    handle = get_handle()
    set_content(handle, 'tvshows')

    series_folder_id = addon.getSetting('series_folder_id')
    series_drive_id = addon.getSetting('series_drive_id')

    if not series_folder_id:
        notify_error('La carpeta de sèries no està configurada')
        end_directory(handle)
        return

    contents = gdrive.get_folder_contents(series_folder_id, series_drive_id)

    for folder in contents['folders']:
        # Usar només caché existent — mai crides HTTP síncrones durant el llistat
        mapping = progress.get_series_map(folder['id'])
        if not mapping:
            threading.Thread(
                target=_fetch_tmdb_async,
                args=(folder['id'], series_drive_id, folder['name']),
                daemon=True,
            ).start()

        thumb = (mapping or {}).get('thumb_url') or folder.get('thumbnail', '')
        fanart = (mapping or {}).get('fanart_url') or ''
        display_title = (mapping or {}).get('title') or folder['name']

        info = {'title': display_title, 'mediatype': 'tvshow'}

        context_menu = [
            context_add_watchlist(folder['id'], series_drive_id, folder['name']),
        ]

        add_directory_item(
            handle,
            display_title,
            {
                'mode': 'series_detail',
                'folder_id': folder['id'],
                'drive_id': series_drive_id,
                'folder_name': folder['name'],
            },
            thumb=thumb,
            fanart=fanart,
            is_folder=True,
        )

    end_directory(handle)


# ------------------------------------------------------------------
# Detalle de serie (versiones + temporadas + episodios raíz)
# ------------------------------------------------------------------

def show_series_detail(args):
    """
    Muestra el contenido de una carpeta de serie.
    Puede mostrar:
      - Versiones alternativas (releases)
      - Temporadas
      - Episodios directos (si están en la raíz)
    """
    handle = get_handle()
    set_content(handle, 'episodes')

    folder_id = args.get('folder_id', [None])[0]
    drive_id = args.get('drive_id', [None])[0]
    folder_name = args.get('folder_name', [''])[0]

    if not folder_id or not drive_id:
        notify_error('Paràmetres invàlids')
        end_directory(handle)
        return

    contents = gdrive.get_folder_contents(folder_id, drive_id)
    resolved = resolve_series_folder(folder_id, drive_id, contents)

    mapping = progress.get_series_map(folder_id)
    series_thumb  = (mapping or {}).get('thumb_url', '')
    series_fanart = (mapping or {}).get('fanart_url', '')
    series_name   = (mapping or {}).get('title', '') or folder_name

    # Opción de añadir a watchlist
    add_directory_item(
        handle,
        '+ ' + (addon.getLocalizedString(30022) % folder_name if '%s' in addon.getLocalizedString(30022) else 'Afegir a Veure més tard'),
        {
            'mode': 'add_to_watchlist',
            'folder_id': folder_id,
            'drive_id': drive_id,
            'folder_name': folder_name,
        },
        is_folder=False,
    )

    # Selector de versiones (si hay)
    if resolved['has_versions']:
        version_items = build_version_selector_items(resolved)
        for vi in version_items:
            if vi['is_root']:
                label = '📂 ' + vi['label']
                params = {
                    'mode': 'series_episodes',
                    'folder_id': folder_id,
                    'drive_id': drive_id,
                    'use_root': '1',
                    'series_id': folder_id,
                    'folder_name': series_name,
                }
            else:
                label = '🎬 ' + vi['label']
                params = {
                    'mode': 'series_episodes',
                    'folder_id': vi['folder_id'],
                    'drive_id': drive_id,
                    'series_id': folder_id,
                    'version_label': vi['label'],
                    'folder_name': series_name,
                }
            add_directory_item(
                handle, label, params,
                thumb=series_thumb, fanart=series_fanart, is_folder=True,
            )

    # Selector de temporadas (si hay)
    if resolved['has_seasons']:
        season_items = build_season_selector_items(resolved)
        for si in season_items:
            add_directory_item(
                handle,
                si['label'],
                {
                    'mode': 'series_episodes',
                    'folder_id': si['folder_id'],
                    'drive_id': drive_id,
                    'series_id': folder_id,
                    'season_number': str(si['season_number']),
                    'folder_name': series_name,
                },
                thumb=series_thumb,
                fanart=series_fanart,
                is_folder=True,
            )

    # Episodios en la raíz (si no hay versiones ni temporadas, o además de ellas)
    if resolved['root_episodes'] and not resolved['has_versions'] and not resolved['has_seasons']:
        _render_episodes(handle, resolved['root_episodes'], drive_id, folder_id,
                         series_thumb, series_fanart, series_name)

    end_directory(handle)


# ------------------------------------------------------------------
# Lista de episodios de una carpeta concreta
# ------------------------------------------------------------------

def show_episodes(args):
    """
    Muestra los episodios de una carpeta (temporada, versión o raíz).
    """
    handle = get_handle()
    set_content(handle, 'episodes')

    folder_id   = args.get('folder_id', [None])[0]
    drive_id    = args.get('drive_id', [None])[0]
    series_id   = args.get('series_id', [folder_id])[0]
    folder_name = args.get('folder_name', [''])[0] or ''
    use_root    = args.get('use_root', ['0'])[0] == '1'

    if not folder_id or not drive_id:
        notify_error('Paràmetres invàlids')
        end_directory(handle)
        return

    contents = gdrive.get_folder_contents(folder_id, drive_id)

    if use_root:
        # Usar episodios de la raíz de la carpeta padre (series_id)
        parent_contents = gdrive.get_folder_contents(series_id or folder_id, drive_id)
        episodes = get_episodes_from_folder(parent_contents)
    else:
        episodes = get_episodes_from_folder(contents)

    # Si no hay episodios directos pero sí subcarpetas, mostrar las subcarpetas
    if not episodes and contents['folders']:
        resolved = resolve_series_folder(folder_id, drive_id, contents)
        mapping = progress.get_series_map(series_id or folder_id)
        series_thumb = (mapping or {}).get('thumb_url', '')
        series_fanart = (mapping or {}).get('fanart_url', '')

        if resolved['has_seasons']:
            for si in build_season_selector_items(resolved):
                add_directory_item(
                    handle, si['label'],
                    {
                        'mode': 'series_episodes',
                        'folder_id': si['folder_id'],
                        'drive_id': drive_id,
                        'series_id': series_id or folder_id,
                    },
                    thumb=series_thumb, fanart=series_fanart, is_folder=True,
                )
        else:
            for sub in contents['folders']:
                add_directory_item(
                    handle, sub['name'],
                    {
                        'mode': 'series_episodes',
                        'folder_id': sub['id'],
                        'drive_id': drive_id,
                        'series_id': series_id or folder_id,
                    },
                    thumb=series_thumb, fanart=series_fanart, is_folder=True,
                )
        end_directory(handle)
        return

    mapping = progress.get_series_map(series_id or folder_id)
    series_thumb  = (mapping or {}).get('thumb_url', '')
    series_fanart = (mapping or {}).get('fanart_url', '')
    series_name   = (mapping or {}).get('title', '') or folder_name

    _render_episodes(handle, episodes, drive_id, series_id or folder_id,
                     series_thumb, series_fanart, series_name)
    end_directory(handle)


def _render_episodes(handle, episodes, drive_id, series_id, series_thumb, series_fanart, series_name=''):
    """Renderiza la lista de episodios."""
    for ep in episodes:
        ep_num = ep.get('episode_number', 0)
        season_num = ep.get('season_number', 0)
        ep_title = ep.get('episode_title', ep['name'])

        if ep_num > 0:
            if season_num > 0:
                label = f'S{season_num:02d}E{ep_num:02d} — {ep_title}'
            else:
                label = f'Ep. {ep_num:02d} — {ep_title}'
        else:
            label = ep['name']

        resume_time = progress.get_resume_time(ep['id'])
        play_url = build_url({
            'mode': 'play_video',
            'file_id': ep['id'],
            'drive_id': drive_id,
            'content_type': 'episode',
            'folder_id': series_id,
            'folder_name': series_name,
            'episode_number': ep_num,
            'season_number': season_num,
        })

        info = {
            'title': ep_title,
            'episode': ep_num,
            'season': season_num,
            'mediatype': 'episode',
        }

        context_menu = [
            context_mark_watched(ep['id']),
            context_mark_unwatched(ep['id']),
        ]

        add_video_item(
            handle=handle,
            label=label,
            play_url=play_url,
            thumb=ep.get('thumbnail') or series_thumb,
            fanart=ep.get('fanart') or series_fanart,
            info=info,
            context_menu=context_menu,
        )
