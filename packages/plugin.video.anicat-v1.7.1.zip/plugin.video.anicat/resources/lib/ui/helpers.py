# -*- coding: utf-8 -*-
"""
Helpers compartidos de UI: construcción de list items, URLs, etc.
"""

import os
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

addon = xbmcaddon.Addon()
_addon_path = addon.getAddonInfo('path')
_addon_name = addon.getAddonInfo('name')

_DEFAULT_THUMB = os.path.join(_addon_path, 'resources', 'media', 'icon.png')
_DEFAULT_FANART = os.path.join(_addon_path, 'resources', 'media', 'fanart.jpg')


def get_handle():
    return int(sys.argv[1])


def build_url(params):
    return sys.argv[0] + '?' + urllib.parse.urlencode(params)


def end_directory(handle, succeeded=True, cache_to_disk=True):
    xbmcplugin.endOfDirectory(handle, succeeded=succeeded, cacheToDisc=cache_to_disk)


def add_directory_item(handle, label, params, thumb='', fanart='', is_folder=True,
                       info=None, properties=None, context_menu=None):
    """Añade un ítem de directorio al handle actual."""
    url = build_url(params)
    li = xbmcgui.ListItem(label)
    li.setArt({
        'thumb': thumb or _DEFAULT_THUMB,
        'fanart': fanart or _DEFAULT_FANART,
    })
    if info:
        li.setInfo('video', info)
    if properties:
        for key, val in properties.items():
            li.setProperty(key, str(val))
    if context_menu:
        li.addContextMenuItems(context_menu)
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=is_folder)


def add_video_item(handle, label, play_url, thumb='', fanart='', info=None,
                   resume_time=0, total_time=0, context_menu=None, properties=None):
    """Añade un ítem reproducible al handle actual."""
    li = xbmcgui.ListItem(label)
    li.setArt({
        'thumb': thumb or _DEFAULT_THUMB,
        'fanart': fanart or _DEFAULT_FANART,
    })
    li.setProperty('IsPlayable', 'true')

    if info:
        li.setInfo('video', info)

    if resume_time > 0:
        li.setProperty('ResumeTime', str(resume_time))
        li.setProperty('TotalTime', str(total_time) if total_time > 0 else '1')

    if properties:
        for key, val in properties.items():
            li.setProperty(key, str(val))

    if context_menu:
        li.addContextMenuItems(context_menu)

    xbmcplugin.addDirectoryItem(handle=handle, url=play_url, listitem=li, isFolder=False)


def set_content(handle, content_type):
    """Define el tipo de contenido (episodes, movies, tvshows...)."""
    xbmcplugin.setContent(handle, content_type)


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, duration=3000):
    xbmcgui.Dialog().notification(_addon_name, message, icon, duration)


def notify_error(message):
    notify(message, xbmcgui.NOTIFICATION_ERROR, 4000)


def context_mark_watched(file_id):
    return (
        addon.getLocalizedString(30200),
        f'RunPlugin({sys.argv[0]}?mode=mark_watched&file_id={file_id})'
    )


def context_mark_unwatched(file_id):
    return (
        addon.getLocalizedString(30201),
        f'RunPlugin({sys.argv[0]}?mode=mark_unwatched&file_id={file_id})'
    )


def context_add_watchlist(folder_id, drive_id, folder_name):
    label = addon.getLocalizedString(30022) % folder_name if '%s' in addon.getLocalizedString(30022) else 'Afegir a Veure més tard'
    return (
        label,
        f'RunPlugin({sys.argv[0]}?mode=add_to_watchlist&folder_id={folder_id}&drive_id={drive_id}&folder_name={urllib.parse.quote(folder_name)})'
    )


def context_remove_watchlist(folder_id):
    label = addon.getLocalizedString(30026) if addon.getLocalizedString(30026) else 'Eliminar de Veure més tard'
    return (
        label,
        f'RunPlugin({sys.argv[0]}?mode=remove_from_watchlist&folder_id={folder_id})'
    )
