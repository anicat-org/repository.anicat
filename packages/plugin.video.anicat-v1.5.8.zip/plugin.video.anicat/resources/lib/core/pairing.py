import ipaddress
import json
import os
import re
import sqlite3
import time
from contextlib import contextmanager
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

import xbmcaddon
import xbmcvfs


DEFAULT_HOST = 'https://ani.cat'
ACCOUNT_ID = 'anicat-linked-device'
SETTINGS = ('tmdb_api_key', 'tmdb_language', 'movies_folder_id', 'movies_drive_id',
            'series_folder_id', 'series_drive_id')
_REFRESH_MARGIN = 1200
_MAX_RESPONSE = 1024 * 1024


class PairingError(Exception):
    def __init__(self, message, status=0, code=''):
        super().__init__(message)
        self.status = status
        self.code = code


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def normalize_host(value):
    try:
        value = (value or DEFAULT_HOST).strip()
        parsed = urlsplit(value)
        hostname = parsed.hostname
        port = parsed.port
        if (parsed.scheme not in ('http', 'https') or not hostname or parsed.username is not None
                or parsed.password is not None or parsed.path not in ('', '/') or parsed.query
                or parsed.fragment or '?' in value or '#' in value
                or re.search(r'[\s\\\x00-\x1f\x7f]', value)):
            raise ValueError()
        if parsed.scheme == 'http':
            local = hostname.lower() == 'localhost'
            if not local:
                address = ipaddress.ip_address(hostname)
                networks = ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', 'fc00::/7')
                local = address.is_loopback or any(address in ipaddress.ip_network(n) for n in networks)
            if not local:
                raise ValueError()
        authority = '[%s]' % hostname if ':' in hostname else hostname
        if port is not None:
            authority += ':%d' % port
        return '%s://%s' % (parsed.scheme, authority.lower())
    except (AttributeError, TypeError, ValueError):
        raise PairingError('Host incorrecte. Utilitza HTTPS o HTTP amb localhost/IP privada per a proves.') from None


def verification_url(host):
    host = normalize_host(host)
    # Only this known public API origin has a separate AniCAT website.
    # Never trust a server-provided verification URL or forward its query string.
    if host in ('https://api.ani.cat', 'https://api.ani.cat:443'):
        host = 'https://ani.cat'
    return host + '/dashboard?pair=1'


def _request(host, path, data=None, token=None):
    host = normalize_host(host)
    if path not in ('/api/pairing/start', '/api/pairing/token', '/api/addon/config', '/api/addon/drive-token'):
        raise PairingError('Ruta API incorrecta.')
    headers = {'Accept': 'application/json', 'Cache-Control': 'no-store'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = None
    if data is not None:
        headers['Content-Type'] = 'application/json'
        body = json.dumps(data).encode('utf-8')
    # Keep the saved origin authoritative: changing the settings does not migrate
    # an existing bearer token. Local and legacy hosts retain their /api prefix.
    public_path = path[4:] if host in ('https://api.ani.cat', 'https://api.ani.cat:443') else path
    request = Request(host + public_path, data=body, headers=headers)
    try:
        with build_opener(_NoRedirect()).open(request, timeout=15) as response:
            raw = response.read(_MAX_RESPONSE + 1)
            if len(raw) > _MAX_RESPONSE:
                raise ValueError()
            result = json.loads(raw)
            if not isinstance(result, dict):
                raise ValueError()
            return result
    except HTTPError as error:
        status = error.code
        try:
            result = json.loads(error.read(_MAX_RESPONSE))
            code = result.get('error', '') if isinstance(result, dict) else ''
        except (ValueError, OSError):
            code = ''
        finally:
            error.close()
        allowed = {'authorization_pending', 'slow_down', 'expired_token'}
        code = code if code in allowed else ''
        message = {
            400: 'Revisa la vinculació i el compte Google al dashboard.',
            401: 'Autorització caducada o revocada. Torna a vincular Kodi.',
            403: 'Accés no autoritzat.',
            428: 'Esperant autorització al dashboard.',
            429: 'Massa peticions. Espera abans de tornar-ho a provar.',
        }.get(status, 'El servidor Ani.cat no està disponible o la seva resposta és incorrecta.')
        raise PairingError(message, status, code) from None
    except (URLError, OSError, TimeoutError):
        raise PairingError('No es pot connectar amb Ani.cat. Revisa el host i la xarxa.', code='network_error') from None
    except (ValueError, TypeError):
        raise PairingError('Resposta API incorrecta. Comprova l’adreça del servidor AniCAT.') from None


def _matches(value, pattern):
    return isinstance(value, str) and re.fullmatch(pattern, value) is not None


def begin_pairing(host, name):
    host = normalize_host(host)
    if not isinstance(name, str) or not 1 <= len(name.strip()) <= 80:
        raise PairingError('El nom del dispositiu ha de tenir entre 1 i 80 caràcters.')
    result = _request(host, '/api/pairing/start', {'name': name.strip()})
    if (not _matches(result.get('device_code'), r'[a-f0-9]{64}')
            or not _matches(result.get('user_code'), r'[A-F0-9]{4}-[A-F0-9]{4}')
            or type(result.get('expires_in')) is not int or not 1 <= result['expires_in'] <= 3600
            or type(result.get('interval')) is not int or not 1 <= result['interval'] <= 60):
        raise PairingError('Resposta de vinculació incorrecta.')
    return dict(result, verification_uri=verification_url(host), interval=max(5, result['interval']))


def poll_pairing(host, device_code):
    if not _matches(device_code, r'[a-f0-9]{64}'):
        raise PairingError('Codi de dispositiu incorrecte.')
    return _request(host, '/api/pairing/token', {'device_code': device_code})


def _database_path():
    return os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'pairing.db')


@contextmanager
def _database():
    db = None
    try:
        path = _database_path()
        os.makedirs(os.path.dirname(path), mode=0o700, exist_ok=True)
        db = sqlite3.connect(path, timeout=20)
        if os.name != 'nt':
            os.chmod(path, 0o600)
        db.row_factory = sqlite3.Row
        db.execute('CREATE TABLE IF NOT EXISTS session (id INTEGER PRIMARY KEY CHECK (id = 1), host TEXT NOT NULL, token TEXT NOT NULL, device_id TEXT NOT NULL, expires_at REAL NOT NULL)')
        db.execute('BEGIN IMMEDIATE')
        with db:
            yield db
    except (sqlite3.Error, OSError):
        raise PairingError('No es pot desar la vinculació al perfil de Kodi.') from None
    finally:
        if db is not None:
            db.close()


def is_linked():
    if not os.path.exists(_database_path()):
        return False
    with _database() as db:
        return db.execute('SELECT 1 FROM session WHERE id = 1').fetchone() is not None


def _session(db):
    session = db.execute('SELECT * FROM session WHERE id = 1').fetchone()
    if not session:
        raise PairingError('Vincula primer aquest Kodi amb Ani.cat.')
    if session['expires_at'] <= time.time():
        raise PairingError('Autorització caducada. Torna a vincular Kodi.', 401)
    return session


def complete_pairing(host, token_payload):
    if (not isinstance(token_payload, dict)
            or not _matches(token_payload.get('access_token'), r'[a-f0-9]{64}')
            or not _matches(token_payload.get('device_id'), r'[a-f0-9]{32}')
            or token_payload.get('token_type') != 'Bearer'
            or type(token_payload.get('expires_in')) is not int
            or not 0 < token_payload['expires_in'] <= 7776000):
        raise PairingError('Resposta d’autorització incorrecta.')
    with _database() as db:
        db.execute('INSERT OR REPLACE INTO session VALUES (1, ?, ?, ?, ?)',
                   (normalize_host(host), token_payload['access_token'], token_payload['device_id'],
                    time.time() + token_payload['expires_in']))
    return sync_config()


def _validated_settings(config):
    if not isinstance(config, dict) or config.get('version') != 1 or not isinstance(config.get('settings'), dict):
        raise PairingError('Versió de configuració no compatible.')
    settings = {}
    for key in SETTINGS:
        value = config['settings'].get(key, '')
        pattern = r'(?:[a-fA-F0-9]{32})?' if key == 'tmdb_api_key' else (
            r'[a-z]{2}-[A-Z]{2}' if key == 'tmdb_language' else r'[a-zA-Z0-9_-]{0,200}')
        if not _matches(value, pattern):
            raise PairingError('La configuració rebuda conté valors incorrectes.')
        settings[key] = value
    if not isinstance(config.get('drive'), dict) or config['drive'].get('connected') is not True:
        raise PairingError('Connecta Google Drive al dashboard abans de sincronitzar Kodi.')
    return settings


def _account_manager():
    try:
        from clouddrive.common.account import AccountManager
        drive = xbmcaddon.Addon('plugin.googledrive')
        return AccountManager(xbmcvfs.translatePath(drive.getAddonInfo('profile')))
    except Exception:
        raise PairingError('Cal instal·lar i activar plugin.googledrive i Cloud Drive Common.') from None


def _drive_account(session, payload):
    identity = payload.get('account', {})
    drives = payload.get('drives', [])
    if (not isinstance(identity, dict) or not _matches(identity.get('id'), r'[a-zA-Z0-9_-]{1,200}')
            or not isinstance(drives, list) or not drives
            or not _matches(payload.get('access_token'), r'[A-Za-z0-9._~+/=-]{1,8192}')
            or type(payload.get('expires_in')) is not int or not _REFRESH_MARGIN < payload['expires_in'] <= 86400):
        raise PairingError('Resposta de Google Drive incorrecta. Actualitza el backend Ani.cat.')
    cleaned = []
    for drive in drives:
        if (not isinstance(drive, dict) or not _matches(drive.get('id'), r'[a-zA-Z0-9_-]{1,200}')
                or not isinstance(drive.get('name'), str) or drive.get('type') not in ('', 'drive#drive', 'drive#teamDrive')):
            raise PairingError('Unitats de Google Drive incorrectes.')
        cleaned.append({key: drive[key] for key in ('id', 'name', 'type')})
    if identity['id'] not in {drive['id'] for drive in cleaned}:
        raise PairingError('Falta la unitat personal de Google Drive.')
    return {'id': ACCOUNT_ID, 'name': 'AniCAT · ' + str(identity.get('name') or identity['id']),
            'drives': cleaned, 'anicat_managed': True, 'anicat_google_id': identity['id'],
            'anicat_host': session['host'], 'anicat_device_id': session['device_id'],
            'access_tokens': {'access_token': payload['access_token'], 'refresh_token': '',
                              'expires_in': payload['expires_in'], 'date': time.time()}}


def _import_account(manager, account, required):
    accounts = manager.get_accounts()
    current = accounts.get(ACCOUNT_ID)
    if current and current.get('anicat_managed') is not True:
        raise PairingError('Ja existeix un compte amb el nom intern reservat per AniCAT.')
    used = {drive['id'] for key, existing in accounts.items() if key != ACCOUNT_ID
            for drive in existing.get('drives', [])}
    if used.intersection(required):
        raise PairingError('Una unitat seleccionada ja pertany a un altre compte de plugin.googledrive. '
                           'No s’ha sobreescrit. Utilitza la configuració manual o resol el duplicat al plugin Google Drive i torna a sincronitzar.')
    account['drives'] = [drive for drive in account['drives'] if drive['id'] not in used]
    if not set(required).issubset({drive['id'] for drive in account['drives']}):
        raise PairingError('El compte Google no té alguna de les unitats configurades al dashboard.')
    if not account['drives']:
        raise PairingError('Les unitats d’aquest compte ja estan configurades a Google Drive.')
    _save_account(manager, account)


def _save_account(manager, account):
    manager.save_account(account)
    saved = manager.get_accounts().get(ACCOUNT_ID)
    if saved != account:
        raise PairingError('Google Drive no ha pogut desar el compte. Torna a sincronitzar.')


def sync_config():
    try:
        with _database() as db:
            session = _session(db)
            config = _request(session['host'], '/api/addon/config', token=session['token'])
            settings = _validated_settings(config)
            payload = _request(session['host'], '/api/addon/drive-token', {}, session['token'])
            account = _drive_account(session, payload)
            for kind in ('movies', 'series'):
                if not settings[kind + '_drive_id']:
                    settings[kind + '_drive_id'] = account['anicat_google_id']
            required = {settings[kind + '_drive_id'] for kind in ('movies', 'series')
                        if settings[kind + '_folder_id']}
            _import_account(_account_manager(), account, required)
            addon = xbmcaddon.Addon()
            for key, value in settings.items():
                addon.setSetting(key, value)
            return config
    except PairingError:
        raise
    except Exception:
        raise PairingError('No s’ha pogut aplicar la configuració. Torna a sincronitzar des del menú Ani.cat.') from None


def ensure_drive_access(drive_id=None):
    if not is_linked():
        return
    try:
        with _database() as db:
            manager = _account_manager()
            account = manager.get_accounts().get(ACCOUNT_ID)
            if not account or account.get('anicat_managed') is not True:
                return
            if drive_id is not None and drive_id not in {drive['id'] for drive in account['drives']}:
                return
            session = _session(db)
            if (account.get('anicat_host') != session['host']
                    or account.get('anicat_device_id') != session['device_id']):
                raise PairingError('La nova vinculació encara no s’ha aplicat. Torna a sincronitzar el compte AniCAT.')
            tokens = account.get('access_tokens', {})
            if tokens.get('date', 0) + tokens.get('expires_in', 0) - _REFRESH_MARGIN > time.time():
                return
            payload = _request(session['host'], '/api/addon/drive-token', {}, session['token'])
            updated = _drive_account(session, payload)
            if updated['anicat_google_id'] != account.get('anicat_google_id'):
                raise PairingError('El compte Google ha canviat. Sincronitza la configuració des del menú Ani.cat.')
            account['access_tokens'] = updated['access_tokens']
            _save_account(manager, account)
    except PairingError:
        raise
    except Exception:
        raise PairingError('No s’ha pogut actualitzar l’accés a Google Drive.') from None
