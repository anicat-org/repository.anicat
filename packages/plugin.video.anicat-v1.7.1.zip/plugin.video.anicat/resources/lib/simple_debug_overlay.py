# -*- coding: utf-8 -*-
"""
Overlay de prueba simplificado que usa un método diferente para mostrar información.
Usa notificaciones más frecuentes y diálogos no modales para debugging.
"""

import xbmc
import xbmcgui
import xbmcaddon
import time
import threading

class SimpleDebugOverlay:
    """Overlay simplificado para debugging que no bloquea la interfaz."""
    
    def __init__(self):
        self.enabled = False
        self.visible = False
        self.update_thread = None
        self.monitor = xbmc.Monitor()
        
        # Configuración
        self.addon = xbmcaddon.Addon()
        self.addon_name = self.addon.getAddonInfo('name')
        
        # Estado actual
        self.current_file_id = None
        self.tracking_active = False
        self.current_time = 0
        self.total_time = 0
        self.update_count = 0
        self.errors = []
        
        xbmc.log(f"[{self.addon_name}] SimpleDebugOverlay inicializada", xbmc.LOGINFO)
    
    def show_overlay(self, file_id=None):
        """Activa el modo overlay simplificado."""
        self.enabled = True
        self.current_file_id = file_id
        self.tracking_active = True
        
        xbmc.log(f"[{self.addon_name}] Modo overlay simplificado activado", xbmc.LOGINFO)
        
        # Iniciar thread de monitoreo si no está corriendo
        if not self.update_thread or not self.update_thread.is_alive():
            self.update_thread = threading.Thread(target=self._monitor_loop)
            self.update_thread.daemon = True
            self.update_thread.start()
        
        # Notificación inicial
        xbmcgui.Dialog().notification(
            self.addon_name,
            "Modo overlay ACTIVADO (Simplificado)",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
    
    def hide_overlay(self):
        """Desactiva el modo overlay simplificado."""
        self.enabled = False
        self.visible = False
        self.tracking_active = False
        
        xbmc.log(f"[{self.addon_name}] Modo overlay simplificado desactivado", xbmc.LOGINFO)
        
        xbmcgui.Dialog().notification(
            self.addon_name,
            "Modo overlay DESACTIVADO (Simplificado)",
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
    
    def _monitor_loop(self):
        """Bucle de monitoreo simplificado."""
        xbmc.log(f"[{self.addon_name}] Iniciando bucle de monitoreo simplificado", xbmc.LOGINFO)
        
        monitor = xbmc.Monitor()
        notification_counter = 0
        last_db_save = time.time()
        loop_count = 0
        
        while self.enabled and not monitor.abortRequested():
            try:
                loop_count += 1
                xbmc.log(f"[{self.addon_name}] Bucle #{loop_count} - enabled: {self.enabled}", xbmc.LOGDEBUG)
                
                # Verificar si hay reproducción activa
                player = xbmc.Player()
                is_playing = player.isPlayingVideo()
                
                xbmc.log(f"[{self.addon_name}] Reproducción activa: {is_playing}", xbmc.LOGDEBUG)
                
                if is_playing and self.enabled:
                    self.tracking_active = True
                    
                    # Obtener file_id real si no tenemos uno válido
                    self._extract_current_file_id()
                    
                    # Obtener tiempo de reproducción actual
                    try:
                        self.current_time = player.getTime()
                        self.total_time = player.getTotalTime()
                    except:
                        # Si el método directo falla, intentar con JSON-RPC
                        try:
                            json_query = '''
                            {
                                "jsonrpc": "2.0",
                                "method": "Player.GetProperties",
                                "params": {"playerid": 1, "properties": ["time", "totaltime"]},
                                "id": 1
                            }
                            '''
                            response = xbmc.executeJSONRPC(json_query)
                            data = xbmc.getJSON(response)
                            if 'result' in data:
                                time_data = data['result'].get('time', {})
                                totaltime_data = data['result'].get('totaltime', {})
                                self.current_time = time_data.get('hours', 0) * 3600 + time_data.get('minutes', 0) * 60 + time_data.get('seconds', 0)
                                self.total_time = totaltime_data.get('hours', 0) * 3600 + totaltime_data.get('minutes', 0) * 60 + totaltime_data.get('seconds', 0)
                                xbmc.log(f"[{self.addon_name}] Tiempo actualizado via JSON-RPC: {self._format_time(self.current_time)}/{self._format_time(self.total_time)}", xbmc.LOGDEBUG)
                        except Exception as e:
                            xbmc.log(f"[{self.addon_name}] Error obteniendo tiempo via JSON-RPC: {e}", xbmc.LOGERROR)
                    
                    # Guardar en base de datos cada 5 segundos
                    current_time = time.time()
                    if current_time - last_db_save >= 5:
                        self._save_progress_to_db()
                        last_db_save = current_time
                    
                    # Mostrar diálogo detallado cada 40 actualizaciones (cada ~20 segundos)
                    notification_counter += 1
                    if notification_counter % 40 == 0:  # Cada ~20 segundos
                        self._show_detailed_dialog()
                    
                else:
                    # No hay reproducción
                    self.tracking_active = False
                    if is_playing == False:
                        xbmc.log(f"[{self.addon_name}] No hay reproducción activa", xbmc.LOGDEBUG)
                
                # Esperar antes de próxima verificación
                if monitor.waitForAbort(0.5):
                    xbmc.log(f"[{self.addon_name}] Monitor abortado", xbmc.LOGINFO)
                    break
                    
            except Exception as loop_error:
                xbmc.log(f"[{self.addon_name}] Error en bucle principal #{loop_count}: {loop_error}", xbmc.LOGERROR)
                self.errors.append(f"Loop error #{loop_count}: {loop_error}")
                
                # Si hay demasiados errores, desactivar la overlay
                if len(self.errors) > 10:
                    xbmc.log(f"[{self.addon_name}] Demasiados errores, desactivando overlay", xbmc.LOGWARNING)
                    self.enabled = False
                    break
                
                # Esperar antes de continuar para evitar bucles de errores rápidos
                monitor.waitForAbort(1.0)
        
        xbmc.log(f"[{self.addon_name}] Bucle de monitoreo simplificado finalizado después de {loop_count} iteraciones", xbmc.LOGINFO)
    
    def _extract_current_file_id(self):
        """Extrae el file_id del video actualmente en reproducción."""
        try:
            player = xbmc.Player()
            playing_file = player.getPlayingFile()
            xbmc.log(f"[{self.addon_name}] Archivo actual en reproducción: {playing_file}", xbmc.LOGINFO)
            
            # Método 1: JSON-RPC - El método más fiable
            try:
                json_query = '''
                {
                    "jsonrpc": "2.0",
                    "method": "Player.GetItem",
                    "params": {"playerid": 1, "properties": ["file"]},
                    "id": 1
                }
                '''
                response = xbmc.executeJSONRPC(json_query)
                data = xbmc.getJSON(response)
                xbmc.log(f"[{self.addon_name}] JSON-RPC response completo: {data}", xbmc.LOGDEBUG)
                
                if 'result' in data and 'item' in data['result']:
                    item = data['result']['item']
                    file_path = item.get('file', '')
                    
                    xbmc.log(f"[{self.addon_name}] File path desde JSON-RPC: {file_path}", xbmc.LOGINFO)
                    
                    # Extraer item_id de la URL del plugin
                    if 'plugin.googledrive' in file_path and 'item_id=' in file_path:
                        import urllib.parse as urlparse
                        parsed = urlparse.urlparse(file_path)
                        query_params = urlparse.parse_qs(parsed.query)
                        
                        xbmc.log(f"[{self.addon_name}] Query params encontrados: {list(query_params.keys())}", xbmc.LOGDEBUG)
                        
                        if 'item_id' in query_params:
                            file_id = query_params['item_id'][0]
                            xbmc.log(f"[{self.addon_name}] File ID crudo extraído: {file_id}", xbmc.LOGINFO)
                            
                            # Verificar que no sea un ID de prueba
                            if not any(pattern in file_id for pattern in ['test_', 'overlay_', 'test_file_', 'overlay_mode_']):
                                self.current_file_id = file_id
                                xbmc.log(f"[{self.addon_name}] File ID REAL extraído: {file_id}", xbmc.LOGINFO)
                                return
                            else:
                                xbmc.log(f"[{self.addon_name}] File ID es de prueba, ignorando: {file_id}", xbmc.LOGWARNING)
                        else:
                            xbmc.log(f"[{self.addon_name}] No se encontró item_id en query params", xbmc.LOGWARNING)
                    else:
                        xbmc.log(f"[{self.addon_name}] No es plugin.googledrive o no tiene item_id: {file_path}", xbmc.LOGWARNING)
                else:
                    xbmc.log(f"[{self.addon_name}] No se obtuvo item del JSON-RPC", xbmc.LOGWARNING)
                    
            except Exception as e:
                xbmc.log(f"[{self.addon_name}] Error con JSON-RPC: {e}", xbmc.LOGERROR)
            
            # Método 2: Extraer directamente del playing_file
            if 'plugin.googledrive' in playing_file and 'item_id=' in playing_file:
                import urllib.parse as urlparse
                parsed = urlparse.urlparse(playing_file)
                query_params = urlparse.parse_qs(parsed.query)
                
                if 'item_id' in query_params:
                    file_id = query_params['item_id'][0]
                    xbmc.log(f"[{self.addon_name}] File ID extraído de playing_file: {file_id}", xbmc.LOGINFO)
                    
                    if not any(pattern in file_id for pattern in ['test_', 'overlay_', 'test_file_', 'overlay_mode_']):
                        self.current_file_id = file_id
                        xbmc.log(f"[{self.addon_name}] File ID REAL desde playing_file: {file_id}", xbmc.LOGINFO)
                        return
                    else:
                        xbmc.log(f"[{self.addon_name}] File ID de prueba desde playing_file: {file_id}", xbmc.LOGWARNING)
            
            # Si no se encuentra, mantener el actual pero registrar el intento
            xbmc.log(f"[{self.addon_name}] No se pudo extraer file_id real, manteniendo: {self.current_file_id}", xbmc.LOGWARNING)
            xbmc.log(f"[{self.addon_name}] Métodos intentados: JSON-RPC, playing_file directo", xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error extrayendo file_id: {e}", xbmc.LOGERROR)
    
    def _save_progress_to_db(self):
        """Guarda el progreso actual en la base de datos."""
        try:
            if not self.current_file_id or 'overlay_mode_' in self.current_file_id:
                xbmc.log(f"[{self.addon_name}] No se guarda progreso: file_id no válido ({self.current_file_id})", xbmc.LOGWARNING)
                return
            
            if self.total_time <= 0:
                xbmc.log(f"[{self.addon_name}] No se guarda progreso: total_time inválido ({self.total_time})", xbmc.LOGWARNING)
                return
            
            # Importar progress_tracker
            from resources.lib import progress_tracker
            import datetime
            
            # Calcular progreso
            progress_percent = (self.current_time / self.total_time) * 100
            
            # Registrar el inicio de la reproducción si es la primera vez
            try:
                # Verificar si el registro ya existe
                conn = progress_tracker.get_db_connection()
                cursor = conn.cursor()
                cursor.execute('SELECT file_id FROM progress WHERE file_id = ?', (self.current_file_id,))
                exists = cursor.fetchone()
                
                if not exists:
                    # Crear registro inicial
                    cursor.execute('''
                        INSERT INTO progress 
                        (file_id, title, current_time, total_time, progress_percent, last_played, watch_count, type)
                        VALUES (?, ?, ?, ?, ?, ?, 1, 'video')
                    ''', (
                        self.current_file_id,
                        f'Video {self.current_file_id[:20]}...',  # Título genérico
                        self.current_time,
                        self.total_time,
                        progress_percent,
                        datetime.datetime.now().isoformat()
                    ))
                    xbmc.log(f"[{self.addon_name}] Registro inicial creado en BD: {self.current_file_id}", xbmc.LOGINFO)
                else:
                    # Actualizar registro existente
                    cursor.execute('''
                        UPDATE progress 
                        SET current_time = ?, total_time = ?, progress_percent = ?, last_played = ?
                        WHERE file_id = ?
                    ''', (
                        self.current_time,
                        self.total_time,
                        progress_percent,
                        datetime.datetime.now().isoformat(),
                        self.current_file_id
                    ))
                    xbmc.log(f"[{self.addon_name}] Registro actualizado en BD: {self.current_file_id}", xbmc.LOGINFO)
                
                conn.commit()
                conn.close()
                
            except Exception as db_error:
                xbmc.log(f"[{self.addon_name}] Error en guardado directo SQL: {db_error}", xbmc.LOGERROR)
                raise db_error
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error guardando progreso en BD: {e}", xbmc.LOGERROR)
            self.errors.append(f"DB save error: {e}")
    
    def _show_detailed_dialog(self):
        """Muestra diálogo detallado no modal."""
        try:
            progress_percent = 0
            if self.total_time > 0:
                progress_percent = int((self.current_time / self.total_time) * 100)
            
            # Determinar tipo de file_id y estado
            file_display = self.current_file_id or 'N/A'
            file_type = "UNKNOWN"
            db_status = "NO GUARDADO"
            
            if not self.current_file_id:
                file_type = "NONE"
                db_status = "NO SE GUARDARÁ (sin ID)"
            elif 'overlay_mode_' in self.current_file_id or 'test_file_' in self.current_file_id:
                file_type = "TEST"
                db_status = "NO SE GUARDARÁ (ID de prueba)"
            elif len(self.current_file_id) < 20:  # IDs muy cortos probablemente no son de Google Drive
                file_type = "TEST"
                db_status = "NO SE GUARDARÁ (ID muy corto)"
            else:
                file_type = "REAL"
                # Verificar si se está guardando en BD
                try:
                    from resources.lib import progress_tracker
                    conn = progress_tracker.get_db_connection()
                    cursor = conn.cursor()
                    cursor.execute('SELECT * FROM progress WHERE file_id = ? ORDER BY last_played DESC LIMIT 1', (file_display,))
                    result = cursor.fetchone()
                    if result:
                        db_status = f"GUARDADO (último: {result[4]})"
                    else:
                        db_status = "NO ENCONTRADO EN BD"
                    conn.close()
                except:
                    db_status = "ERROR VERIFICANDO BD"
            
            # Construir texto detallado
            dialog_text = f"=== TRACKING DEBUG STATUS ===\n\n"
            dialog_text += f"File ID: {file_display}\n"
            dialog_text += f"File Type: {file_type}\n"
            dialog_text += f"DB Status: {db_status}\n"
            dialog_text += f"Status: {'ACTIVE' if self.tracking_active else 'INACTIVE'}\n"
            dialog_text += f"Mode: Simplified Overlay\n"
            dialog_text += f"Current Time: {self._format_time(self.current_time)}\n"
            dialog_text += f"Total Time: {self._format_time(self.total_time)}\n"
            dialog_text += f"Progress: {progress_percent}%\n"
            dialog_text += f"Updates: {self.update_count}\n"
            dialog_text += f"Errors: {len(self.errors)}\n"
            
            if self.errors:
                dialog_text += f"\n=== RECENT ERRORS ===\n"
                for i, error in enumerate(self.errors[-3:]):
                    dialog_text += f"{i+1}. {error}\n"
            
            # Información de depuración
            dialog_text += f"\n=== DEBUG INFO ===\n"
            dialog_text += f"DB Save Interval: 5 seconds\n"
            dialog_text += f"Dialog Interval: 20 seconds\n"
            dialog_text += f"File ID Length: {len(file_display) if file_display != 'N/A' else 0}\n"
            dialog_text += f"Notifications: Disabled (solo diálogo)\n"
            
            dialog_text += f"\nAuto-cierre en 10 segundos..."
            
            # Mostrar diálogo no modal que se cierra solo
            dialog = xbmcgui.Dialog()
            dialog.textviewer("Tracking Debug Status", dialog_text)
            
            xbmc.log(f"[{self.addon_name}] Diálogo detallado mostrado", xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error mostrando diálogo: {e}", xbmc.LOGERROR)
    
    def _format_time(self, seconds):
        """Formatea segundos en formato MM:SS."""
        if seconds <= 0:
            return "00:00"
        
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        else:
            return f"{minutes:02d}:{secs:02d}"

# Instancia global - se creará cuando se necesite
simple_debug_overlay = None

def get_simple_debug_overlay():
    """Obtiene o crea la instancia de la overlay."""
    global simple_debug_overlay
    if simple_debug_overlay is None:
        simple_debug_overlay = SimpleDebugOverlay()
    return simple_debug_overlay
