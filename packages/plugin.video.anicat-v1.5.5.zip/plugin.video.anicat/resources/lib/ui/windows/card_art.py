"""Consistent artwork and fallback classification for custom cards."""
ROOT = 'special://home/addons/plugin.video.anicat/resources/'
POSTER = ROOT + 'skins/Default/media/hq_placeholder_poster_v1.png'
LANDSCAPE = ROOT + 'skins/Default/media/hq_placeholder_landscape_v1.png'
FANART = ROOT + 'media/fanart.jpg'


def is_placeholder(thumbnail):
    name = (thumbnail or '').replace('\\', '/').rsplit('/', 1)[-1].lower()
    return not name or name in ('icon.png', 'icon_round.png', 'defaultvideo.png') or name.startswith('hq_placeholder_')


def set_card_art(item, thumbnail='', fanart='', landscape=False):
    missing = is_placeholder(thumbnail)
    art = (LANDSCAPE if landscape else POSTER) if missing else thumbnail
    item.setArt({'thumb': art, 'poster': art,
                 'fanart': (fanart if not is_placeholder(fanart) else '') or (FANART if missing else thumbnail)})
    item.setProperty('IsPlaceholder', 'true' if missing else '')


def is_direct_movie(source):
    return source.get('content_type') in ('movie', 'movies') and not source.get('is_folder', True)
