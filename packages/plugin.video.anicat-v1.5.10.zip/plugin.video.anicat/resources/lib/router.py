# -*- coding: utf-8 -*-
"""
Enrutador de modos del plugin AniCat.
Mapea el parámetro 'mode' de la URL al handler correspondiente.
"""

import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon()


def dispatch(mode, args):
    """
    Enruta la llamada al módulo de UI correspondiente.

    Args:
        mode (str | None): valor del parámetro 'mode' de la URL
        args (dict): todos los parámetros de la URL (valores como listas)
    """
    try:
        if mode is None:
            home_state = xbmcgui.Window(10000)
            restore_requested = args.get('restore', ['0'])[0] == '1'
            if restore_requested:
                home_state.clearProperty('AniCat.HomeOpen')
            if (
                addon.getSetting('use_custom_home') == 'false'
                or home_state.getProperty('AniCat.HomeOpen') == 'true'
                or (
                    home_state.getProperty('AniCat.RestoreInProgress') == 'true'
                    and not restore_requested
                )
                or not xbmc.getCondVisibility('Window.IsActive(videos)')
            ):
                if restore_requested:
                    home_state.clearProperty('AniCat.RestoreInProgress')
                from resources.lib.ui import main_menu
                main_menu.show(args)
                return

            # Intentar la UI nova (WindowXML); fallback al menú classic si falla
            try:
                home_state.setProperty('AniCat.HomeOpen', 'true')
                try:
                    from resources.lib.ui.windows.window_router import show_home
                    show_home()
                finally:
                    home_state.clearProperty('AniCat.HomeOpen')
                    if restore_requested:
                        home_state.clearProperty('AniCat.RestoreInProgress')
                return
            except Exception as e:
                import traceback
                tb = traceback.format_exc()
                xbmc.log(f'[AniCat] WindowXML home ERROR: {e}\n{tb}', xbmc.LOGERROR)
                xbmcgui.Dialog().notification('AniCat', f'WindowXML: {e}', xbmcgui.NOTIFICATION_ERROR, 8000)
                from resources.lib.ui import main_menu
                main_menu.show(args)

        elif mode == 'continue_watching':
            try:
                from resources.lib.ui.windows.window_router import show_continue_watching
                show_continue_watching()
                return
            except Exception as e:
                import traceback; xbmc.log(f'[AniCat] WindowXML continue ERROR: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
                from resources.lib.ui import continue_watching
                continue_watching.show(args)

        elif mode == 'movies':
            try:
                from resources.lib.ui.windows.window_router import show_movies
                show_movies()
                return
            except Exception as e:
                import traceback; xbmc.log(f'[AniCat] WindowXML movies ERROR: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
                from resources.lib.ui import movies
                movies.show(args)

        elif mode == 'series':
            try:
                from resources.lib.ui.windows.window_router import show_series
                show_series()
                return
            except Exception as e:
                import traceback; xbmc.log(f'[AniCat] WindowXML series ERROR: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
                from resources.lib.ui.series import show_series_list
                show_series_list(args)

        elif mode == 'series_detail':
            from resources.lib.ui.series import show_series_detail
            show_series_detail(args)

        elif mode == 'series_episodes':
            from resources.lib.ui.series import show_episodes
            show_episodes(args)

        elif mode == 'browse_folder':
            # Alias genérico: delega según content_type
            content_type = args.get('content_type', ['general'])[0]
            if content_type == 'series':
                from resources.lib.ui.series import show_series_detail
                show_series_detail(args)
            else:
                from resources.lib.ui.movies import show as movies_show
                # Reutilizar la vista de exploración genérica de movies para subcarpetas
                _browse_generic(args)

        elif mode == 'play_video':
            from resources.lib.ui.playback import play_video
            play_video(args)

        elif mode == 'mark_watched':
            from resources.lib.ui.playback import mark_watched
            mark_watched(args)

        elif mode == 'mark_unwatched':
            from resources.lib.ui.playback import mark_unwatched
            mark_unwatched(args)

        elif mode == 'watch_later':
            from resources.lib.ui import watchlist
            watchlist.show(args)

        elif mode == 'watchlist_item':
            from resources.lib.core.progress import get_watchlist
            from resources.lib.ui.windows.window_router import open_watchlist_item, watchlist_source
            item_id = args.get('item_id', [''])[0]
            saved = next((item for item in get_watchlist() if item['folder_id'] == item_id), None)
            if saved:
                open_watchlist_item(watchlist_source(saved))

        elif mode == 'add_to_watchlist':
            from resources.lib.ui import watchlist
            watchlist.add(args)

        elif mode == 'remove_from_watchlist':
            from resources.lib.ui import watchlist
            watchlist.remove(args)

        elif mode == 'pair_device':
            from resources.lib.ui import pairing
            pairing.show(args)

        elif mode == 'sync_account':
            from resources.lib.ui import pairing
            pairing.sync_account(args)

        elif mode == 'drive_config':
            from resources.lib.ui import drive_config
            drive_config.show(args)

        elif mode == 'setup_drive':
            from resources.lib.ui import drive_config
            drive_config.setup_drive(args)

        elif mode == 'show_current_config':
            from resources.lib.ui import drive_config
            drive_config.show_current_config(args)

        elif mode == 'manual_drive_setup':
            from resources.lib.ui import drive_config
            drive_config.manual_drive_setup(args)

        elif mode == 'settings':
            addon.openSettings()
            xbmc.executebuiltin('Container.Refresh')

        elif mode == 'dummy':
            pass  # modo sin acción (placeholder)

        elif mode == 'debug_tracking':
            _debug_tracking()

        elif mode == 'debug_pending':
            _debug_pending()

        else:
            xbmc.log(f'[AniCat] Mode desconegut: {mode}', xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(
                addon.getAddonInfo('name'),
                f'Mode desconegut: {mode}',
                xbmcgui.NOTIFICATION_WARNING,
            )

    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        xbmc.log(f'[AniCat] Error en dispatch(mode={mode}): {e}\n{tb}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            'Error AniCat',
            f'Ha ocorregut un error: {e}\n\nRevisa els logs per a més detalls.',
        )


def _browse_generic(args):
    """Vista genérica de exploración de carpeta (para películas en subcarpeta)."""
    from resources.lib.ui.helpers import (
        get_handle, add_directory_item, add_video_item, end_directory,
        set_content, context_mark_watched, context_mark_unwatched, build_url,
    )
    from resources.lib.core import progress, gdrive

    handle = get_handle()
    folder_id    = args.get('folder_id', [None])[0]
    drive_id     = args.get('drive_id', [None])[0]
    content_type = args.get('content_type', ['general'])[0]
    folder_name  = args.get('folder_name', [''])[0] or ''

    if not folder_id or not drive_id:
        from resources.lib.ui.helpers import notify_error
        notify_error('Paràmetres invàlids')
        end_directory(handle)
        return

    if content_type == 'movies':
        set_content(handle, 'movies')
        mediatype = 'movie'
    else:
        set_content(handle, 'episodes')
        mediatype = 'episode'

    contents = gdrive.get_folder_contents(folder_id, drive_id)

    for sub in contents['folders']:
        add_directory_item(
            handle,
            sub['name'],
            {
                'mode': 'browse_folder',
                'folder_id': sub['id'],
                'drive_id': drive_id,
                'content_type': content_type,
                'folder_name': sub['name'],
            },
            thumb=sub.get('thumbnail', ''),
            is_folder=True,
        )

    for f in contents['files']:
        resume_time = progress.get_resume_time(f['id'])
        play_url = build_url({
            'mode': 'play_video',
            'file_id': f['id'],
            'drive_id': drive_id,
            'content_type': content_type,
            'folder_id': folder_id,    # necessari per al tracking (series_id)
            'folder_name': folder_name or f['name'],  # títol fallback
        })
        info = {'title': f['name'], 'mediatype': mediatype}
        context_menu = [
            context_mark_watched(f['id']),
            context_mark_unwatched(f['id']),
        ]
        add_video_item(
            handle=handle,
            label=f['name'],
            play_url=play_url,
            thumb=f.get('thumbnail', ''),
            fanart=f.get('fanart', ''),
            info=info,
            resume_time=resume_time,
            context_menu=context_menu,
        )

    end_directory(handle)


# ------------------------------------------------------------------
# Debug helpers
# ------------------------------------------------------------------

def _debug_tracking():
    """Mostra tots els registres de progress de la BD en un diàleg."""
    try:
        import datetime
        from resources.lib.core.progress import get_all_progress
        rows = get_all_progress()
        if not rows:
            xbmcgui.Dialog().ok('AniCat Debug', 'No hi ha registres de progress a la BD.')
            return
        lines = ['TÍTOL                          TEMPS    TOTAL     %   TIPUS    ÚLTIMA VEG.']
        lines.append('-' * 78)
        for r in rows[:30]:
            pct = (r['resume_time'] / r['total_time'] * 100) if r.get('total_time', 0) > 0 else 0
            ts = datetime.datetime.fromtimestamp(r['last_played']).strftime('%d/%m %H:%M') if r.get('last_played') else '-'
            title = (r.get('title') or r['file_id'])[:30]
            lines.append(f"{title:<30} {r.get('resume_time',0):>6.0f}s {r.get('total_time',0):>6.0f}s {pct:>4.0f}%  {r.get('type','?'):<8} {ts}")
        text = '\n'.join(lines)
        xbmc.log('[AniCat] Debug Progress DB:\n' + text, xbmc.LOGINFO)
        xbmcgui.Dialog().textviewer('AniCat — Progress DB', text)
    except Exception as e:
        xbmcgui.Dialog().ok('Error Debug', str(e))


def _debug_pending():
    """Mostra l'estat de pending_playback i dels últims events del player."""
    try:
        import time
        import datetime
        from resources.lib.core import progress

        conn = progress.get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM pending_playback WHERE id = 1')
        row = cursor.fetchone()
        conn.close()

        lines = ['=== pending_playback ===']
        if row:
            age = int(time.time()) - (row['written_at'] or 0)
            lines += [
                f"file_id: {row['file_id']}",
                f"title:   {row['title']}",
                f"type:    {row['file_type']}",
                f"ep_num:  {row['episode_number']}",
                f"age:     {age}s",
            ]
        else:
            lines.append('(buit — cap reproducció pendent registrada)')

        lines += ['', '=== Últims 5 progress ===']
        for r in progress.get_all_progress()[:5]:
            ts = datetime.datetime.fromtimestamp(r['last_played']).strftime('%d/%m %H:%M') if r.get('last_played') else '-'
            pct = (r['resume_time'] / r['total_time'] * 100) if r.get('total_time', 0) > 0 else 0
            lines.append(f"[{ts}] {(r.get('title') or r['file_id'])[:35]}  {pct:.0f}%  ({r.get('type','?')})")

        text = '\n'.join(lines)
        xbmc.log('[AniCat] Debug Pending:\n' + text, xbmc.LOGINFO)
        xbmcgui.Dialog().textviewer('AniCat — Debug Tracking', text)
    except Exception as e:
        xbmcgui.Dialog().ok('Error Debug', str(e))
