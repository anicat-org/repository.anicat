# -*- coding: utf-8 -*-
"""
Overlay visual en tiempo real usando WindowDialog para mostrar información de tracking.
Crea una ventana flotante que se actualiza continuamente sin interrumpir la reproducción.
"""

import xbmc
import xbmcgui
import xbmcaddon
import time
import threading

class RealTimeTrackingOverlay:
    """Overlay en tiempo real que se integra con el HUD del reproductor."""
    
    def __init__(self):
        self.window = None
        self.visible = False
        self.enabled = False  # Estado del toggle
        self.update_thread = None
        self.monitor = xbmc.Monitor()
        
        # Configuración
        self.addon = xbmcaddon.Addon()
        self.addon_name = self.addon.getAddonInfo('name')
        
        # Estado actual
        self.current_file_id = None
        self.tracking_active = False
        self.last_update = 0
        self.current_time = 0
        self.total_time = 0
        self.update_count = 0
        self.errors = []
        
        # Configuración de la ventana
        self.window_id = 10151
        self.window_width = 300
        self.window_height = 150
        
        # Estado del HUD del reproductor
        self.hud_visible = False
        self.last_hud_check = 0
        
        xbmc.log(f"[{self.addon_name}] Overlay inicializada (estado: {self.enabled})", xbmc.LOGINFO)
        
    def show_overlay(self, file_id=None):
        """Activa el modo overlay (no muestra la ventana inmediatamente)."""
        self.enabled = True
        self.current_file_id = file_id
        self.tracking_active = True
        
        xbmc.log(f"[{self.addon_name}] Modo overlay activado", xbmc.LOGINFO)
        
        # Iniciar thread de monitoreo si no está corriendo
        if not self.update_thread or not self.update_thread.is_alive():
            self.update_thread = threading.Thread(target=self._monitor_loop)
            self.update_thread.daemon = True
            self.update_thread.start()
        
        # Notificación breve
        xbmcgui.Dialog().notification(
            self.addon_name,
            "Modo overlay ACTIVADO",
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
    
    def hide_overlay(self):
        """Desactiva el modo overlay."""
        self.enabled = False
        self.visible = False
        self.tracking_active = False
        
        # Cerrar ventana si está abierta
        if self.window:
            try:
                self.window.close()
            except:
                pass
            self.window = None
        
        xbmc.log(f"[{self.addon_name}] Modo overlay desactivado", xbmc.LOGINFO)
        
        # Notificación breve
        xbmcgui.Dialog().notification(
            self.addon_name,
            "Modo overlay DESACTIVADO",
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
    
    def _monitor_loop(self):
        """Bucle principal que monitorea la reproducción y el HUD."""
        xbmc.log(f"[{self.addon_name}] Iniciando bucle de monitoreo", xbmc.LOGINFO)
        
        while self.enabled and not self.monitor.abortRequested():
            try:
                # Verificar si hay reproducción activa
                player = xbmc.Player()
                is_playing = player.isPlayingVideo()
                
                xbmc.log(f"[{self.addon_name}] Reproducción activa: {is_playing}, Overlay habilitado: {self.enabled}", xbmc.LOGDEBUG)
                
                if is_playing and self.enabled:
                    # Simplificado: mostrar siempre durante reproducción (sin depender del HUD)
                    if not self.visible:
                        xbmc.log(f"[{self.addon_name}] Mostrando overlay (reproducción activa)", xbmc.LOGINFO)
                        self._create_window()
                        self.visible = True
                    
                    # Actualizar datos si la ventana está visible
                    if self.visible:
                        self._update_status()
                        self._update_display()
                else:
                    # No hay reproducción, cerrar ventana
                    if self.visible:
                        xbmc.log(f"[{self.addon_name}] Ocultando overlay (sin reproducción)", xbmc.LOGINFO)
                        self._close_window()
                        self.visible = False
                
                # Esperar antes de próxima verificación
                if self.monitor.waitForAbort(0.5):
                    break
                    
            except Exception as e:
                xbmc.log(f"[{self.addon_name}] Error en monitor_loop: {e}", xbmc.LOGERROR)
                self.errors.append(f"Monitor error: {e}")
        
        xbmc.log(f"[{self.addon_name}] Bucle de monitoreo finalizado", xbmc.LOGINFO)
    
    def _check_hud_visibility(self):
        """Verifica si el HUD del reproductor está visible."""
        try:
            # Método 1: Verificar si el reproductor está en pantalla completa y si hay controles visibles
            player = xbmc.Player()
            if not player.isPlayingVideo():
                self.hud_visible = False
                return False
            
            # Método 2: Verificar si el cursor del ratón se ha movido recientemente
            # (Kodi muestra el HUD cuando el ratón se mueve)
            current_time = time.time()
            
            # Si no hay registro de último movimiento, asumir que el HUD está visible
            if not hasattr(self, 'last_hud_activity'):
                self.last_hud_activity = current_time
                self.hud_visible = True
                return True
            
            # Si ha habido actividad reciente (menos de 3 segundos), asumir HUD visible
            time_since_activity = current_time - self.last_hud_activity
            if time_since_activity < 3:
                self.hud_visible = True
            else:
                self.hud_visible = False
            
            # Método 3: Verificar propiedades de la GUI
            try:
                json_query = '''
                {
                    "jsonrpc": "2.0",
                    "method": "GUI.GetProperties",
                    "params": {"properties": ["fullscreen"]},
                    "id": 1
                }
                '''
                response = xbmc.executeJSONRPC(json_query)
                data = xbmc.getJSON(response)
                
                if 'result' in data and 'fullscreen' in data['result']:
                    # Si estamos en fullscreen, el HUD podría no ser visible permanentemente
                    is_fullscreen = data['result']['fullscreen']
                    if is_fullscreen:
                        # En fullscreen, el HUD aparece con el movimiento del ratón
                        # Ya lo verificamos arriba
                        pass
                    else:
                        # Si no estamos en fullscreen, asumir que el HUD es visible
                        self.hud_visible = True
                        
            except:
                # Fallback: si hay reproducción activa, asumir que el HUD puede ser visible
                self.hud_visible = player.isPlayingVideo()
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error verificando visibilidad HUD: {e}", xbmc.LOGWARNING)
            # Fallback seguro: asumir que el HUD está visible si hay reproducción
            try:
                player = xbmc.Player()
                self.hud_visible = player.isPlayingVideo()
            except:
                self.hud_visible = False
        
        return self.hud_visible
    
    def _simulate_mouse_activity(self):
        """Simula actividad del ratón para pruebas."""
        self.last_hud_activity = time.time()
    
    def _create_window(self):
        """Crea la ventana de overlay sin bloquear."""
        try:
            xbmc.log(f"[{self.addon_name}] Creando ventana de overlay...", xbmc.LOGINFO)
            
            # Usar Window en lugar de WindowDialog para no bloquear
            self.window = xbmcgui.Window(self.window_id)
            xbmc.log(f"[{self.addon_name}] Window creada con ID: {self.window_id}", xbmc.LOGINFO)
            
            # Limpiar controles anteriores
            try:
                existing_controls = self.window.getControls()
                if existing_controls:
                    self.window.removeControls(existing_controls)
                    xbmc.log(f"[{self.addon_name}] Limpiados {len(existing_controls)} controles anteriores", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[{self.addon_name}] Error limpiando controles: {e}", xbmc.LOGWARNING)
            
            # Configurar controles
            self._setup_window_controls()
            xbmc.log(f"[{self.addon_name}] Controles configurados", xbmc.LOGINFO)
            
            # Posicionar ventana en la esquina superior derecha
            screen_width = 1280
            screen_height = 720
            
            try:
                import json
                query = '{"jsonrpc":"2.0","method":"Gui.GetScreenResolution","params":{},"id":1}'
                response = xbmc.executeJSONRPC(query)
                data = xbmc.getJSON(response)
                if 'result' in data:
                    res = data['result']
                    screen_width = res['width']
                    screen_height = res['height']
                    xbmc.log(f"[{self.addon_name}] Resolución detectada: {screen_width}x{screen_height}", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[{self.addon_name}] Error obteniendo resolución: {e}", xbmc.LOGWARNING)
            
            window_x = screen_width - self.window_width - 20
            window_y = 20
            
            self.window.setPosition(window_x, window_y)
            self.window.setWidth(self.window_width)
            self.window.setHeight(self.window_height)
            
            xbmc.log(f"[{self.addon_name}] Ventana posicionada en ({window_x}, {window_y}) con tamaño {self.window_width}x{self.window_height}", xbmc.LOGINFO)
            
            # Hacer la ventana visible
            self.window.setProperty("Window.IsVisible", "true")
            xbmc.log(f"[{self.addon_name}] Ventana marcada como visible", xbmc.LOGINFO)
            
            xbmc.log(f"[{self.addon_name}] Ventana de overlay creada exitosamente", xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error creando ventana: {e}", xbmc.LOGERROR)
            import traceback
            xbmc.log(f"[{self.addon_name}] Traceback: {traceback.format_exc()}", xbmc.LOGERROR)
    
    def _close_window(self):
        """Cierra la ventana de overlay."""
        try:
            if self.window:
                self.window.removeControls(self.window.getControls())
                self.window.close()
                self.window = None
                xbmc.log(f"[{self.addon_name}] Ventana de overlay cerrada", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error cerrando ventana: {e}", xbmc.LOGERROR)
    
    def _setup_window_controls(self):
        """Configura los controles de la ventana."""
        try:
            # Fondo semitransparente más pequeño
            background = xbmcgui.ControlImage(
                0, 0, 
                self.window_width, self.window_height,
                'black.png'
            )
            background.setColorDiffuse('AA000000')  # Negro semitransparente
            self.window.addControl(background)
            
            # Título más pequeño
            self.title_label = xbmcgui.ControlLabel(
                5, 5, 
                self.window_width - 10, 20,
                "TRACKING",
                font='font12',
                textColor='FF00FF00'
            )
            self.window.addControl(self.title_label)
            
            # File ID truncado
            self.file_id_label = xbmcgui.ControlLabel(
                5, 25, 
                self.window_width - 10, 15,
                f"File: {self.current_file_id[:20] if self.current_file_id else 'N/A'}...",
                font='font10',
                textColor='FFFFFFFF'
            )
            self.window.addControl(self.file_id_label)
            
            # Estado
            self.status_label = xbmcgui.ControlLabel(
                5, 40, 
                self.window_width - 10, 15,
                "Status: ACTIVE",
                font='font10',
                textColor='FFFFFF00'
            )
            self.window.addControl(self.status_label)
            
            # Tiempo
            self.time_label = xbmcgui.ControlLabel(
                5, 55, 
                self.window_width - 10, 15,
                "00:00 / 00:00",
                font='font10',
                textColor='FFFFFFFF'
            )
            self.window.addControl(self.time_label)
            
            # Barra de progreso pequeña
            self.progress_bar = xbmcgui.ControlProgress(
                5, 70,
                self.window_width - 10, 8
            )
            self.window.addControl(self.progress_bar)
            
            # Contador
            self.update_label = xbmcgui.ControlLabel(
                5, 80, 
                self.window_width - 10, 15,
                "Updates: 0",
                font='font10',
                textColor='FF00FFFF'
            )
            self.window.addControl(self.update_label)
            
            # Errores
            self.error_label = xbmcgui.ControlLabel(
                5, 95, 
                self.window_width - 10, 15,
                "Errors: 0",
                font='font10',
                textColor='FFFF0000'
            )
            self.window.addControl(self.error_label)
            
            # Pequeño indicador de estado
            self.indicator = xbmcgui.ControlImage(
                self.window_width - 25, 5,
                20, 20,
                'white.png'
            )
            self.indicator.setColorDiffuse('FF00FF00')  # Verde
            self.window.addControl(self.indicator)
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error configurando controles: {e}", xbmc.LOGERROR)
    
    def _update_status(self):
        """Actualiza el estado del tracking."""
        try:
            # Verificar si hay reproducción activa
            player = xbmc.Player()
            is_playing = player.isPlayingVideo()
            
            # Método alternativo JSON-RPC
            if not is_playing:
                try:
                    json_query = '{"jsonrpc":"2.0","method":"Player.GetActivePlayers","id":1}'
                    response = xbmc.executeJSONRPC(json_query)
                    data = xbmc.getJSON(response)
                    if 'result' in data and len(data['result']) > 0:
                        is_playing = any(p.get('type') == 'video' for p in data['result'])
                except:
                    pass
            
            if is_playing:
                try:
                    self.current_time = player.getTime()
                    self.total_time = player.getTotalTime()
                    self.last_update = time.time()
                    self.update_count += 1
                except:
                    # Método alternativo JSON-RPC
                    try:
                        json_query = '''
                        {
                            "jsonrpc": "2.0",
                            "method": "Player.GetProperties",
                            "params": {"playerid": 1, "properties": ["time", "totaltime"]},
                            "id": 1
                        }
                        '''
                        response = xbmc.executeJSONRPC(json_query)
                        data = xbmc.getJSON(response)
                        if 'result' in data:
                            result = data['result']
                            time_data = result.get('time', {})
                            totaltime_data = result.get('totaltime', {})
                            
                            self.current_time = time_data.get('hours', 0) * 3600 + time_data.get('minutes', 0) * 60 + time_data.get('seconds', 0)
                            self.total_time = totaltime_data.get('hours', 0) * 3600 + totaltime_data.get('minutes', 0) * 60 + totaltime_data.get('seconds', 0)
                            self.last_update = time.time()
                            self.update_count += 1
                    except:
                        pass
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error actualizando estado: {e}", xbmc.LOGERROR)
            self.errors.append(f"Status error: {e}")
    
    def _update_display(self):
        """Actualiza la visualización en tiempo real."""
        if not self.window or not self.visible:
            return
            
        try:
            # Calcular progreso
            progress_percent = 0
            if self.total_time > 0:
                progress_percent = int((self.current_time / self.total_time) * 100)
            
            # Actualizar labels si existen
            if hasattr(self, 'file_id_label'):
                file_display = self.current_file_id or 'N/A'
                if len(file_display) > 20:
                    file_display = file_display[:17] + "..."
                self.file_id_label.setLabel(f"File: {file_display}")
            
            if hasattr(self, 'status_label'):
                status = "ACTIVE" if self.tracking_active else "INACTIVE"
                color = "FF00FF00" if self.tracking_active else "FFFF0000"
                self.status_label.setLabel(f"Status: {status}")
                self.status_label.setColorDiffuse(color)
            
            if hasattr(self, 'time_label'):
                time_str = f"{self._format_time(self.current_time)} / {self._format_time(self.total_time)}"
                self.time_label.setLabel(time_str)
            
            if hasattr(self, 'progress_bar'):
                self.progress_bar.setPercent(progress_percent)
            
            if hasattr(self, 'update_label'):
                self.update_label.setLabel(f"Updates: {self.update_count}")
            
            if hasattr(self, 'error_label'):
                error_count = len(self.errors)
                error_color = "FF00FF00" if error_count == 0 else "FFFF0000"
                self.error_label.setLabel(f"Errors: {error_count}")
                self.error_label.setColorDiffuse(error_color)
            
            # Actualizar indicador de estado
            if hasattr(self, 'indicator'):
                indicator_color = "FF00FF00" if self.tracking_active else "FFFF0000"
                self.indicator.setColorDiffuse(indicator_color)
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error actualizando display: {e}", xbmc.LOGERROR)
    
    def _format_time(self, seconds):
        """Formatea segundos en formato MM:SS."""
        if seconds <= 0:
            return "00:00"
        
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        else:
            return f"{minutes:02d}:{secs:02d}"
    
    def add_error(self, error_msg):
        """Añade un error al log."""
        self.errors.append(f"[{time.strftime('%H:%M:%S')}] {error_msg}")
        # Mantener solo los últimos 10 errores
        if len(self.errors) > 10:
            self.errors = self.errors[-10:]

# Instancia global
realtime_tracking_overlay = RealTimeTrackingOverlay()
