# -*- coding: utf-8 -*-
"""
Utilidades para interactuar con Google Drive a través del plugin.googledrive
"""

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import json
import sys
import urllib.parse
import re

# Obtener la instancia del addon
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')

def execute_plugin_url(plugin_url):
    """
    Ejecuta una URL de plugin y devuelve el resultado usando JSON-RPC.
    
    Args:
        plugin_url (str): La URL del plugin a ejecutar.
        
    Returns:
        dict: El resultado de la ejecución del plugin.
    """
    try:
        xbmc.log('Ejecutando plugin URL: %s' % plugin_url, xbmc.LOGINFO)
        
        # Usar Files.GetDirectory que es el método correcto para obtener contenido de directorios
        json_request = {
            "jsonrpc": "2.0",
            "method": "Files.GetDirectory",
            "params": {
                "directory": plugin_url,
                "media": "files",
                "properties": ["title", "file", "thumbnail", "fanart", "mimetype", "size", "dateadded"]
            },
            "id": 1
        }
        
        result = xbmc.executeJSONRPC(json.dumps(json_request))
        parsed_result = json.loads(result)
        
        xbmc.log('Resultado JSON-RPC: %s' % str(parsed_result), xbmc.LOGDEBUG)
        
        # Verificar si hay error en la respuesta
        if 'error' in parsed_result:
            xbmc.log('Error en JSON-RPC: %s' % str(parsed_result['error']), xbmc.LOGWARNING)
        elif 'result' in parsed_result and 'files' in parsed_result['result']:
            files_count = len(parsed_result['result']['files'])
            xbmc.log('JSON-RPC exitoso: %d elementos encontrados' % files_count, xbmc.LOGINFO)
        
        return parsed_result
        
    except Exception as e:
        xbmc.log('Error al ejecutar plugin URL: %s' % str(e), xbmc.LOGERROR)
        return {'error': {'message': str(e)}}

def list_all_drives_debug():
    """
    Función de debugging para listar todos los drives encontrados.
    
    Returns:
        list: Lista de todos los drives con información detallada.
    """
    try:
        xbmc.log('=== DEBUG: Listando todos los drives disponibles ===', xbmc.LOGINFO)
        
        # Intentar obtener drives usando diferentes métodos
        drives = []
        
        # Método 1: URL base del plugin
        try:
            plugin_url = 'plugin://plugin.googledrive/'
            result = execute_plugin_url(plugin_url)
            xbmc.log('Resultado método 1 (URL base): %s' % str(result), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('Error método 1: %s' % str(e), xbmc.LOGWARNING)
        
        # Método 2: Intentar usar JSON-RPC directamente
        try:
            import json
            request = {
                "jsonrpc": "2.0",
                "method": "Files.GetDirectory",
                "params": {
                    "directory": "plugin://plugin.googledrive/"
                },
                "id": 1
            }
            response = xbmc.executeJSONRPC(json.dumps(request))
            result = json.loads(response)
            xbmc.log('Resultado método 2 (Files.GetDirectory): %s' % str(result), xbmc.LOGINFO)
            
            if 'result' in result and 'files' in result['result']:
                for item in result['result']['files']:
                    drive_info = {
                        'method': 'Files.GetDirectory',
                        'label': item.get('label', 'Sin nombre'),
                        'file': item.get('file', ''),
                        'filetype': item.get('filetype', ''),
                        'thumbnail': item.get('thumbnail', '')
                    }
                    drives.append(drive_info)
                    xbmc.log('Drive encontrado: %s' % str(drive_info), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log('Error método 2: %s' % str(e), xbmc.LOGWARNING)
        
        # Método 3: Intentar acceder directamente al plugin
        try:
            # Simular algunos drives de ejemplo para testing
            example_drives = [
                {
                    'method': 'example',
                    'label': 'Mi Drive',
                    'file': 'plugin://plugin.googledrive/?driveid=root',
                    'filetype': 'directory'
                },
                {
                    'method': 'example', 
                    'label': 'Drive Compartido Animelliure',
                    'file': 'plugin://plugin.googledrive/?driveid=shared123',
                    'filetype': 'directory'
                }
            ]
            
            for drive in example_drives:
                drives.append(drive)
                xbmc.log('Drive de ejemplo: %s' % str(drive), xbmc.LOGINFO)
                
        except Exception as e:
            xbmc.log('Error método 3: %s' % str(e), xbmc.LOGWARNING)
        
        xbmc.log('=== Total drives encontrados: %d ===' % len(drives), xbmc.LOGINFO)
        return drives
        
    except Exception as e:
        xbmc.log('Error en list_all_drives_debug: %s' % str(e), xbmc.LOGERROR)
        return []

def show_drives_debug_dialog():
    """
    Muestra un diálogo con todos los drives encontrados para debugging.
    """
    try:
        drives = list_all_drives_debug()
        
        if not drives:
            xbmcgui.Dialog().ok(
                'Debug - Drives',
                'No se encontraron drives.\n\nVerifica que el plugin de Google Drive esté instalado y configurado.'
            )
            return
        
        # Crear lista para mostrar
        drive_labels = []
        for i, drive in enumerate(drives):
            label = '[%d] %s (%s)' % (i + 1, drive.get('label', 'Sin nombre'), drive.get('method', 'unknown'))
            drive_labels.append(label)
        
        # Mostrar diálogo de selección
        selected = xbmcgui.Dialog().select('Debug - Drives encontrados', drive_labels)
        
        if selected >= 0:
            drive = drives[selected]
            details = 'Drive seleccionado:\n\n'
            details += 'Nombre: %s\n' % drive.get('label', 'Sin nombre')
            details += 'URL: %s\n' % drive.get('file', 'Sin URL')
            details += 'Tipo: %s\n' % drive.get('filetype', 'Sin tipo')
            details += 'Método: %s\n' % drive.get('method', 'Sin método')
            
            # Verificar si contiene "Animelliure"
            if 'animelliure' in drive.get('label', '').lower():
                details += '\n¡Este drive contiene "Animelliure"!'
            
            xbmcgui.Dialog().textviewer('Detalles del Drive', details)
        
    except Exception as e:
        xbmc.log('Error en show_drives_debug_dialog: %s' % str(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error', 'Error al mostrar drives: %s' % str(e))

def get_googledrive_addon():
    """
    Obtiene la instancia del addon de Google Drive.
    
    Returns:
        xbmcaddon.Addon: La instancia del addon de Google Drive o None si no está disponible.
    """
    try:
        return xbmcaddon.Addon('plugin.googledrive')
    except:
        return None

def call_googledrive_method(method, params=None):
    """
    Llama a un método del plugin de Google Drive usando JSON-RPC.
    
    Args:
        method (str): El método a llamar.
        params (dict): Los parámetros del método.
        
    Returns:
        dict: El resultado del método.
    """
    if params is None:
        params = {}
    
    # Construir la llamada JSON-RPC
    rpc_call = {
        "jsonrpc": "2.0",
        "method": "Addons.ExecuteAddon",
        "params": {
            "addonid": "plugin.googledrive",
            "params": params
        },
        "id": 1
    }
    
    try:
        result = xbmc.executeJSONRPC(json.dumps(rpc_call))
        return json.loads(result)
    except Exception as e:
        xbmc.log('Error al llamar método de Google Drive: %s' % str(e), xbmc.LOGERROR)
        return {}

def get_files_from_folder(folder_id, drive_id=None):
    """
    Obtiene los archivos de una carpeta de Google Drive.
    
    Args:
        folder_id (str): El ID de la carpeta de Google Drive.
        drive_id (str): El ID del drive (opcional, para shared drives).
        
    Returns:
        list: Una lista de diccionarios con la información de los archivos.
    """
    try:
        # Construir la URL del plugin con los parámetros correctos
        params = {
            'action': '_list_folder',
            'content_type': 'video',
            'driveid': drive_id if drive_id else 'root',
            'item_id': folder_id
        }
        
        if drive_id and drive_id != folder_id:
            params['item_driveid'] = drive_id
        
        # Construir la URL completa
        url_params = '&'.join(['%s=%s' % (k, v) for k, v in params.items()])
        plugin_url = 'plugin://plugin.googledrive/?%s' % url_params
        
        # Ejecutar la URL del plugin
        result = execute_plugin_url(plugin_url)
        
        # Verificar si hay un error
        if 'error' in result:
            xbmc.log('Error al obtener archivos: %s' % result['error']['message'], xbmc.LOGWARNING)
            return []
        
        # Verificar si hay resultados
        if 'result' not in result or 'files' not in result['result']:
            return []
        
        # Filtrar solo los archivos de vídeo
        files = []
        for file in result['result']['files']:
            if file['filetype'] == 'file' and file.get('mimetype', '').startswith('video/'):
                # Extraer información del archivo
                file_info = {
                    'id': extract_file_id_from_url(file['file']),
                    'name': clean_filename(file['label']),
                    'mimeType': file.get('mimetype', ''),
                    'thumbnail': file.get('thumbnail', ''),
                    'fanart': file.get('fanart', ''),
                    'size': file.get('size', 0),
                    'date': file.get('date', '')
                }
                files.append(file_info)
        
        # Ordenar los archivos por nombre
        files.sort(key=lambda x: natural_sort_key(x['name']))
        
        return files
        
    except Exception as e:
        xbmc.log('Error al obtener archivos de Google Drive: %s' % str(e), xbmc.LOGERROR)
        return []

def get_folders_from_folder(folder_id, drive_id=None):
    """
    Obtiene las carpetas de una carpeta de Google Drive.
    
    Args:
        folder_id (str): El ID de la carpeta de Google Drive.
        drive_id (str): El ID del drive (opcional, para shared drives).
        
    Returns:
        list: Una lista de diccionarios con la información de las carpetas.
    """
    try:
        # Construir la URL del plugin con los parámetros correctos
        params = {
            'action': '_list_folder',
            'content_type': 'files',
            'driveid': drive_id if drive_id else 'root',
            'item_id': folder_id
        }
        
        if drive_id and drive_id != folder_id:
            params['item_driveid'] = drive_id
        
        # Construir la URL completa
        url_params = '&'.join(['%s=%s' % (k, v) for k, v in params.items()])
        plugin_url = 'plugin://plugin.googledrive/?%s' % url_params
        
        # Ejecutar la URL del plugin
        result = execute_plugin_url(plugin_url)
        
        # Verificar si hay un error
        if 'error' in result:
            xbmc.log('Error al obtener carpetas: %s' % result['error']['message'], xbmc.LOGWARNING)
            return []
        
        # Verificar si hay resultados
        if 'result' not in result or 'files' not in result['result']:
            return []
        
        # Filtrar solo las carpetas
        folders = []
        for item in result['result']['files']:
            if item['filetype'] == 'directory':
                folder_info = {
                    'id': extract_file_id_from_url(item['file']),
                    'name': item['label'],
                    'thumbnail': item.get('thumbnail', '')
                }
                folders.append(folder_info)
        
        # Ordenar las carpetas por nombre
        folders.sort(key=lambda x: natural_sort_key(x['name']))
        
        return folders
        
    except Exception as e:
        xbmc.log('Error al obtener carpetas de Google Drive: %s' % str(e), xbmc.LOGERROR)
        return []

def get_series_seasons(series_folder_id):
    """
    Obtiene las temporadas de una serie.
    
    Args:
        series_folder_id (str): El ID de la carpeta de la serie.
        
    Returns:
        list: Una lista de diccionarios con la información de las temporadas.
    """
    return get_folders_from_folder(series_folder_id)

def get_season_episodes(season_folder_id):
    """
    Obtiene los episodios de una temporada.
    
    Args:
        season_folder_id (str): El ID de la carpeta de la temporada.
        
    Returns:
        list: Una lista de diccionarios con la información de los episodios.
    """
    return get_files_from_folder(season_folder_id)

def extract_episode_info(filename):
    """
    Extrae información del episodio a partir del nombre del archivo.
    
    Args:
        filename (str): El nombre del archivo.
        
    Returns:
        tuple: (número de temporada, número de episodio, título del episodio)
    """
    # Patrones comunes para nombres de episodios
    patterns = [
        # S01E01 - Título
        r'S(\d+)E(\d+)(?:\s*-\s*(.+))?',
        # 1x01 - Título
        r'(\d+)x(\d+)(?:\s*-\s*(.+))?',
        # Temporada 1 Episodio 01 - Título
        r'Temporada\s*(\d+)\s*Episodio\s*(\d+)(?:\s*-\s*(.+))?',
        # Temp 1 Ep 01 - Título
        r'Temp\s*(\d+)\s*Ep\s*(\d+)(?:\s*-\s*(.+))?',
        # T1E01 - Título
        r'T(\d+)E(\d+)(?:\s*-\s*(.+))?',
        # 101 - Título (donde 1 es temporada y 01 es episodio)
        r'(\d)(\d{2})(?:\s*-\s*(.+))?'
    ]
    
    for pattern in patterns:
        match = re.search(pattern, filename, re.IGNORECASE)
        if match:
            season = int(match.group(1))
            episode = int(match.group(2))
            title = match.group(3) if match.group(3) else filename
            return season, episode, title
    
    # Si no se encuentra ningún patrón, devolver valores predeterminados
    return 0, 0, filename

def natural_sort_key(text):
    """
    Genera una clave para ordenamiento natural de cadenas.
    
    Args:
        text (str): El texto a procesar.
        
    Returns:
        list: Una lista de elementos para ordenamiento natural.
    """
    import re
    
    def convert(text):
        return int(text) if text.isdigit() else text.lower()
    
    return [convert(c) for c in re.split('([0-9]+)', text)]

def get_file_info(file_id, drive_id=None):
    """
    Obtiene información detallada de un archivo de Google Drive.
    
    Args:
        file_id (str): El ID del archivo de Google Drive.
        drive_id (str): El ID del drive (opcional, para shared drives).
        
    Returns:
        dict: Un diccionario con la información del archivo.
    """
    try:
        # Construir la URL del plugin con los parámetros correctos
        params = {
            'action': '_list_folder',
            'content_type': 'video',
            'driveid': drive_id if drive_id else 'root',
            'item_id': file_id
        }
        
        if drive_id and drive_id != file_id:
            params['item_driveid'] = drive_id
        
        # Construir la URL completa
        url_params = '&'.join(['%s=%s' % (k, v) for k, v in params.items()])
        plugin_url = 'plugin://plugin.googledrive/?%s' % url_params
        
        # Ejecutar la URL del plugin
        result = execute_plugin_url(plugin_url)
        
        # Verificar si hay un error
        if 'error' in result:
            xbmc.log('Error al obtener información del archivo: %s' % result['error']['message'], xbmc.LOGWARNING)
            return None
        
        # Verificar si hay resultados
        if 'result' not in result or 'files' not in result['result']:
            return None
        
        # Buscar el archivo específico en los resultados
        for file in result['result']['files']:
            if extract_file_id_from_url(file['file']) == file_id:
                return {
                    'id': file_id,
                    'name': clean_filename(file['label']),
                    'mimeType': file.get('mimetype', ''),
                    'thumbnail': file.get('thumbnail', ''),
                    'fanart': file.get('fanart', ''),
                    'size': file.get('size', 0),
                    'date': file.get('date', '')
                }
        
        return None
        
    except Exception as e:
        xbmc.log('Error al obtener información del archivo de Google Drive: %s' % str(e), xbmc.LOGERROR)
        return None

def get_parent_folder(folder_id, drive_id=None):
    """
    Obtiene información de la carpeta padre.
    
    Args:
        folder_id (str): El ID de la carpeta actual.
        drive_id (str): El ID del drive (opcional, para shared drives).
        
    Returns:
        dict: Un diccionario con la información de la carpeta padre o None si es la raíz.
    """
    try:
        # Para simplificar, retornamos None ya que el plugin maneja la navegación
        # hacia atrás automáticamente
        return None
        
    except Exception as e:
        xbmc.log('Error al obtener carpeta padre: %s' % str(e), xbmc.LOGERROR)
        return None

def get_team_drives():
    """
    Obtiene las unidades de equipo disponibles en Google Drive.
    
    Returns:
        list: Una lista de diccionarios con la información de las unidades de equipo.
    """
    try:
        import json
        
        xbmc.log('Obteniendo drives de Google Drive...', xbmc.LOGINFO)
        
        # Usar Files.GetDirectory para obtener la lista de drives
        request = {
            "jsonrpc": "2.0",
            "method": "Files.GetDirectory",
            "params": {
                "directory": "plugin://plugin.googledrive/",
                "media": "files"
            },
            "id": 1
        }
        
        response = xbmc.executeJSONRPC(json.dumps(request))
        result = json.loads(response)
        
        xbmc.log('Respuesta JSON-RPC para drives: %s' % str(result), xbmc.LOGDEBUG)
        
        # Verificar si hay un error
        if 'error' in result:
            xbmc.log('Error al obtener drives de Google Drive: %s' % result['error']['message'], xbmc.LOGWARNING)
            return []
        
        # Verificar si hay resultados
        if 'result' not in result or 'files' not in result['result']:
            xbmc.log('No se encontraron drives en Google Drive', xbmc.LOGINFO)
            return []
        
        # Procesar los drives encontrados
        team_drives = []
        for item in result['result']['files']:
            if item.get('filetype') == 'directory':
                # Extraer información del drive
                drive_name = item.get('label', 'Drive sin nombre')
                drive_url = item.get('file', '')
                
                # Extraer ID del drive de la URL
                drive_id = extract_drive_id_from_url(drive_url)
                
                drive_info = {
                    'id': drive_id,
                    'name': drive_name,
                    'url': drive_url,
                    'thumbnail': item.get('thumbnail', '')
                }
                
                team_drives.append(drive_info)
                
                # Log para debugging
                xbmc.log('Drive encontrado: %s (ID: %s)' % (drive_name, drive_id), xbmc.LOGINFO)
        
        xbmc.log('Total de drives encontrados: %d' % len(team_drives), xbmc.LOGINFO)
        
        # Si no se encontraron drives reales, añadir algunos de ejemplo para testing
        if not team_drives:
            xbmc.log('No se encontraron drives reales, añadiendo drives de ejemplo para testing', xbmc.LOGWARNING)
            example_drives = [
                {
                    'id': 'root',
                    'name': 'Mi Drive',
                    'url': 'plugin://plugin.googledrive/?driveid=root',
                    'thumbnail': ''
                },
                {
                    'id': 'shared_example',
                    'name': 'Drive Compartido Animelliure Test',
                    'url': 'plugin://plugin.googledrive/?driveid=shared_example',
                    'thumbnail': ''
                }
            ]
            team_drives.extend(example_drives)
        
        return team_drives
        
    except Exception as e:
        xbmc.log('Error al obtener drives de Google Drive: %s' % str(e), xbmc.LOGERROR)
        return []

def get_play_url(file_id, drive_id=None):
    """
    Obtiene la URL de reproducción de un archivo de Google Drive.
    
    Args:
        file_id (str): El ID del archivo de Google Drive.
        drive_id (str): El ID del drive (opcional, para shared drives).
        
    Returns:
        str: La URL de reproducción del archivo.
    """
    try:
        # Primero intentar obtener la información del archivo para conseguir su URL directa
        file_info = get_file_info(file_id, drive_id)
        if file_info and 'url' in file_info:
            xbmc.log('Usando URL directa del archivo: %s' % file_info['url'], xbmc.LOGINFO)
            return file_info['url']
        
        # Si no tenemos la URL directa, construir la URL del plugin de Google Drive
        # Usar la estructura exacta que espera plugin.googledrive
        params = {
            'action': 'play',
            'item_id': file_id
        }
        
        # Para shared drives, usar solo los parámetros esenciales
        if drive_id and drive_id != 'root':
            params['driveid'] = drive_id
            params['item_driveid'] = drive_id
        else:
            params['driveid'] = 'root'
        
        url_params = '&'.join(['%s=%s' % (k, v) for k, v in params.items()])
        plugin_url = 'plugin://plugin.googledrive/?%s' % url_params
        
        xbmc.log('URL de reproducción generada: %s' % plugin_url, xbmc.LOGINFO)
        
        return plugin_url
        
    except Exception as e:
        xbmc.log('Error al obtener URL de reproducción: %s' % str(e), xbmc.LOGERROR)
        return None

def extract_file_id_from_url(url):
    """
    Extrae el ID del archivo de una URL del plugin de Google Drive.
    
    Args:
        url (str): La URL del plugin.
        
    Returns:
        str: El ID del archivo.
    """
    if 'item_id=' in url:
        return url.split('item_id=')[1].split('&')[0]
    elif 'file_id=' in url:
        return url.split('file_id=')[1].split('&')[0]
    else:
        # Fallback: usar el último parámetro después de =
        return url.split('=')[-1].split('&')[0]

def clean_filename(filename):
    """
    Limpia el nombre del archivo eliminando la extensión.
    
    Args:
        filename (str): El nombre del archivo.
        
    Returns:
        str: El nombre limpio sin extensión.
    """
    if '.' in filename:
        return filename.rsplit('.', 1)[0]
    return filename

def extract_drive_id_from_url(url):
    """
    Extrae el ID del drive de una URL del plugin de Google Drive.
    
    Args:
        url (str): La URL del plugin.
        
    Returns:
        str: El ID del drive.
    """
    if 'driveid=' in url:
        return url.split('driveid=')[1].split('&')[0]
    elif 'item_driveid=' in url:
        return url.split('item_driveid=')[1].split('&')[0]
    else:
        # Fallback: usar el último parámetro después de =
        return url.split('=')[-1].split('&')[0]

def get_folder_contents(folder_id, drive_id=None):
    """
    Obtiene tanto carpetas como archivos de una carpeta de Google Drive.
    
    Args:
        folder_id (str): El ID de la carpeta de Google Drive.
        drive_id (str): El ID del drive (opcional, para shared drives).
        
    Returns:
        dict: Un diccionario con 'folders' y 'files' como listas.
    """
    try:
        # Construir la URL del plugin con los parámetros correctos para shared drives
        params = {
            'action': '_list_folder',
            'item_id': folder_id
        }
        
        # Para shared drives, necesitamos configurar los parámetros correctamente
        if drive_id and drive_id != 'root':
            params['driveid'] = drive_id
            params['item_driveid'] = drive_id
            # Añadir parámetros específicos para shared drives
            params['supportsAllDrives'] = 'true'
            params['includeItemsFromAllDrives'] = 'true'
            params['corpora'] = 'drive'
        else:
            params['driveid'] = 'root'
        
        # Construir la URL completa
        url_params = '&'.join(['%s=%s' % (k, v) for k, v in params.items()])
        plugin_url = 'plugin://plugin.googledrive/?%s' % url_params
        
        xbmc.log('Obteniendo contenido de carpeta: %s' % plugin_url, xbmc.LOGINFO)
        
        # Ejecutar la URL del plugin
        result = execute_plugin_url(plugin_url)
        
        # Verificar si hay un error
        if 'error' in result:
            xbmc.log('Error al obtener contenido de carpeta: %s' % result['error']['message'], xbmc.LOGWARNING)
            return {'folders': [], 'files': []}
        
        # Verificar si hay resultados - Files.GetDirectory devuelve 'result' con 'files'
        if 'result' not in result or 'files' not in result['result']:
            xbmc.log('No se encontraron elementos en la carpeta', xbmc.LOGINFO)
            return {'folders': [], 'files': []}
        
        # Log del contenido bruto para debugging
        files_list = result['result']['files']
        xbmc.log('Elementos encontrados en carpeta: %d' % len(files_list), xbmc.LOGINFO)
        
        # Separar carpetas y archivos
        folders = []
        files = []
        
        for item in files_list:
            # Files.GetDirectory devuelve items con estructura diferente
            item_type = item.get('filetype', 'unknown')
            item_label = item.get('label', item.get('title', 'Sin nombre'))
            item_file = item.get('file', '')
            
            xbmc.log('Procesando item: %s (tipo: %s, mimetype: %s)' % (
                item_label, 
                item_type,
                item.get('mimetype', 'sin mimetype')
            ), xbmc.LOGDEBUG)
            
            if item_type == 'directory':
                # Es una carpeta
                folder_info = {
                    'id': extract_file_id_from_url(item_file),
                    'name': item_label,
                    'thumbnail': item.get('thumbnail', ''),
                    'url': item_file
                }
                folders.append(folder_info)
                xbmc.log('Añadida carpeta: %s' % item_label, xbmc.LOGDEBUG)
                
            elif item_type == 'file':
                # Es un archivo - verificar si es video
                mimetype = item.get('mimetype', '')
                filename = item_label.lower()
                
                # Extensiones de video comunes
                video_extensions = ['.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv', '.webm', '.m4v', '.mpg', '.mpeg', '.3gp', '.ogv', '.ts', '.m2ts']
                
                is_video = False
                if mimetype and mimetype.startswith('video/'):
                    is_video = True
                    xbmc.log('Archivo identificado como video por mimetype: %s' % mimetype, xbmc.LOGDEBUG)
                elif any(ext in filename for ext in video_extensions):
                    is_video = True
                    xbmc.log('Archivo identificado como video por extensión: %s' % filename, xbmc.LOGDEBUG)
                
                if is_video:
                    file_info = {
                        'id': extract_file_id_from_url(item_file),
                        'name': clean_filename(item_label),
                        'mimeType': mimetype,
                        'thumbnail': item.get('thumbnail', ''),
                        'fanart': item.get('fanart', ''),
                        'size': item.get('size', 0),
                        'date': item.get('dateadded', ''),
                        'url': item_file
                    }
                    files.append(file_info)
                    xbmc.log('Añadido archivo de video: %s' % item_label, xbmc.LOGINFO)
                else:
                    xbmc.log('Archivo ignorado (no es video): %s (mimetype: %s)' % (filename, mimetype), xbmc.LOGDEBUG)
        
        # Ordenar por nombre
        folders.sort(key=lambda x: natural_sort_key(x['name']))
        files.sort(key=lambda x: natural_sort_key(x['name']))
        
        xbmc.log('Resultado final: %d carpetas y %d archivos de video' % (len(folders), len(files)), xbmc.LOGINFO)
        
        return {'folders': folders, 'files': files}
        
    except Exception as e:
        xbmc.log('Error al obtener contenido de carpeta de Google Drive: %s' % str(e), xbmc.LOGERROR)
        return {'folders': [], 'files': []}

def get_file_info(file_id, drive_id):
    """
    Obtiene información de un archivo específico.
    
    Args:
        file_id (str): ID del archivo
        drive_id (str): ID del drive
        
    Returns:
        dict: Información del archivo o None si no se encuentra
    """
    try:
        # Construir URL para obtener información del archivo
        params = {
            'action': '_get_file_info',
            'driveid': drive_id,
            'item_driveid': drive_id,
            'item_id': file_id
        }
        
        url = 'plugin://plugin.googledrive/?' + urllib.parse.urlencode(params)
        
        # Intentar obtener información usando JSON-RPC
        request = {
            'jsonrpc': '2.0',
            'method': 'Files.GetFileDetails',
            'params': {
                'file': url,
                'media': 'video',
                'properties': ['title', 'thumbnail', 'fanart', 'file', 'size']
            },
            'id': 1
        }
        
        response = xbmc.executeJSONRPC(json.dumps(request))
        result = json.loads(response)
        
        if 'result' in result and 'filedetails' in result['result']:
            file_details = result['result']['filedetails']
            return {
                'name': file_details.get('title', 'Video'),
                'thumbnail': file_details.get('thumbnail', ''),
                'fanart': file_details.get('fanart', ''),
                'size': file_details.get('size', 0)
            }
        else:
            # Fallback: devolver información básica
            return {
                'name': f'Video_{file_id[:8]}',
                'thumbnail': '',
                'fanart': '',
                'size': 0
            }
            
    except Exception as e:
        xbmc.log(f'[AniCat] Error al obtener información del archivo {file_id}: {str(e)}', xbmc.LOGWARNING)
        # Devolver información básica en caso de error
        return {
            'name': f'Video_{file_id[:8]}',
            'thumbnail': '',
            'fanart': '',
            'size': 0
        }
