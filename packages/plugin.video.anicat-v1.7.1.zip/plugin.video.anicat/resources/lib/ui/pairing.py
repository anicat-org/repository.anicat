import os
import time
import uuid

import pyqrcode
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.core import pairing
from resources.lib.core.library_sync import sync as sync_library


MESSAGE_XML = 'anicat_pairing_message.xml'
QR_XML = 'anicat_pairing_qr.xml'
GLOBAL_PROPERTY = 'AniCat.PairingDialogOpen'
ACTION_CLOSE = (10, 92, 13)


class _Expired(Exception):
    pass


class PairingMessageDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self._heading = kwargs.pop('heading', 'AniCAT')
        self._message = kwargs.pop('message', '')
        self._confirm_mode = kwargs.pop('confirm', False)
        self.result = False
        super(PairingMessageDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        self.getControl(9010).setLabel(self._heading)
        self.getControl(9020).setText(self._message.replace('\n', '[CR]'))
        self.getControl(9008).setVisible(self._confirm_mode)
        self.getControl(9008).setEnabled(self._confirm_mode)
        self.getControl(9009).setLabel('Continuar' if self._confirm_mode else 'D’acord')
        self.setFocusId(9008 if self._confirm_mode else 9009)

    def onAction(self, action):
        if action.getId() in ACTION_CLOSE:
            self.close()

    def onClick(self, control_id):
        if control_id == 9009:
            self.result = True
            self.close()
        elif control_id == 9008:
            self.close()


class PairingQRDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self._heading = kwargs.pop('heading', 'Vincular amb AniCAT')
        self._uri = kwargs.pop('uri', '')
        self._qr_path = kwargs.pop('qr_path', '')
        self._code = kwargs.pop('code', '')
        self._status = kwargs.pop('status', '')
        self._percent = 0
        self._canceled = False
        self._closed = False
        self._qr_deleted = False
        self._update_count = 0
        super(PairingQRDialog, self).__init__(*args, **kwargs)

    def onInit(self):
        self._apply()
        self.setFocusId(9009)

    def _apply(self):
        try:
            self.getControl(9010).setLabel(self._heading)
            self.getControl(9020).setImage(self._qr_path)
            self.getControl(9021).setImage(os.path.join(_addon_path(), 'resources', 'media', 'icon_round.png'))
            self.getControl(9030).setText(self._uri)
            self.getControl(9040).setLabel(self._code)
            self.getControl(9050).setText(self._status)
            self.getControl(9060).setPercent(self._percent)
        except Exception:
            pass

    def update(self, percent, status):
        if self._closed:
            return
        self._percent = max(0, min(100, int(percent)))
        self._status = status
        self._update_count += 1
        self._apply()

    def iscanceled(self):
        return self._canceled

    def onAction(self, action):
        if action.getId() in ACTION_CLOSE:
            self._canceled = True
            self.close()

    def onClick(self, control_id):
        if control_id == 9009:
            self._canceled = True
            self.close()

    def close(self):
        if not self._closed:
            self._closed = True
            super(PairingQRDialog, self).close()
        self._delete_qr()

    def _delete_qr(self):
        if self._qr_deleted or not self._qr_path:
            return
        self._qr_deleted = True
        _delete_file(self._qr_path)


def _addon_path():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))


def _message(heading, message, confirm=False):
    dialog = PairingMessageDialog(MESSAGE_XML, _addon_path(), 'Default', '720p',
                                  heading=heading, message=message, confirm=confirm)
    global_state = xbmcgui.Window(10000)
    global_state.setProperty(GLOBAL_PROPERTY, 'true')
    try:
        dialog.doModal()
        return dialog.result
    finally:
        del dialog
        global_state.clearProperty(GLOBAL_PROPERTY)


def _confirm(heading, prefix=''):
    return _message(
        heading,
        prefix + 'El compte de Drive s’importarà com a compte dedicat, sense modificar '
        'els altres usuaris de Drive. Les carpetes i els ajustos TMDB d’AniCAT '
        'se substituiran pels del tauler. Vols continuar?',
        confirm=True,
    )


def _delete_file(path):
    try:
        xbmcvfs.delete(path)
    except Exception:
        pass


def _qr_file(uri):
    addon = xbmcaddon.Addon()
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
    xbmcvfs.mkdirs(profile)
    path = os.path.join(profile, 'anicat_pairing_%s.png' % uuid.uuid4().hex)
    try:
        pyqrcode.create(uri, error='H').png(path, scale=6)
    except Exception:
        _delete_file(path)
        raise
    return path


def _authorize(host, name, monitor):
    started = time.monotonic()
    request = pairing.begin_pairing(host, name)
    lifetime = float(request['expires_in'])
    deadline = started + lifetime
    interval = max(5.0, float(request.get('interval', 5)))
    uri = pairing.verification_url(host)
    status = 'Escaneja el QR o obre l’adreça, inicia sessió i introdueix el codi manualment.'
    qr_path = _qr_file(uri)
    dialog = None
    global_state = xbmcgui.Window(10000)
    global_state.setProperty(GLOBAL_PROPERTY, 'true')
    try:
        dialog = PairingQRDialog(QR_XML, _addon_path(), 'Default', '720p',
                                 heading='Vincular amb AniCAT', uri=uri, qr_path=qr_path,
                                 code=request['user_code'], status=status)
        dialog.show()
        next_poll = time.monotonic() + interval
        while not monitor.abortRequested() and not dialog.iscanceled():
            now = time.monotonic()
            if now >= deadline:
                raise _Expired()
            if now < next_poll:
                if monitor.waitForAbort(min(0.25, next_poll - now, deadline - now)):
                    return None
                continue
            try:
                token = pairing.poll_pairing(host, request['device_code'])
            except pairing.PairingError as error:
                if error.code == 'expired_token':
                    raise _Expired() from None
                if error.code == 'slow_down':
                    interval += 5
                    status = 'Esperant autorització; reduint la freqüència de consulta.'
                elif error.code == 'network_error':
                    interval = max(interval, min(60, interval * 2))
                    status = 'Connexió interrompuda. Ho tornarem a provar abans que caduqui.'
                elif error.code == 'authorization_pending':
                    status = 'Esperant que introdueixis el codi al tauler.'
                else:
                    raise
                if monitor.abortRequested() or dialog.iscanceled():
                    return None
                now = time.monotonic()
                if now >= deadline:
                    raise _Expired()
                dialog.update(int(100 * (now - started) / lifetime), status)
                next_poll = now + interval
            else:
                if monitor.abortRequested() or dialog.iscanceled():
                    return None
                if time.monotonic() >= deadline:
                    raise _Expired()
                return token
        return None
    finally:
        if dialog is None:
            _delete_file(qr_path)
        else:
            dialog.close()
        global_state.clearProperty(GLOBAL_PROPERTY)


def show(args=None, refresh=True):
    monitor = xbmc.Monitor()
    try:
        if xbmc.Player().isPlaying() is True:
            _message('Atura la reproducció', 'Atura el vídeo abans de canviar la vinculació del compte.')
            return False
        addon = xbmcaddon.Addon()
        host = pairing.normalize_host(addon.getSetting('anicat_host') or pairing.DEFAULT_HOST)
        name = addon.getSetting('anicat_device_name').strip() or 'Kodi'
        prefix = 'Aquest dispositiu ja està vinculat. Se substituirà la vinculació actual. ' if pairing.is_linked() else ''
        if not _confirm('Vincular amb AniCAT', 'Servidor: ' + host + '\n' + prefix):
            return False
        if host.startswith('http://') and not _message(
            'Connexió local de proves',
            'HTTP no xifra les credencials. Utilitza’l només en una xarxa de proves de confiança. '
            'localhost apunta al dispositiu on s’obre: al mòbil no és l’ordinador de Kodi. '
            'Per escanejar el QR des d’un altre dispositiu, configura una IP local accessible. '
            'Vols continuar amb ' + host + '?',
            confirm=True,
        ):
            return False
        if monitor.abortRequested():
            return False
        token = _authorize(host, name, monitor)
        if token is None or monitor.abortRequested():
            return False
        try:
            pairing.complete_pairing(host, token)
        except pairing.PairingError as error:
            _message(
                'No s’ha pogut aplicar la configuració',
                str(error) + '\nSi la vinculació s’ha desat, fes servir «Sincronitzar el compte AniCAT» '
                'per tornar-ho a provar sense generar un altre codi.',
            )
            return False
        try:
            sync_library()
        except Exception:
            xbmc.log('[AniCAT] Biblioteca pendent de sincronització.', xbmc.LOGWARNING)
        _message('AniCAT vinculat', 'El compte ja està disponible. El progrés i La meva llista se sincronitzen automàticament.')
        if refresh:
            xbmc.executebuiltin('Container.Refresh')
        return True
    except _Expired:
        _message('Codi caducat', 'Torna a obrir l’assistent per obtenir un codi nou.')
    except pairing.PairingError as error:
        _message('No s’ha pogut vincular AniCAT', str(error))
    except Exception:
        _message('No s’ha pogut vincular AniCAT', 'No s’ha pogut completar l’assistent. Comprova la connexió i el mòdul QR.')
    return False


def sync_account(args=None, refresh=True):
    try:
        if not pairing.is_linked():
            _message('Compte no vinculat', 'Fes servir «Vincular amb AniCAT» abans de sincronitzar.')
            return False
        if not _confirm('Sincronitzar el compte AniCAT') or xbmc.Monitor().abortRequested():
            return False
        pairing.sync_config()
        sync_library()
        _message('AniCAT sincronitzat', 'S’ha aplicat la configuració del tauler del compte vinculat.')
        if refresh:
            xbmc.executebuiltin('Container.Refresh')
        return True
    except pairing.PairingError as error:
        _message('No s’ha pogut sincronitzar AniCAT', str(error))
    except Exception:
        _message('No s’ha pogut sincronitzar AniCAT', 'Torna-ho a provar més tard des de «Sincronitzar el compte AniCAT».')
    return False
