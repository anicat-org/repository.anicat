"""Independent assistants for local Google authorization and LAN transfer."""
import time
import webbrowser
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.core import drive_local, drive_peer, pairing


def _message(heading, message, confirm=False):
    from resources.lib.ui.pairing import _message as custom_message
    return custom_message(heading, message, confirm=confirm)


def _progress():
    from resources.lib.ui.windows.setup_progress import progress_dialog
    return progress_dialog()


def show_menu(args=None):
    from resources.lib.ui.windows.context_menu import choose
    while True:
        options = []
        if device_role() != 'tv' and desktop_supported():
            options.extend([('Connectar Google en aquest PC', connect), ('Enviar Drive a un altre Kodi', send)])
        options.extend([('Rebre Drive des d’un altre Kodi', receive), ('Tipus de dispositiu', select_role)])
        selected = choose([{'label': label, 'icon': 'folder'} for label, _ in options], 'Google Drive · AniCAT')
        if selected not in range(len(options)):
            return
        options[selected][1]()


def select_role():
    from resources.lib.ui.windows.context_menu import choose
    selected = choose(['Automàtic', 'Ordinador', 'Televisor', 'Mòbil o tauleta'], 'Tipus de dispositiu')
    if selected in range(4):
        xbmcaddon.Addon().setSetting('anicat_device_role', str(selected))


def show_settings_menu():
    from resources.lib.ui.windows.context_menu import choose
    addon = xbmcaddon.Addon()
    while True:
        watched = addon.getSetting('auto_mark_watched') == 'true'
        resume = addon.getSetting('resume_prompt') == 'true'
        choice = choose(['Tipus de dispositiu', 'Marcar com a vist: ' + ('Sí' if watched else 'No'),
                         'Preguntar abans de reprendre: ' + ('Sí' if resume else 'No'), 'Ajustos avançats'], 'Ajustos d’AniCAT')
        if choice < 0:
            return
        if choice == 0:
            select_role()
        elif choice in (1, 2):
            key, current = ('auto_mark_watched', watched) if choice == 1 else ('resume_prompt', resume)
            addon.setSetting(key, 'false' if current else 'true')
        elif choice == 3:
            addon.openSettings()


def device_role():
    selected = xbmcaddon.Addon().getSetting('anicat_device_role')
    if selected in ('1', '2', '3'):
        return {'1': 'pc', '2': 'tv', '3': 'mobile'}[selected]
    if xbmc.getCondVisibility('System.Platform.Android'):
        return 'unknown'
    return 'pc' if desktop_supported() else 'unknown'


def desktop_supported():
    return not xbmc.getCondVisibility('System.Platform.Android') and any(
        xbmc.getCondVisibility('System.Platform.' + platform) for platform in ('Windows', 'OSX', 'Linux'))


def _credentials():
    addon = xbmcaddon.Addon()
    client_id = addon.getSetting('google_desktop_client_id').strip()
    secret = addon.getSetting('google_desktop_client_secret').strip()
    if not client_id and pairing.is_linked():
        with pairing._database() as db:
            session = pairing._session(db)
            config = pairing._request(session['host'], '/api/addon/config', token=session['token'])
        desktop = config.get('google_desktop', {})
        if desktop.get('type') != 'desktop':
            raise ValueError('Actualitza la API per configurar OAuth local.')
        client_id = desktop.get('client_id', '')
        secret = desktop.get('client_secret', '')
    if not client_id:
        raise ValueError('Falta el client OAuth d’escriptori. Configura’l als ajustos de Google Drive o al servidor AniCAT.')
    return client_id, secret


def _authorize():
    if not desktop_supported():
        raise ValueError('Aquest flux necessita Kodi en Windows, macOS o Linux amb navegador. Utilitza «Rebre Drive des d’un altre Kodi».')
    auth = drive_local.DesktopAuthorization(*_credentials())
    dialog = _progress()
    try:
        dialog.create('Connectar Google Drive', 'Autoritza Google al navegador d’aquest ordinador. No obris aquest enllaç al mòbil.')
        if not webbrowser.open(auth.url, new=2):
            raise ValueError('No s’ha pogut obrir el navegador d’aquest ordinador.')
        monitor = xbmc.Monitor()
        end = time.monotonic() + 300
        while not monitor.abortRequested() and not dialog.iscanceled() and time.monotonic() < end:
            tokens = auth.poll()
            if tokens:
                return tokens
        return None
    finally:
        auth.close()
        dialog.close()


def connect(args=None):
    try:
        if xbmc.Player().isPlaying():
            raise ValueError('Atura la reproducció abans de canviar el compte de Drive.')
        tokens = _authorize()
        if tokens:
            drive_local.install(tokens)
            _message('Google Drive', 'Connectat en aquest Kodi. Les credencials de Drive no s’han enviat a Ani.cat.')
    except Exception as error:
        _error(error)


def receive(args=None):
    receiver = None
    dialog = _progress()
    try:
        if xbmc.Player().isPlaying():
            raise ValueError('Atura la reproducció abans de canviar el compte de Drive.')
        addon = xbmcaddon.Addon()
        from resources.lib.ui.windows.context_menu import choose
        short = False
        if pairing.is_linked():
            method = choose(['Amb el compte AniCAT · PIN de 6 xifres', 'Per IP · codi de connexió llarg'], 'Com vols rebre Drive?')
            if method < 0:
                return
            short = method == 0
        receiver = drive_peer.Receiver(addon.getSetting('anicat_device_name') or 'Kodi')
        ip = xbmc.getIPAddress()
        advertisement = {'address': '%s:%d' % (ip, receiver.server.server_port), 'role': device_role()}
        if short:
            advertisement.update(session=receiver.session, public_key=receiver.public_key)
        announced = _directory(advertisement)
        short = short and announced.get('ok') is True and announced.get('_secure_origin') is True
        if not short and 'public_key' in advertisement:
            _directory({'address': advertisement['address'], 'role': advertisement['role']})
        receiver.short_enabled = short
        code = receiver.pin if short else receiver.code
        label = 'PIN' if short else 'Codi per IP'
        dialog.create('Rebre Google Drive', 'Al PC, obre «Enviar Drive a un altre Kodi».\n%s: [B]%s[/B]\nAdreça: %s:%d\nDisponible durant 5 minuts.' % (label, code, ip, receiver.server.server_port))
        monitor = xbmc.Monitor()
        while not dialog.iscanceled() and not monitor.abortRequested() and time.monotonic() < receiver.deadline:
            if receiver.result:
                tokens = receiver.result
                receiver.close()
                receiver = None
                dialog.close()
                # Verify renewal on the receiving platform before declaring success.
                drive_local.install(drive_local.refresh(tokens))
                _message('Google Drive', 'Autorització rebuda i comprovada amb Google. Aquest Kodi ja té accés local a Drive.')
                return
            if receiver.attempts >= 5:
                raise ValueError('Massa intents incorrectes. Torna a obrir el receptor per generar un codi nou.')
            monitor.waitForAbort(0.2)
    except Exception as error:
        _error(error)
    finally:
        _directory({})
        dialog.close()
        if receiver:
            receiver.close()


def send(args=None):
    try:
        dialog = xbmcgui.Dialog()
        from resources.lib.ui.windows.context_menu import choose
        trusted = None
        while True:
            directory = _directory()
            peers = [dict(p) for p in directory.get('devices', directory.get('peers', []))]
            endpoints = {p.get('address') for p in peers}
            try:
                for peer in drive_peer.discover():
                    if peer['address'] not in endpoints:
                        peers.append(peer)
            except OSError:
                pass
            peers.sort(key=lambda p: not bool(p.get('address')))
            options = [{'label': ('[COLOR FF66DD99][B]%s · Preparat per rebre[/B][/COLOR]' % p['name'])
                        if p.get('address') else ('[COLOR FF999999]%s · En espera…[/COLOR]' % p['name']),
                        'icon': 'play' if p.get('address') else 'folder'} for p in peers]
            choice = choose(options + [{'label': 'Introduir IP i port', 'icon': 'edit'},
                                       {'label': 'Actualitzar dispositius', 'icon': 'reset'}], 'Els meus Kodi')
            if choice < 0:
                return
            if choice == len(peers) + 1:
                continue
            if choice == len(peers):
                endpoint = dialog.input('IP i port del Kodi receptor', defaultt='')
                break
            peer = peers[choice]
            if not peer.get('address'):
                _message('Preparar el receptor', 'Obre «Rebre Drive des d’un altre Kodi» en aquest dispositiu i actualitza la llista.')
                continue
            endpoint = peer['address']
            if directory.get('_secure_origin') is True and peer.get('public_key') and peer.get('session'):
                trusted = peer
            break
        if not endpoint:
            return
        endpoint = drive_peer.address(endpoint)
        if trusted:
            from resources.lib.ui.windows.pin_dialog import ask_pin
            code = ask_pin()
        else:
            code = dialog.input('Codi llarg que mostra el Kodi receptor', type=xbmcgui.INPUT_ALPHANUM).strip()
        if not code:
            return
        if not _message('Enviar Google Drive', 'Autoritzaràs Drive per al Kodi a %s. Confirma que el codi prové de la seva pantalla. El receptor custodiarà l’accés a Drive.' % endpoint, confirm=True):
            return
        # Fresh desktop consent for this transfer; never copy AniCAT bearer tokens.
        tokens = _authorize()
        if tokens:
            drive_peer.send(endpoint, code, tokens, trusted_peer=trusted)
            _message('Transferència rebuda', 'Comprova la confirmació de Google Drive a la pantalla del Kodi receptor. No s’ha desat una còpia d’aquesta autorització al PC.')
    except Exception as error:
        _error(error)


def _error(error):
    # HTTP exceptions can contain callback URLs or provider data; never display them.
    message = str(error) if isinstance(error, (ValueError, pairing.PairingError)) else 'No s’ha pogut completar. Revisa el client OAuth, la connexió i que el receptor continuï obert. Entre VLAN cal permetre TCP 48763.'
    _message('Google Drive', message)


def _directory(data=None):
    """Optional account-scoped rendezvous. Only private address/role leave Kodi."""
    try:
        if pairing.is_linked():
            with pairing._database() as db:
                session = pairing._session(db)
                result = pairing._request(session['host'], '/api/addon/peers', data, session['token'])
                result['_secure_origin'] = session['host'].startswith('https://')
                return result
    except Exception:
        pass  # Broadcast/manual IP still work when Ani.cat is unavailable.
    return {}
