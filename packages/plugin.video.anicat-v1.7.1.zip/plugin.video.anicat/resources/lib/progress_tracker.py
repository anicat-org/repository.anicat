# -*- coding: utf-8 -*-
"""
Módulo para el seguimiento del progreso de visualización de los usuarios.
Guarda y recupera el tiempo de reproducción de los vídeos.
"""

import xbmc
import xbmcaddon
import xbmcvfs
import json
import os
import time
import sqlite3
import threading
from datetime import datetime

# Obtener la instancia del addon
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = addon.getAddonInfo('id')

# Directorio de datos del usuario
user_data_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))

# Asegurarse de que el directorio existe
if not xbmcvfs.exists(user_data_dir):
    xbmcvfs.mkdirs(user_data_dir)

# Ruta de la base de datos
db_path = os.path.join(user_data_dir, 'progress.db')

# Lock global para operaciones de base de datos
db_lock = threading.Lock()

def get_db_connection():
    return sqlite3.connect(db_path)

def init_database():
    """
    Inicializa la base de datos si no existe.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Crear tabla de progreso si no existe
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS progress (
            file_id TEXT PRIMARY KEY,
            title TEXT,
            resume_time INTEGER,
            total_time INTEGER,
            last_played INTEGER,
            thumbnail TEXT,
            fanart TEXT,
            type TEXT,
            series_id TEXT,
            season_id TEXT,
            episode_number INTEGER
        )
        ''')
        
        # Crear tabla de carpetas de watchlist si no existe
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS watchlist_folders (
            folder_id TEXT PRIMARY KEY,
            drive_id TEXT,
            title TEXT,
            thumbnail TEXT,
            fanart TEXT,
            added_date INTEGER
        )
        ''')
        
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log('Error al inicializar la base de datos: %s' % str(e), xbmc.LOGERROR)

# Inicializar la base de datos al cargar el módulo
init_database()

def get_resume_time(file_id):
    """
    Obtiene el tiempo de reanudación para un archivo específico.
    
    Args:
        file_id (str): ID del archivo
        
    Returns:
        int: Tiempo de reanudación en segundos, 0 si no hay progreso guardado
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT resume_time FROM progress 
            WHERE file_id = ? AND resume_time > 0
        ''', (file_id,))
        
        result = cursor.fetchone()
        conn.close()
        
        return result[0] if result else 0
        
    except Exception as e:
        xbmc.log(f'[AniCat] Error al obtener tiempo de reanudación: {str(e)}', xbmc.LOGERROR)
        return 0

def get_in_progress_items(limit=20):
    """
    Obtiene los elementos que están en progreso.
    
    Args:
        limit (int): El número máximo de elementos a devolver.
        
    Returns:
        list: Una lista de diccionarios con la información de los elementos en progreso.
    """
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT * FROM progress 
        WHERE resume_time > 0 AND resume_time < total_time * 0.95
        ORDER BY last_played DESC
        LIMIT ?
        ''', (limit,))
        
        items = []
        for row in cursor.fetchall():
            items.append(dict(row))
        
        conn.close()
        
        return items
    except Exception as e:
        xbmc.log('Error al obtener elementos en progreso: %s' % str(e), xbmc.LOGERROR)
        return []

def register_playback_start(file_id, title="", thumbnail="", fanart="", file_type="movie", series_id="", season_id="", episode_number=0):
    """
    Registra el inicio de la reproducción de un archivo.
    
    Args:
        file_id (str): El ID del archivo.
        title (str): El título del archivo.
        thumbnail (str): La URL de la miniatura.
        fanart (str): La URL del fanart.
        file_type (str): El tipo de archivo (movie o episode).
        series_id (str): El ID de la serie (solo para episodios).
        season_id (str): El ID de la temporada (solo para episodios).
        episode_number (int): El número del episodio (solo para episodios).
    """
    try:
        xbmc.log(f'[AniCat] === REGISTER_PLAYBACK_START ===', xbmc.LOGINFO)
        xbmc.log(f'[AniCat] file_id: {file_id}', xbmc.LOGINFO)
        xbmc.log(f'[AniCat] title: {title}', xbmc.LOGINFO)
        xbmc.log(f'[AniCat] file_type: {file_type}', xbmc.LOGINFO)
        xbmc.log(f'[AniCat] series_id: {series_id}', xbmc.LOGINFO)
        
        # Verificar que tenemos un file_id válido
        if not file_id:
            xbmc.log('[AniCat] ERROR: file_id está vacío', xbmc.LOGERROR)
            return
        
        # Obtener el tiempo de reanudación anterior si existe
        resume_time = get_resume_time(file_id)
        xbmc.log(f'[AniCat] Resume time obtenido: {resume_time}', xbmc.LOGINFO)
        
        # Usar lock para evitar concurrencia
        with db_lock:
            # Guardar la información inicial en la base de datos
            xbmc.log('[AniCat] Obteniendo conexión a DB...', xbmc.LOGINFO)
            conn = get_db_connection()
            cursor = conn.cursor()
            
            # Verificar que la tabla existe
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='progress'")
            table_exists = cursor.fetchone()
            xbmc.log(f'[AniCat] Tabla progress existe: {table_exists is not None}', xbmc.LOGINFO)
            
            if not table_exists:
                xbmc.log('[AniCat] ERROR: Tabla progress no existe, reinicializando DB...', xbmc.LOGERROR)
                conn.close()
                init_database()
                conn = get_db_connection()
                cursor = conn.cursor()
            
            # Insertar/actualizar registro
            xbmc.log('[AniCat] Ejecutando INSERT OR REPLACE...', xbmc.LOGINFO)
            cursor.execute('''
            INSERT OR REPLACE INTO progress 
            (file_id, title, resume_time, total_time, last_played, thumbnail, fanart, type, series_id, season_id, episode_number) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                file_id, 
                title, 
                resume_time, 
                1,  # total_time = 1 para evitar división por cero, se actualizará cuando se obtenga del reproductor
                int(time.time()), 
                thumbnail, 
                fanart, 
                file_type, 
                series_id, 
                season_id, 
                episode_number
            ))
            
            # Verificar que se insertó
            rows_affected = cursor.rowcount
            xbmc.log(f'[AniCat] Filas afectadas: {rows_affected}', xbmc.LOGINFO)
            
            conn.commit()
            xbmc.log('[AniCat] Commit realizado', xbmc.LOGINFO)
            
            # Verificar que el registro existe
            cursor.execute('SELECT * FROM progress WHERE file_id = ?', (file_id,))
            record = cursor.fetchone()
            if record:
                xbmc.log(f'[AniCat] Registro verificado en DB: {record}', xbmc.LOGINFO)
            else:
                xbmc.log('[AniCat] ERROR: No se encontró el registro después de insertar', xbmc.LOGERROR)
            
            # Contar total de registros
            cursor.execute('SELECT COUNT(*) FROM progress')
            total_count = cursor.fetchone()[0]
            xbmc.log(f'[AniCat] Total registros en progress: {total_count}', xbmc.LOGINFO)
            
            conn.close()
        
        xbmc.log(f'[AniCat] === REGISTER_PLAYBACK_START COMPLETADO ===', xbmc.LOGINFO)
        
    except Exception as e:
        xbmc.log(f'[AniCat] ERROR en register_playback_start: {str(e)}', xbmc.LOGERROR)
        import traceback
        xbmc.log(f'[AniCat] Traceback: {traceback.format_exc()}', xbmc.LOGERROR)

def update_progress_periodically(file_id, player, monitor):
    """
    Actualiza el progreso de reproducción periódicamente.
    
    Args:
        file_id (str): El ID del archivo.
        player (xbmc.Player): El reproductor de Kodi.
        monitor (xbmc.Monitor): El monitor de Kodi.
    """
    try:
        # Actualizar el progreso cada segundo
        while player.isPlayingVideo() and not monitor.abortRequested():
            # Esperar 1 segundo
            if monitor.waitForAbort(1):
                break
            
            # Si el reproductor ya no está reproduciendo, salir
            if not player.isPlayingVideo():
                break
            
            try:
                # Obtener el tiempo actual y total
                current_time = player.getTime()
                total_time = player.getTotalTime()
                
                # Solo actualizar si tenemos tiempos válidos
                if current_time > 0 and total_time > 0:
                    # Usar lock para evitar concurrencia
                    with db_lock:
                        # Actualizar el progreso en la base de datos
                        conn = get_db_connection()
                        cursor = conn.cursor()
                        
                        cursor.execute('''
                        UPDATE progress 
                        SET resume_time = ?, total_time = ?, last_played = ? 
                        WHERE file_id = ?
                        ''', (current_time, total_time, int(time.time()), file_id))
                        
                        conn.commit()
                        conn.close()
            except Exception as e:
                # Continuar si hay un error temporal obteniendo el tiempo
                pass
        
        # Verificar si se completó la reproducción al finalizar
        try:
            if player.isPlayingVideo():
                current_time = player.getTime()
                total_time = player.getTotalTime()
                
                # Si ha visto más del 90% del vídeo, marcar como completado
                if total_time > 0 and current_time / total_time > 0.90:
                    mark_as_watched(file_id)
                else:
                    # Actualizar una última vez
                    conn = get_db_connection()
                    cursor = conn.cursor()
                    
                    cursor.execute('''
                    UPDATE progress 
                    SET resume_time = ?, total_time = ?, last_played = ? 
                    WHERE file_id = ?
                    ''', (current_time, total_time, int(time.time()), file_id))
                    
                    conn.commit()
                    conn.close()
        except Exception as e:
            pass
            
    except Exception as e:
        xbmc.log('Error al actualizar el progreso: %s' % str(e), xbmc.LOGERROR)

def mark_as_watched(file_id):
    """
    Marca un archivo como visto.
    
    Args:
        file_id (str): El ID del archivo.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('UPDATE progress SET resume_time = 0 WHERE file_id = ?', (file_id,))
        
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log('Error al marcar como visto: %s' % str(e), xbmc.LOGERROR)

def mark_as_unwatched(file_id):
    """
    Marca un archivo como no visto.
    
    Args:
        file_id (str): El ID del archivo.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM progress WHERE file_id = ?', (file_id,))
        
        conn.commit()
        conn.close()
    except Exception as e:
        xbmc.log('Error al marcar como no visto: %s' % str(e), xbmc.LOGERROR)

def add_folder_to_watchlist(folder_id, drive_id, title, thumbnail="", fanart=""):
    """
    Añade una carpeta a la lista de 'ver más tarde'.
    
    Args:
        folder_id (str): El ID de la carpeta.
        drive_id (str): El ID del drive.
        title (str): El título de la carpeta.
        thumbnail (str): La URL de la miniatura.
        fanart (str): La URL del fanart.
        
    Returns:
        bool: True si se añadió exitosamente, False en caso contrario.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verificar si la carpeta ya está en la lista
        cursor.execute('SELECT folder_id FROM watchlist_folders WHERE folder_id = ?', (folder_id,))
        if cursor.fetchone():
            conn.close()
            return False  # Ya existe
        
        # Añadir la carpeta
        cursor.execute('''
        INSERT INTO watchlist_folders (folder_id, drive_id, title, thumbnail, fanart, added_date)
        VALUES (?, ?, ?, ?, ?, ?)
        ''', (folder_id, drive_id, title, thumbnail, fanart, int(time.time())))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        xbmc.log('Error al añadir carpeta a watchlist: %s' % str(e), xbmc.LOGERROR)
        return False

def remove_folder_from_watchlist(folder_id):
    """
    Elimina una carpeta de la lista de 'ver más tarde'.
    
    Args:
        folder_id (str): El ID de la carpeta.
        
    Returns:
        bool: True si se eliminó exitosamente, False en caso contrario.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM watchlist_folders WHERE folder_id = ?', (folder_id,))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        xbmc.log('Error al eliminar carpeta de watchlist: %s' % str(e), xbmc.LOGERROR)
        return False

def get_watchlist_folders():
    """
    Obtiene todas las carpetas de la lista de 'ver más tarde'.
    
    Returns:
        list: Una lista de diccionarios con la información de las carpetas.
    """
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('''
        SELECT * FROM watchlist_folders 
        ORDER BY added_date DESC
        ''')
        
        folders = []
        for row in cursor.fetchall():
            folders.append(dict(row))
        
        conn.close()
        return folders
    except Exception as e:
        xbmc.log('Error al obtener carpetas de watchlist: %s' % str(e), xbmc.LOGERROR)
        return []

def is_folder_in_watchlist(folder_id):
    """
    Verifica si una carpeta está en la lista de 'ver más tarde'.
    
    Args:
        folder_id (str): El ID de la carpeta.
        
    Returns:
        bool: True si la carpeta está en la lista, False en caso contrario.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT folder_id FROM watchlist_folders WHERE folder_id = ?', (folder_id,))
        result = cursor.fetchone()
        
        conn.close()
        return result is not None
    except Exception as e:
        xbmc.log('Error al verificar carpeta en watchlist: %s' % str(e), xbmc.LOGERROR)
        return False

def get_continue_watching_items(limit=20):
    """
    Obtiene los elementos para "Seguir viendo" con lógica mejorada.
    Para series, solo muestra el episodio más reciente por carpeta.
    
    Args:
        limit (int): El número máximo de elementos a devolver.
        
    Returns:
        list: Una lista de diccionarios con la información de los elementos para seguir viendo.
    """
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        # Primero, vamos a ver qué hay en la tabla de progreso
        cursor.execute('SELECT COUNT(*) as total FROM progress')
        total_count = cursor.fetchone()[0]
        xbmc.log(f'[AniCat] Total items in progress table: {total_count}', xbmc.LOGINFO)
        
        # Ver cuántos tienen resume_time > 0
        cursor.execute('SELECT COUNT(*) as with_resume FROM progress WHERE resume_time > 0')
        with_resume = cursor.fetchone()[0]
        xbmc.log(f'[AniCat] Items with resume_time > 0: {with_resume}', xbmc.LOGINFO)
        
        # Ver algunos ejemplos de datos
        cursor.execute('SELECT file_id, title, resume_time, total_time, type FROM progress LIMIT 5')
        sample_data = cursor.fetchall()
        for row in sample_data:
            xbmc.log(f'[AniCat] Sample data: {dict(row)}', xbmc.LOGINFO)
        
        # Consulta mejorada: obtener todos los elementos con progreso
        # Incluir elementos con total_time = 0 (metadata no cargada todavía)
        cursor.execute('''
        SELECT * FROM progress 
        WHERE resume_time > 0 
        ORDER BY last_played DESC
        ''')
        
        all_items = cursor.fetchall()
        xbmc.log(f'[AniCat] Raw query returned {len(all_items)} items', xbmc.LOGINFO)
        
        # Procesar en Python para manejar la lógica de series y filtrado
        series_episodes = {}  # series_id -> episodio más reciente
        movies = []
        
        for row in all_items:
            item = dict(row)
            
            # Calcular porcentaje de progreso
            if item['total_time'] > 0:
                item['progress_percent'] = int((item['resume_time'] / item['total_time']) * 100)
                
                # Excluir elementos vistos completamente (>90%)
                if item['progress_percent'] >= 90:
                    xbmc.log(f'[AniCat] Excluyendo elemento visto: {item["title"]} - {item["progress_percent"]}%', xbmc.LOGDEBUG)
                    continue
            else:
                # Para elementos con total_time = 0, mostrar progreso desconocido
                item['progress_percent'] = 0
                xbmc.log(f'[AniCat] Incluyendo elemento sin metadata: {item["title"]}', xbmc.LOGDEBUG)
            
            if item['type'] == 'episode' and item.get('series_id'):
                # Para episodios, mantener solo el más reciente por serie
                series_id = item['series_id']
                if series_id not in series_episodes or item['last_played'] > series_episodes[series_id]['last_played']:
                    series_episodes[series_id] = item
            else:
                # Para películas o episodios sin series_id, añadir directamente
                movies.append(item)
        
        # Combinar resultados
        items = list(series_episodes.values()) + movies
        
        # Ordenar por última reproducción y limitar
        items.sort(key=lambda x: x['last_played'], reverse=True)
        items = items[:limit]
        
        for item in items:
            xbmc.log(f'[AniCat] Continue watching item: {item["title"]} - {item["progress_percent"]}%', xbmc.LOGINFO)
        
        conn.close()
        
        xbmc.log(f'[AniCat] Returning {len(items)} continue watching items', xbmc.LOGINFO)
        return items
    except Exception as e:
        xbmc.log(f'[AniCat] Error al obtener elementos para seguir viendo: {str(e)}', xbmc.LOGERROR)
        import traceback
        xbmc.log(f'[AniCat] Traceback: {traceback.format_exc()}', xbmc.LOGERROR)
        return []
