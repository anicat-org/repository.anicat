# -*- coding: utf-8 -*-
"""Vista de películas."""

import threading
import xbmcaddon
from resources.lib.ui.helpers import (
    get_handle, add_directory_item, add_video_item, end_directory,
    set_content, notify_error, build_url,
    context_mark_watched, context_mark_unwatched,
)
from resources.lib.core import progress, gdrive

addon = xbmcaddon.Addon()


def _fetch_tmdb_async(folder_id, drive_id, folder_name):
    """Fetch TMDB en segon pla, sense bloquejar el llistat."""
    try:
        from resources.lib.core.tmdb_client import resolve_and_cache_series
        resolve_and_cache_series(folder_id, drive_id, folder_name)
    except Exception:
        pass


def show(args):
    handle = get_handle()
    set_content(handle, 'movies')

    movies_folder_id = addon.getSetting('movies_folder_id')
    movies_drive_id = addon.getSetting('movies_drive_id')

    if not movies_folder_id:
        notify_error('La carpeta de pel·lícules no està configurada')
        end_directory(handle)
        return

    contents = gdrive.get_folder_contents(movies_folder_id, movies_drive_id)

    # Subcarpetas (películas en carpeta propia)
    for folder in contents['folders']:
        # Només usar caché existent — mai fer crides HTTP síncrones aquí
        mapping = progress.get_series_map(folder['id'])

        thumb = (mapping or {}).get('thumb_url') or folder.get('thumbnail', '')
        fanart = (mapping or {}).get('fanart_url') or ''

        # Si no hi ha mapeo, llançar fetch async per a la propera vegada
        if not mapping:
            t = threading.Thread(
                target=_fetch_tmdb_async,
                args=(folder['id'], movies_drive_id, folder['name']),
                daemon=True,
            )
            t.start()

        add_directory_item(
            handle,
            folder['name'],
            {
                'mode': 'browse_folder',
                'folder_id': folder['id'],
                'drive_id': movies_drive_id,
                'content_type': 'movies',
                'folder_name': folder['name'],
            },
            thumb=thumb,
            fanart=fanart,
            is_folder=True,
        )

    # Archivos de video directos — sempre via router play_video per al tracking
    for f in contents['files']:
        resume_time = progress.get_resume_time(f['id'])
        play_url = build_url({
            'mode': 'play_video',
            'file_id': f['id'],
            'drive_id': movies_drive_id,
            'content_type': 'movie',
            'folder_name': f['name'],  # títol de la pel·lícula directa
        })
        info = {'title': f['name'], 'mediatype': 'movie'}

        context_menu = [
            context_mark_watched(f['id']),
            context_mark_unwatched(f['id']),
        ]

        add_video_item(
            handle=handle,
            label=f['name'],
            play_url=play_url,
            thumb=f.get('thumbnail', ''),
            fanart=f.get('fanart', ''),
            info=info,
            resume_time=resume_time,
            context_menu=context_menu,
        )

    end_directory(handle)
