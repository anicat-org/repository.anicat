#!/usr/bin/python
# -*- coding: utf-8 -*-
"""
AniCat - Punt d'entrada del plugin.
Manté aquest fitxer curt: només parseja els arguments i delega al router.
"""

import sys
import os
import urllib.parse

# Afegir el directori arrel del addon al sys.path perquè els imports funcionin
_addon_dir = os.path.dirname(os.path.abspath(__file__))
if _addon_dir not in sys.path:
    sys.path.insert(0, _addon_dir)

def _main():
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    mode_list = args.get('mode', [None])
    mode = mode_list[0] if mode_list else None

    from resources.lib.router import dispatch
    dispatch(mode, args)


_main()
