"""Addon-owned progress dialog used by the Drive assistants."""
import os
import xbmcaddon
import xbmcgui
import xbmcvfs


class SetupProgress(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        self.heading = ''
        self.message = ''
        self.canceled = False
        super().__init__(*args, **kwargs)

    def create(self, heading, message):
        self.heading, self.message = heading, message
        self.show()

    def onInit(self):
        self.getControl(9010).setLabel(self.heading)
        self.getControl(9020).setText(self.message.replace('\n', '[CR]'))
        self.setFocusId(9009)

    def iscanceled(self):
        return self.canceled

    def onAction(self, action):
        if action.getId() in (10, 92, 13):
            self.canceled = True
            self.close()

    def onClick(self, control_id):
        if control_id == 9009:
            self.canceled = True
            self.close()


def progress_dialog():
    path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
    return SetupProgress('anicat_setup_progress.xml', os.path.abspath(path), 'Default', '720p')
