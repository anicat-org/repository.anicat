"""Six-digit receiver PIN, entirely within AniCAT's dialog layer."""
import xbmcgui
import xbmcaddon
import xbmcvfs


class PinDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.digits = ''
        self.result = ''

    def onInit(self):
        # Numeric XML labels are Kodi localization IDs, so set literal digits at runtime.
        for digit in range(10):
            self.getControl(9100 + digit).setLabel(str(digit))
        self._update()
        self.setFocusId(9101)

    def _update(self):
        self.getControl(9010).setLabel('  '.join(self.digits.ljust(6, '_')))
        self.getControl(9121).setEnabled(len(self.digits) == 6)

    def onClick(self, control_id):
        if 9100 <= control_id <= 9109:
            self.digits = (self.digits + str(control_id - 9100))[:6]
        elif control_id == 9120:
            self.digits = self.digits[:-1]
        elif control_id == 9121 and len(self.digits) == 6:
            self.result = self.digits
            self.close()
            return
        elif control_id == 9009:
            self.close()
            return
        self._update()
        if len(self.digits) == 6:
            self.setFocusId(9121)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (10, 92, 13):
            self.close()
        elif 58 <= action_id <= 67:
            self.onClick(9100 + action_id - 58)


def ask_pin():
    dialog = PinDialog('anicat_pin.xml', xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')), 'Default', '720p')
    try:
        dialog.doModal()
        return dialog.result
    finally:
        dialog.close()
