"""Recover AniCAT's own windows without reloading Kodi's global skin."""
import xbmc
import xbmcgui


def clear_state():
    state = xbmcgui.Window(10000)
    for name in ('HomeOpen', 'RestoreInProgress', 'ContextMenuOpen', 'PairingDialogOpen'):
        state.clearProperty('AniCat.' + name)


def reload_interface(args=None):
    clear_state()
    xbmc.executebuiltin('ActivateWindow(Videos,plugin://plugin.video.anicat/?restore=1,return)')
