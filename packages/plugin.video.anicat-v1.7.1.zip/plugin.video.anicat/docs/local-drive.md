# Local Drive setup (1.7.0)

## 1.7.1: custom menus and short PIN

Home settings now open addon-owned menus for Drive, device role and common playback preferences. Five menu rows fit without scrolling; larger lists show a page indicator. Progress and confirmation dialogs also use the addon UI, while text/numeric entry uses Kodi's keyboard.

When receiving through a linked AniCAT account, select the account option and enter the receiver's six-digit PIN on the PC. The account directory supplies the receiver's ephemeral RSA-2048 public key and session over authenticated HTTPS. The sender wraps a random AES-256 key using RSA-OAEP/SHA-256 and authenticates/encrypts the PIN and Google tokens with AES-GCM. The receiver checks the PIN online, allows five attempts and one transfer, and expires after five minutes. The PIN is never used as an offline-guessable encryption key. Neither PIN nor private key is sent to Ani.cat. Old clients/manual IP keep the original 80-bit code flow; update both Kodi installations for the short PIN.

The directory additionally lists inactive linked devices by name with instructions to open the receiver. MAC addresses are neither collected nor needed. Routing/firewall requirements are unchanged. HTTPS is required to trust directory public keys; local HTTP setups use the long-code flow.

**Recarregar la interfície AniCAT** is available in the home custom menu, the fallback menu and addon settings. It resets only AniCAT UI flags and reopens its home; it does not restart Kodi or reload the global skin. Modal windows now close in `finally` on errors. This provides recovery, not a claim that every device-specific skin failure has been reproduced or resolved.

This is a new client-side OAuth implementation, not a statement of Google verification or CASA exemption. The desktop-client authorization/refresh on Android TV must be validated with Google before a general rollout. Legacy backend Drive data and endpoints still exist for older installations; this change does not delete them or remove all Drive-derived library metadata from the API.

## Configuration

The API uses **GOOGLE_DESKTOP_CLIENT_ID** and **GOOGLE_DESKTOP_CLIENT_SECRET**, exclusively for the installed desktop client. Both compose files pass these separately from the web client. Authenticated `/addon/config` exposes them under `google_desktop`; it never falls back to the web client's secret. Installed-client credentials are distributed application configuration, not a confidential server secret. The client ID/optional desktop secret can also be entered locally in Kodi settings. Never enter the web client secret there.

Link the AniCAT account using the existing QR for preferences, TMDB, progress and lists. Drive connection is no longer required for approval. To connect Drive on Windows/macOS/Linux with a browser, choose **Connectar Drive amb Google en aquest ordinador**. The browser must be on that computer: OAuth uses loopback, state and PKCE. Cancellation/timeout closes the temporary loopback listener. Android/mobile does not impersonate the desktop platform to initiate this flow.

## PC to TV

1. On TV, open **Rebre Drive des d’un altre Kodi**. It listens for five minutes and shows its address and a random 16-character code.
2. On PC, open **Enviar Drive a un altre Kodi**. Select the receiver or enter its IP and port, then enter the code from the TV.
3. Complete a fresh Google consent on the PC. The PC sends that authorization without retaining a persistent copy of it.
4. The TV checks token renewal directly with Google and verifies Drive access before confirming installation. The PC receipt only confirms delivery: check the TV's final message.

Discovery uses UDP broadcast on 48763, plus optional AniCAT rendezvous restricted to the same account. The API stores only address/role for 300 seconds, lists only unexpired, non-revoked devices, and never relays pairing codes, tokens or encrypted credential payloads. Receiver close withdraws its advertisement; crashes expire by TTL. Inter-VLAN operation requires routing and an allow rule from sender to receiver **TCP 48763**. UDP discovery generally does not cross VLANs, but the account directory/manual IP do. No NAT traversal, public exposure, automatic router changes or cloud credential relay is implemented. IPv4 private addresses are supported.

The transfer code contains 80 random bits. AES-GCM authenticates and encrypts the payload with a session-bound key derived from this code. Discovery does not disclose the code. The HTTP transport contains ciphertext only; redirects and proxies are disabled, and browser Origin requests are refused. Receivers allow five failed submissions and one successful transfer. An authenticated encrypted receipt confirms delivery.

## Storage and device roles

Google tokens live in `drive-local.enc` in the Kodi profile, encrypted with a locally generated key in `drive-local.key`. File permissions are restricted where supported. This is **not OS-keystore-backed protection**: someone with access to the whole profile can recover them. Cloud Drive Common receives only the short-lived access token, with an empty upstream refresh field. AniCAT renews directly with Google. No Google password is ever received.

Device role: Automatic / Computer / TV / Mobile or tablet. Android is ambiguous in Automatic mode; select TV manually. Role changes assistant choices, not branding or the platform's OAuth capabilities. All roles retain the AniCAT skin and account QR. A desktop selection cannot enable desktop OAuth on Android. Revocation isolation between Google grants is not guaranteed.

## Validation

Run `py -m unittest discover -s tests -v` with PyCryptodome (`Cryptodome`) available, plus API tests on `anicat_test` and web build/lint. Tests use synthetic credentials and local sockets; they do not grant real Google access. Real device acceptance requires PC OAuth, TV import and renewal with PC stopped, a routed-VLAN trial, cancel/expiry, existing manual Drive account conflict handling, and account-library synchronization on both devices.
