"""Opt-in LAN discovery and one-use encrypted credential transfer.

The 80-bit pairing secret is displayed only on the receiver, never advertised.
HTTP carries AES-GCM ciphertext; Ani.cat is not a relay. No UPnP port mapping.
"""
import base64
import hashlib
import ipaddress
import json
import re
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.request import Request, ProxyHandler, build_opener
from resources.lib.core.drive_local import seal, unseal, validate

PORT = 48763
DISCOVER = b'ANICAT-DISCOVER-DRIVE-1'


def transfer_key(code, session):
    code = code.replace('-', '').replace(' ', '').upper()
    if not re.fullmatch('[A-Z2-7]{16}', code) or not re.fullmatch('[a-f0-9]{32}', session):
        raise ValueError('Codi de transferència incorrecte.')
    return hashlib.sha256(('anicat-drive-transfer-v1/' + session + '/' + code).encode()).digest()


def address(value):
    host, separator, port = value.strip().partition(':')
    ip = ipaddress.ip_address(host)
    if ip.version != 4 or not any(ip in ipaddress.ip_network(net) for net in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '127.0.0.0/8')):
        raise ValueError('Indica una adreça IPv4 de la xarxa local.')
    port = int(port) if separator else PORT
    if not 1 <= port <= 65535:
        raise ValueError('Port incorrecte.')
    return '%s:%d' % (ip, port)


class Receiver:
    def __init__(self, name, host='0.0.0.0', port=PORT):
        self.session = secrets.token_hex(16)
        raw = base64.b32encode(secrets.token_bytes(10)).decode()
        self.code = '-'.join(raw[i:i + 4] for i in range(0, 16, 4))
        self.key = transfer_key(self.code, self.session)
        self.deadline = time.monotonic() + 300
        self.result = None
        self.attempts = 0
        self.stop = threading.Event()
        owner = self

        class Handler(BaseHTTPRequestHandler):
            def setup(self):
                super().setup()
                self.connection.settimeout(3)

            def log_message(self, *args):
                pass

            def reply(self, status, data):
                self.send_response(status)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())

            def active(self):
                return not owner.stop.is_set() and owner.result is None and owner.attempts < 5 and time.monotonic() < owner.deadline

            def do_GET(self):
                if self.path != '/info' or self.headers.get('Origin') or not self.active():
                    self.reply(403, {})
                    return
                self.reply(200, owner.info)

            def do_POST(self):
                if self.path != '/transfer' or self.headers.get('Origin') or not self.active():
                    self.reply(403, {})
                    return
                owner.attempts += 1
                try:
                    size = int(self.headers.get('Content-Length', '0'))
                    if not 0 < size <= 32768:
                        raise ValueError()
                    body = json.loads(self.rfile.read(size))
                    tokens = unseal(owner.key, body['payload'], owner.session)
                    validate(tokens)
                    owner.result = tokens
                except (ValueError, KeyError, TypeError):
                    self.reply(400, {})
                    return
                # Authenticated receipt avoids mistaking a forged HTTP 200 for success.
                self.reply(200, {'receipt': seal(owner.key, {'received': True}, owner.session)})

        self.server = HTTPServer((host, port), Handler)
        self.server.timeout = 0.3
        self.info = {'version': 1, 'name': str(name)[:80], 'session': self.session, 'port': self.server.server_port}
        self.thread = threading.Thread(target=self._serve, daemon=True)
        self.thread.start()
        self.udp = None
        try:
            self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.udp.bind((host, PORT))
            self.udp.settimeout(0.3)
            self.discovery = threading.Thread(target=self._advertise, daemon=True)
            self.discovery.start()
        except OSError:
            if self.udp:
                self.udp.close()
            self.udp = None  # Manual IP remains available.

    def _serve(self):
        while not self.stop.is_set() and time.monotonic() < self.deadline:
            self.server.handle_request()

    def _advertise(self):
        while not self.stop.is_set() and time.monotonic() < self.deadline:
            try:
                body, peer = self.udp.recvfrom(128)
                if body == DISCOVER and self.result is None:
                    self.udp.sendto(json.dumps(self.info).encode(), peer)
            except socket.timeout:
                pass
            except OSError:
                break

    def close(self):
        self.stop.set()
        self.thread.join(timeout=4)
        self.server.server_close()
        if self.udp:
            self.udp.close()
            self.discovery.join(timeout=1)
        self.key = b''


def discover(seconds=2):
    found = {}
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        sock.settimeout(0.2)
        sock.sendto(DISCOVER, ('255.255.255.255', PORT))
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            try:
                raw, peer = sock.recvfrom(1024)
                item = json.loads(raw)
                endpoint = address(peer[0] + ':' + str(item['port']))
                if item.get('version') == 1 and isinstance(item.get('name'), str):
                    found[endpoint] = {'address': endpoint, 'name': item['name'][:80]}
            except (ValueError, KeyError, TypeError, socket.timeout):
                pass
    return list(found.values())


def _request(endpoint, path, body=None):
    from resources.lib.core.pairing import _NoRedirect
    data = json.dumps(body).encode() if body is not None else None
    with build_opener(ProxyHandler({}), _NoRedirect()).open(
            Request('http://' + address(endpoint) + path, data=data,
                    headers={'Content-Type': 'application/json'}), timeout=5) as response:
        raw = response.read(32769)
        if len(raw) > 32768:
            raise ValueError('Invalid peer response')
        return json.loads(raw)


def send(endpoint, code, tokens):
    validate(tokens)
    info = _request(endpoint, '/info')
    if info.get('version') != 1:
        raise ValueError('Versió del receptor incompatible.')
    session = info['session']
    key = transfer_key(code, session)
    response = _request(endpoint, '/transfer', {'payload': seal(key, tokens, session)})
    if unseal(key, response['receipt'], session) != {'received': True}:
        raise ValueError('El receptor no ha confirmat la transferència.')
