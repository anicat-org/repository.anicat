# -*- coding: utf-8 -*-
"""Vista "Ver más tarde" / Watchlist."""

import urllib.parse
import xbmcaddon
from resources.lib.ui.helpers import (
    get_handle, add_directory_item, end_directory, set_content,
    notify, notify_error, context_remove_watchlist,
)
from resources.lib.core import progress

addon = xbmcaddon.Addon()


def show(args):
    handle = get_handle()
    set_content(handle, 'tvshows')
    from resources.lib.core.tmdb_client import get_watchlist_with_metadata
    items = get_watchlist_with_metadata()

    if not items:
        add_directory_item(
            handle,
            addon.getLocalizedString(30021),
            {'mode': 'dummy'},
            is_folder=False,
        )
        end_directory(handle)
        return

    for item in items:
        context_menu = [context_remove_watchlist(item['folder_id'])]
        add_directory_item(
            handle,
            item['title'],
            {
                'mode': 'watchlist_item',
                'item_id': item['folder_id'],
            },
            thumb=item.get('thumbnail') or '',
            fanart=item.get('fanart') or '',
            is_folder=True,
            context_menu=context_menu,
        )

    end_directory(handle)


def add(args):
    folder_id = args.get('folder_id', [None])[0]
    drive_id = args.get('drive_id', [None])[0]
    folder_name = args.get('folder_name', ['Carpeta'])[0]
    folder_name = urllib.parse.unquote(folder_name)

    if not folder_id or not drive_id:
        notify_error('Paràmetres invàlids')
        return

    if progress.is_in_watchlist(folder_id):
        notify(addon.getLocalizedString(30023) % folder_name if '%s' in addon.getLocalizedString(30023) else f'"{folder_name}" ja és a Veure més tard')
        return

    # Intentar obtener thumbnail del series_map
    thumbnail = ''
    fanart = ''
    mapping = progress.get_series_map(folder_id)
    if mapping:
        thumbnail = mapping.get('thumb_url', '')
        fanart = mapping.get('fanart_url', '')

    success = progress.add_to_watchlist(folder_id, drive_id, folder_name, thumbnail, fanart)
    if success:
        notify(addon.getLocalizedString(30022) % folder_name if '%s' in addon.getLocalizedString(30022) else f'"{folder_name}" afegida a Veure més tard')
    else:
        notify_error(addon.getLocalizedString(30024))


def remove(args):
    folder_id = args.get('folder_id', [None])[0]
    if not folder_id:
        notify_error('ID de carpeta no proporcionat')
        return

    success = progress.remove_from_watchlist(folder_id)
    if success:
        notify(addon.getLocalizedString(30025))
        import xbmc
        xbmc.executebuiltin('Container.Refresh')
    else:
        notify_error('Error eliminant de la llista')
