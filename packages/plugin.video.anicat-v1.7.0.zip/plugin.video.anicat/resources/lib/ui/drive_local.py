"""Independent assistants for local Google authorization and LAN transfer."""
import time
import webbrowser
import xbmc
import xbmcaddon
import xbmcgui
from resources.lib.core import drive_local, drive_peer, pairing


def device_role():
    selected = xbmcaddon.Addon().getSetting('anicat_device_role')
    if selected in ('1', '2', '3'):
        return {'1': 'pc', '2': 'tv', '3': 'mobile'}[selected]
    if xbmc.getCondVisibility('System.Platform.Android'):
        return 'unknown'
    return 'pc' if desktop_supported() else 'unknown'


def desktop_supported():
    return not xbmc.getCondVisibility('System.Platform.Android') and any(
        xbmc.getCondVisibility('System.Platform.' + platform) for platform in ('Windows', 'OSX', 'Linux'))


def _credentials():
    addon = xbmcaddon.Addon()
    client_id = addon.getSetting('google_desktop_client_id').strip()
    secret = addon.getSetting('google_desktop_client_secret').strip()
    if not client_id and pairing.is_linked():
        with pairing._database() as db:
            session = pairing._session(db)
            config = pairing._request(session['host'], '/api/addon/config', token=session['token'])
        desktop = config.get('google_desktop', {})
        if desktop.get('type') != 'desktop':
            raise ValueError('Actualitza la API per configurar OAuth local.')
        client_id = desktop.get('client_id', '')
        secret = desktop.get('client_secret', '')
    if not client_id:
        raise ValueError('Falta el client OAuth d’escriptori. Configura’l als ajustos de Google Drive o al servidor AniCAT.')
    return client_id, secret


def _authorize():
    if not desktop_supported():
        raise ValueError('Aquest flux necessita Kodi en Windows, macOS o Linux amb navegador. Utilitza «Rebre Drive des d’un altre Kodi».')
    auth = drive_local.DesktopAuthorization(*_credentials())
    dialog = xbmcgui.DialogProgress()
    try:
        dialog.create('Connectar Google Drive', 'Autoritza Google al navegador d’aquest ordinador. No obris aquest enllaç al mòbil.')
        if not webbrowser.open(auth.url, new=2):
            raise ValueError('No s’ha pogut obrir el navegador d’aquest ordinador.')
        monitor = xbmc.Monitor()
        end = time.monotonic() + 300
        while not monitor.abortRequested() and not dialog.iscanceled() and time.monotonic() < end:
            tokens = auth.poll()
            if tokens:
                return tokens
        return None
    finally:
        auth.close()
        dialog.close()


def connect(args=None):
    try:
        if xbmc.Player().isPlaying():
            raise ValueError('Atura la reproducció abans de canviar el compte de Drive.')
        tokens = _authorize()
        if tokens:
            drive_local.install(tokens)
            xbmcgui.Dialog().ok('Google Drive', 'Connectat en aquest Kodi. Les credencials de Drive no s’han enviat a Ani.cat.')
    except Exception as error:
        _error(error)


def receive(args=None):
    receiver = None
    dialog = xbmcgui.DialogProgress()
    try:
        if xbmc.Player().isPlaying():
            raise ValueError('Atura la reproducció abans de canviar el compte de Drive.')
        addon = xbmcaddon.Addon()
        receiver = drive_peer.Receiver(addon.getSetting('anicat_device_name') or 'Kodi')
        ip = xbmc.getIPAddress()
        _directory({'address': '%s:%d' % (ip, receiver.server.server_port), 'role': device_role()})
        dialog.create('Rebre Google Drive', 'Al PC, obre «Enviar Drive a un altre Kodi».\nCodi: %s\nAdreça: %s:%d\nDisponible durant 5 minuts.' % (receiver.code, ip, receiver.server.server_port))
        monitor = xbmc.Monitor()
        while not dialog.iscanceled() and not monitor.abortRequested() and time.monotonic() < receiver.deadline:
            if receiver.result:
                tokens = receiver.result
                receiver.close()
                receiver = None
                dialog.close()
                # Verify renewal on the receiving platform before declaring success.
                drive_local.install(drive_local.refresh(tokens))
                xbmcgui.Dialog().ok('Google Drive', 'Autorització rebuda i comprovada amb Google. Aquest Kodi ja té accés local a Drive.')
                return
            if receiver.attempts >= 5:
                raise ValueError('Massa intents incorrectes. Torna a obrir el receptor per generar un codi nou.')
            monitor.waitForAbort(0.2)
    except Exception as error:
        _error(error)
    finally:
        _directory({})
        dialog.close()
        if receiver:
            receiver.close()


def send(args=None):
    try:
        dialog = xbmcgui.Dialog()
        try:
            peers = drive_peer.discover()
        except OSError:
            peers = []
        endpoints = {p['address'] for p in peers}
        for peer in _directory().get('peers', []):
            if peer['address'] not in endpoints:
                peers.append(peer)
                endpoints.add(peer['address'])
        choice = dialog.select('Kodi que espera rebre Drive', [p['name'] + ' (' + p['address'] + ')' for p in peers] + ['Introduir IP i port (també entre VLAN)'])
        if choice < 0:
            return
        endpoint = peers[choice]['address'] if choice < len(peers) else dialog.input('IP i port del Kodi receptor', defaultt='')
        if not endpoint:
            return
        endpoint = drive_peer.address(endpoint)
        code = dialog.input('Codi de 16 caràcters que mostra el Kodi receptor').strip()
        if not code:
            return
        if not dialog.yesno('Enviar Google Drive', 'Autoritzaràs Drive per al Kodi a %s. Confirma que el codi prové de la seva pantalla. El receptor custodiarà l’accés a Drive.' % endpoint):
            return
        # Fresh desktop consent for this transfer; never copy AniCAT bearer tokens.
        tokens = _authorize()
        if tokens:
            drive_peer.send(endpoint, code, tokens)
            xbmcgui.Dialog().ok('Transferència rebuda', 'Comprova la confirmació de Google Drive a la pantalla del Kodi receptor. No s’ha desat una còpia d’aquesta autorització al PC.')
    except Exception as error:
        _error(error)


def _error(error):
    # HTTP exceptions can contain callback URLs or provider data; never display them.
    message = str(error) if isinstance(error, (ValueError, pairing.PairingError)) else 'No s’ha pogut completar. Revisa el client OAuth, la connexió i que el receptor continuï obert. Entre VLAN cal permetre TCP 48763.'
    xbmcgui.Dialog().ok('Google Drive', message)


def _directory(data=None):
    """Optional account-scoped rendezvous. Only private address/role leave Kodi."""
    try:
        if pairing.is_linked():
            with pairing._database() as db:
                session = pairing._session(db)
                return pairing._request(session['host'], '/api/addon/peers', data, session['token'])
    except Exception:
        pass  # Broadcast/manual IP still work when Ani.cat is unavailable.
    return {}
