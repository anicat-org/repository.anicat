# -*- coding: utf-8 -*-
"""
Overlay visual simplificado para debugging del sistema de tracking en el reproductor Kodi.
Usa directamente la API de Kodi sin necesidad de archivos XML.
"""

import xbmc
import xbmcgui
import xbmcaddon
import time
import threading

class SimpleTrackingOverlay:
    """Overlay visual simplificado usando notificaciones y diálogos."""
    
    def __init__(self):
        self.visible = False
        self.update_thread = None
        self.monitor = xbmc.Monitor()
        
        # Configuración
        self.addon = xbmcaddon.Addon()
        self.addon_name = self.addon.getAddonInfo('name')
        
        # Estado actual
        self.current_file_id = None
        self.tracking_active = False
        self.last_update = 0
        self.current_time = 0
        self.total_time = 0
        self.update_count = 0
        self.errors = []
        
    def show_overlay(self, file_id=None):
        """Muestra el overlay de tracking usando notificaciones."""
        if self.visible:
            return
            
        self.current_file_id = file_id
        self.visible = True
        self.tracking_active = True
        
        # Iniciar thread de actualización
        self.update_thread = threading.Thread(target=self._update_loop)
        self.update_thread.daemon = True
        self.update_thread.start()
        
        xbmc.log(f"[{self.addon_name}] Simple tracking overlay iniciado", xbmc.LOGINFO)
        
        # Mostrar notificación inicial
        xbmcgui.Dialog().notification(
            self.addon_name,
            "Overlay de tracking ACTIVADO",
            xbmcgui.NOTIFICATION_INFO,
            3000
        )
    
    def hide_overlay(self):
        """Oculta el overlay de tracking."""
        self.visible = False
        self.tracking_active = False
        
        if self.update_thread and self.update_thread.is_alive():
            self.update_thread.join(timeout=1)
        
        xbmc.log(f"[{self.addon_name}] Simple tracking overlay detenido", xbmc.LOGINFO)
        
        # Mostrar notificación final
        xbmcgui.Dialog().notification(
            self.addon_name,
            "Overlay de tracking DESACTIVADO",
            xbmcgui.NOTIFICATION_INFO,
            2000
        )
    
    def _update_loop(self):
        """Bucle de actualización del overlay."""
        notification_interval = 10  # Notificar cada 10 actualizaciones
        update_counter = 0
        
        while self.visible and not self.monitor.abortRequested():
            try:
                self._update_status()
                update_counter += 1
                
                # Mostrar notificación periódica con estado
                if update_counter % notification_interval == 0:
                    self._show_status_notification()
                
                if self.monitor.waitForAbort(1):
                    break
                    
            except Exception as e:
                xbmc.log(f"[{self.addon_name}] Error en update_loop: {e}", xbmc.LOGERROR)
                self.errors.append(f"Update error: {e}")
    
    def _update_status(self):
        """Actualiza el estado del tracking."""
        try:
            # Verificar si hay reproducción activa
            player = xbmc.Player()
            is_playing = player.isPlayingVideo()
            
            # Método alternativo JSON-RPC
            if not is_playing:
                try:
                    json_query = '{"jsonrpc":"2.0","method":"Player.GetActivePlayers","id":1}'
                    response = xbmc.executeJSONRPC(json_query)
                    data = xbmc.getJSON(response)
                    if 'result' in data and len(data['result']) > 0:
                        is_playing = any(p.get('type') == 'video' for p in data['result'])
                except:
                    pass
            
            if is_playing:
                try:
                    self.current_time = player.getTime()
                    self.total_time = player.getTotalTime()
                    self.last_update = time.time()
                    self.update_count += 1
                except:
                    # Método alternativo JSON-RPC
                    try:
                        json_query = '''
                        {
                            "jsonrpc": "2.0",
                            "method": "Player.GetProperties",
                            "params": {"playerid": 1, "properties": ["time", "totaltime"]},
                            "id": 1
                        }
                        '''
                        response = xbmc.executeJSONRPC(json_query)
                        data = xbmc.getJSON(response)
                        if 'result' in data:
                            result = data['result']
                            time_data = result.get('time', {})
                            totaltime_data = result.get('totaltime', {})
                            
                            self.current_time = time_data.get('hours', 0) * 3600 + time_data.get('minutes', 0) * 60 + time_data.get('seconds', 0)
                            self.total_time = totaltime_data.get('hours', 0) * 3600 + totaltime_data.get('minutes', 0) * 60 + totaltime_data.get('seconds', 0)
                            self.last_update = time.time()
                            self.update_count += 1
                    except:
                        pass
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error actualizando estado: {e}", xbmc.LOGERROR)
            self.errors.append(f"Status error: {e}")
    
    def _show_status_notification(self):
        """Muestra notificación con el estado actual."""
        try:
            progress_percent = 0
            if self.total_time > 0:
                progress_percent = int((self.current_time / self.total_time) * 100)
            
            # Construir mensaje de estado
            status_lines = [
                f"TRACKING DEBUG",
                f"File: {self.current_file_id or 'N/A'}",
                f"Updates: {self.update_count}",
                f"Time: {self._format_time(self.current_time)} / {self._format_time(self.total_time)}",
                f"Progress: {progress_percent}%"
            ]
            
            if self.errors:
                status_lines.append(f"Errors: {len(self.errors)}")
            
            status_text = " | ".join(status_lines)
            
            # Mostrar notificación
            xbmcgui.Dialog().notification(
                self.addon_name,
                status_text,
                xbmcgui.NOTIFICATION_INFO,
                5000
            )
            
            # También escribir al log
            xbmc.log(f"[{self.addon_name}] {status_text}", xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error mostrando notificación: {e}", xbmc.LOGERROR)
    
    def _format_time(self, seconds):
        """Formatea segundos en formato MM:SS."""
        if seconds <= 0:
            return "00:00"
        
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        secs = int(seconds % 60)
        
        if hours > 0:
            return f"{hours:02d}:{minutes:02d}:{secs:02d}"
        else:
            return f"{minutes:02d}:{secs:02d}"
    
    def add_error(self, error_msg):
        """Añade un error al log."""
        self.errors.append(f"[{time.strftime('%H:%M:%S')}] {error_msg}")
        # Mantener solo los últimos 10 errores
        if len(self.errors) > 10:
            self.errors = self.errors[-10:]
    
    def show_detailed_status(self):
        """Muestra un diálogo con el estado detallado."""
        try:
            progress_percent = 0
            if self.total_time > 0:
                progress_percent = int((self.current_time / self.total_time) * 100)
            
            # Construir texto detallado
            status_text = f"=== TRACKING DEBUG ===\n"
            status_text += f"File ID: {self.current_file_id or 'N/A'}\n"
            status_text += f"File Type: {'Google Drive' if self.current_file_id and len(self.current_file_id) > 10 else 'Other'}\n"
            status_text += f"Tracking: {'✅ ACTIVO' if self.tracking_active else '❌ INACTIVO'}\n"
            status_text += f"Updates: {self.update_count}\n"
            status_text += f"Current Time: {self._format_time(self.current_time)}\n"
            status_text += f"Total Time: {self._format_time(self.total_time)}\n"
            status_text += f"Progress: {progress_percent}%\n"
            status_text += f"Last Update: {time.strftime('%H:%M:%S', time.localtime(self.last_update)) if self.last_update else 'Never'}\n"
            status_text += f"Overlay: {'✅ VISIBLE' if self.visible else '❌ OCULTO'}\n"
            
            if self.errors:
                status_text += f"\n=== ERRORS ({len(self.errors)}) ===\n"
                for i, error in enumerate(self.errors[-3:]):  # Últimos 3 errores
                    status_text += f"  {error}\n"
            
            # Mostrar diálogo
            xbmcgui.Dialog().textviewer("Tracking Debug Status", status_text)
            
        except Exception as e:
            xbmc.log(f"[{self.addon_name}] Error mostrando estado detallado: {e}", xbmc.LOGERROR)

# Instancia global
simple_tracking_overlay = SimpleTrackingOverlay()
