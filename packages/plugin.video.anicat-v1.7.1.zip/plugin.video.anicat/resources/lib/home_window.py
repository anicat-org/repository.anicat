# -*- coding: utf-8 -*-

import os
import threading
import time
import traceback
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib import gdrive_utils
from resources.lib import progress_tracker
from resources.lib.catalog_utils import group_by_initial


ADDON = xbmcaddon.Addon()
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PLUGIN_URL = 'plugin://%s/' % ADDON.getAddonInfo('id')
DEFAULT_THUMB = os.path.join(ADDON_PATH, 'resources', 'media', 'icon.png')
DEFAULT_FANART = os.path.join(ADDON_PATH, 'resources', 'media', 'fanart.jpg')

ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_CONTEXT_MENU = 117

HOME_ROWS = {
    100: 'continue',
    200: 'watchlist',
    300: 'movies',
    400: 'series'
}
CATALOG_LOAD_TIMEOUT = 20


def build_plugin_url(params):
    return PLUGIN_URL + '?' + urllib.parse.urlencode(params)


def _localized(string_id, fallback):
    value = ADDON.getLocalizedString(string_id)
    return value or fallback


def _list_item(
    label,
    action,
    url='',
    thumb='',
    fanart='',
    subtitle='',
    progress=0
):
    item = xbmcgui.ListItem(label=label, label2=subtitle)
    item.setArt({
        'thumb': thumb or DEFAULT_THUMB,
        'poster': thumb or DEFAULT_THUMB,
        'fanart': fanart or thumb or DEFAULT_FANART
    })
    item.setProperty('Action', action)
    item.setProperty('TargetUrl', url)
    item.setProperty('Subtitle', subtitle)
    item.setProperty('Progress', str(max(0, min(100, int(progress or 0)))))
    return item


def _folder_item(folder, drive_id, content_type):
    params = {
        'mode': 'browse_folder',
        'folder_id': folder['id'],
        'drive_id': drive_id,
        'content_type': content_type,
        'folder_name': folder.get('name', ''),
        'thumbnail': folder.get('thumbnail', ''),
        'fanart': folder.get('fanart', '') or folder.get('thumbnail', '')
    }
    return _list_item(
        folder.get('name', ''),
        'browse',
        build_plugin_url(params),
        folder.get('thumbnail', ''),
        folder.get('fanart', '')
    )


def _video_item(video, drive_id, content_type):
    params = {
        'mode': 'play_video',
        'file_id': video['id'],
        'drive_id': drive_id,
        'content_type': content_type,
        'title': video.get('name', '')
    }
    return _list_item(
        video.get('name', ''),
        'play',
        build_plugin_url(params),
        video.get('thumbnail', ''),
        video.get('fanart', '')
    )


def _catalog_source(content):
    source = []
    for folder in content.get('folders', []):
        value = dict(folder)
        value['item_type'] = 'folder'
        source.append(value)
    for video in content.get('files', []):
        value = dict(video)
        value['item_type'] = 'video'
        source.append(value)
    return source


class BaseAniCatWindow(xbmcgui.WindowXML):
    def _selected_item(self, control_id):
        try:
            return self.getControl(control_id).getSelectedItem()
        except RuntimeError:
            return None

    def _update_selection(self, control_id):
        item = self._selected_item(control_id)
        if not item:
            return
        self.setProperty('SelectedTitle', item.getLabel())
        self.setProperty('SelectedSubtitle', item.getProperty('Subtitle'))
        self.setProperty(
            'SelectedFanart',
            item.getArt('fanart') or item.getArt('thumb') or DEFAULT_FANART
        )

    def _run_item(self, item):
        if not item:
            return
        action = item.getProperty('Action')
        target_url = item.getProperty('TargetUrl')
        if action == 'play':
            xbmc.executebuiltin('RunPlugin(%s)' % target_url)
        elif action == 'browse':
            self.close()
            xbmc.executebuiltin(
                'ActivateWindow(Videos,%s,return)' % target_url
            )
        elif action == 'settings':
            ADDON.openSettings()

    def onAction(self, action):
        if action.getId() in (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK):
            self.close()


class AniCatHomeWindow(BaseAniCatWindow):
    def __init__(self, *args, **kwargs):
        self.movies = []
        self.series = []
        self._rows = {}

    def onInit(self):
        self.setProperty('TitleContinue', _localized(30001, 'Seguir viendo'))
        self.setProperty('TitleWatchlist', _localized(30300, 'Mi lista'))
        self.setProperty('TitleMovies', _localized(30002, 'Películas'))
        self.setProperty('TitleSeries', _localized(30003, 'Series'))
        self.setProperty('Loading', _localized(30301, 'Cargando catálogo…'))
        self.setProperty('SelectedFanart', DEFAULT_FANART)
        try:
            self._load_rows()
        except Exception as error:
            xbmc.log(
                '[AniCAT] Error cargando la portada: %s\n%s' % (
                    error,
                    traceback.format_exc()
                ),
                xbmc.LOGERROR
            )
            self._rows = {}
            for control_id in HOME_ROWS:
                control = self.getControl(control_id)
                control.reset()
                control.addItem(self._empty_card())
        self.clearProperty('Loading')
        self.setFocusId(self._first_populated_row())
        self._update_selection(self.getFocusId())

    def _load_rows(self):
        continue_items = progress_tracker.get_continue_watching_items(20)
        watchlist_items = progress_tracker.get_watchlist_folders()

        self._rows = {
            100: self._continue_cards(continue_items),
            200: self._watchlist_cards(watchlist_items),
            300: self._preview_cards('movies', self.movies),
            400: self._preview_cards('series', self.series)
        }

        for control_id, items in self._rows.items():
            self._replace_row(control_id, items)

        for content_type in ('movies', 'series'):
            loader = threading.Thread(
                target=self._load_catalog_row,
                args=(content_type,),
                name='AniCAT-%s' % content_type
            )
            loader.daemon = True
            loader.start()

    def _replace_row(self, control_id, items):
        control = self.getControl(control_id)
        control.reset()
        control.addItems(items or [self._empty_card()])

    def _load_catalog_row(self, content_type):
        started_at = time.monotonic()
        try:
            source = _catalog_source(self._load_catalog(content_type))
            elapsed = time.monotonic() - started_at
            if elapsed > CATALOG_LOAD_TIMEOUT:
                xbmc.log(
                    '[AniCAT] Catálogo %s descartado tras %.1f segundos' % (
                        content_type,
                        elapsed
                    ),
                    xbmc.LOGWARNING
                )
                return

            if content_type == 'movies':
                self.movies = source
                control_id = 300
            else:
                self.series = source
                control_id = 400

            self._replace_row(
                control_id,
                self._preview_cards(content_type, source)
            )

            if content_type == 'series':
                folders = progress_tracker.get_watchlist_folders()
                self._replace_row(200, self._watchlist_cards(folders))
        except Exception as error:
            xbmc.log(
                '[AniCAT] Error cargando catálogo %s: %s\n%s' % (
                    content_type,
                    error,
                    traceback.format_exc()
                ),
                xbmc.LOGERROR
            )

    def _load_catalog(self, content_type):
        folder_id = ADDON.getSetting('%s_folder_id' % content_type)
        drive_id = ADDON.getSetting('%s_drive_id' % content_type)
        if not folder_id:
            return {'folders': [], 'files': []}
        return gdrive_utils.get_folder_contents(folder_id, drive_id)

    def _continue_cards(self, items):
        cards = []
        for item in items:
            is_episode = item.get('type') == 'episode'
            content_type = 'series' if is_episode else 'movies'
            drive_id = ADDON.getSetting('%s_drive_id' % content_type)
            subtitle = '%d%%' % item.get('progress_percent', 0)
            if is_episode and item.get('episode_number', 0):
                subtitle = '%s · %s' % (
                    _localized(30029, 'Episodio %d') % item['episode_number'],
                    subtitle
                )
            params = {
                'mode': 'play_video',
                'file_id': item['file_id'],
                'drive_id': drive_id,
                'content_type': content_type,
                'folder_id': item.get('series_id', ''),
                'title': item.get('title', '')
            }
            cards.append(_list_item(
                item.get('title', ''),
                'play',
                build_plugin_url(params),
                item.get('thumbnail', ''),
                item.get('fanart', ''),
                subtitle,
                item.get('progress_percent', 0)
            ))
        return cards

    def _watchlist_cards(self, folders):
        cards = []
        series_by_id = {
            item.get('id'): item
            for item in self.series
            if item.get('item_type') == 'folder'
        }
        for folder in folders:
            catalog_item = series_by_id.get(folder['folder_id'], {})
            data = {
                'id': folder['folder_id'],
                'name': folder.get('title', ''),
                'thumbnail': (
                    folder.get('thumbnail', '')
                    or catalog_item.get('thumbnail', '')
                ),
                'fanart': (
                    folder.get('fanart', '')
                    or catalog_item.get('fanart', '')
                    or catalog_item.get('thumbnail', '')
                )
            }
            card = _folder_item(data, folder.get('drive_id', ''), 'series')
            card.setProperty('FolderId', folder['folder_id'])
            cards.append(card)
        return cards

    def _preview_cards(self, content_type, source):
        title = _localized(30302, 'Ver todo')
        cards = [_list_item(title, 'catalog')]
        drive_id = ADDON.getSetting('%s_drive_id' % content_type)
        for item in source[:20]:
            if item['item_type'] == 'folder':
                cards.append(_folder_item(item, drive_id, content_type))
            else:
                cards.append(_video_item(item, drive_id, content_type))
        for card in cards:
            card.setProperty('CatalogType', content_type)
        return cards

    def _empty_card(self):
        return _list_item(_localized(30303, 'Sin contenido'), 'none')

    def _first_populated_row(self):
        for control_id in (100, 200, 300, 400):
            if self._rows.get(control_id):
                return control_id
        return 300

    def _open_catalog(self, content_type):
        source = self.movies if content_type == 'movies' else self.series
        window = AniCatCatalogWindow(
            'anicat_catalog.xml',
            ADDON_PATH,
            'Default',
            '720p',
            content_type=content_type,
            source=source
        )
        window.doModal()
        del window
        self._update_selection(self.getFocusId())

    def _remove_from_watchlist(self):
        item = self._selected_item(200)
        folder_id = item.getProperty('FolderId') if item else ''
        if not folder_id:
            return
        remove_label = _localized(30026, 'Eliminar de Mi lista')
        if xbmcgui.Dialog().contextmenu([remove_label]) != 0:
            return
        if progress_tracker.remove_folder_from_watchlist(folder_id):
            control = self.getControl(200)
            control.reset()
            folders = progress_tracker.get_watchlist_folders()
            cards = self._watchlist_cards(folders)
            self._rows[200] = cards
            control.addItems(cards or [self._empty_card()])
            self._update_selection(200)

    def onFocus(self, control_id):
        if control_id in HOME_ROWS:
            self._update_selection(control_id)

    def onClick(self, control_id):
        if control_id == 50:
            ADDON.openSettings()
            self._load_rows()
            return
        if control_id not in HOME_ROWS:
            return
        item = self._selected_item(control_id)
        if item and item.getProperty('Action') == 'catalog':
            self._open_catalog(item.getProperty('CatalogType'))
            return
        self._run_item(item)

    def onAction(self, action):
        if action.getId() == ACTION_CONTEXT_MENU and self.getFocusId() == 200:
            self._remove_from_watchlist()
            return
        super(AniCatHomeWindow, self).onAction(action)


class AniCatCatalogWindow(BaseAniCatWindow):
    def __init__(self, *args, **kwargs):
        self.content_type = kwargs.get('content_type', 'series')
        self.source = kwargs.get('source', [])
        self.groups = {}
        self.letters = []
        self.letter_index = 0

    def onInit(self):
        title_id = 30002 if self.content_type == 'movies' else 30003
        title = _localized(title_id, self.content_type.title())
        self.setProperty('CatalogTitle', title)
        self.setProperty('SelectedFanart', DEFAULT_FANART)
        self.groups = group_by_initial(self.source)
        self.letters = sorted(
            self.groups,
            key=lambda value: (value == '#', value)
        )
        if not self.letters:
            self.letters = ['#']
            self.groups['#'] = []
        self._show_letter(0)
        self.setFocusId(50)

    def _show_letter(self, index):
        self.letter_index = index % len(self.letters)
        letter = self.letters[self.letter_index]
        previous_index = (self.letter_index - 1) % len(self.letters)
        previous_letter = self.letters[previous_index]
        next_letter = self.letters[(self.letter_index + 1) % len(self.letters)]
        self.setProperty('CurrentLetter', letter)
        self.setProperty('PreviousLetter', previous_letter)
        self.setProperty('NextLetter', next_letter)

        drive_id = ADDON.getSetting('%s_drive_id' % self.content_type)
        cards = []
        for item in self.groups.get(letter, []):
            if item.get('item_type') == 'folder':
                cards.append(_folder_item(item, drive_id, self.content_type))
            else:
                cards.append(_video_item(item, drive_id, self.content_type))

        control = self.getControl(50)
        control.reset()
        control.addItems(cards or [
            _list_item(_localized(30303, 'Sin contenido'), 'none')
        ])
        control.selectItem(0)
        self.setProperty('RowCount', str(len(cards)))
        self._update_selection(50)

    def onFocus(self, control_id):
        if control_id == 50:
            self._update_selection(50)

    def onClick(self, control_id):
        if control_id == 50:
            self._run_item(self._selected_item(50))

    def onAction(self, action):
        action_id = action.getId()
        if self.getFocusId() == 50 and action_id == ACTION_MOVE_UP:
            self._show_letter(self.letter_index - 1)
            return
        if self.getFocusId() == 50 and action_id == ACTION_MOVE_DOWN:
            self._show_letter(self.letter_index + 1)
            return
        super(AniCatCatalogWindow, self).onAction(action)


def show_home():
    window = AniCatHomeWindow(
        'anicat_home.xml',
        ADDON_PATH,
        'Default',
        '720p'
    )
    window.doModal()
    del window
