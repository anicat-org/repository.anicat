# -*- coding: utf-8 -*-
"""
Cliente de TMDB (The Movie Database).
Requiere API key configurada por el usuario en settings.xml.
Implementa caché SQLite con TTL de 7 días.
"""

import json
import time
import re
from difflib import SequenceMatcher
import xbmc
import xbmcaddon

try:
    from urllib.request import urlopen, Request
    from urllib.parse import urlencode, quote
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError
    from urllib import urlencode, quote

_BASE_URL = 'https://api.themoviedb.org/3'
_IMG_BASE = 'https://image.tmdb.org/t/p'
_CACHE_TTL = 7 * 24 * 3600  # 7 días en segundos
_TIMEOUT = 10  # segundos

addon = xbmcaddon.Addon()


def _get_api_key():
    return addon.getSetting('tmdb_api_key').strip()


def _get_language():
    lang = addon.getSetting('tmdb_language') or 'es-ES'
    return lang


# ------------------------------------------------------------------
# Caché
# ------------------------------------------------------------------

def _cache_get(key):
    try:
        from resources.lib.core.progress import get_db_connection
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            'SELECT data_json FROM tmdb_cache WHERE cache_key = ? AND expires_at > ?',
            (key, int(time.time()))
        )
        row = cursor.fetchone()
        conn.close()
        if row:
            return json.loads(row['data_json'])
    except Exception as e:
        xbmc.log(f'[AniCat] tmdb_cache_get error: {e}', xbmc.LOGDEBUG)
    return None


def _cache_set(key, data, ttl=_CACHE_TTL):
    try:
        from resources.lib.core.progress import get_db_connection, _db_lock
        with _db_lock:
            conn = get_db_connection()
            conn.execute('''
                INSERT INTO tmdb_cache (cache_key, data_json, expires_at)
                VALUES (?, ?, ?)
                ON CONFLICT(cache_key) DO UPDATE SET
                    data_json  = excluded.data_json,
                    expires_at = excluded.expires_at
            ''', (key, json.dumps(data), int(time.time()) + ttl))
            conn.commit()
            conn.close()
    except Exception as e:
        xbmc.log(f'[AniCat] tmdb_cache_set error: {e}', xbmc.LOGDEBUG)


# ------------------------------------------------------------------
# HTTP
# ------------------------------------------------------------------

def _api_get(endpoint, params=None):
    """Hace una petición GET a la API de TMDB con caché."""
    api_key = _get_api_key()
    if not api_key:
        xbmc.log('[AniCat] TMDB: API key no configurada', xbmc.LOGWARNING)
        return None

    params = dict(params or {})
    params['api_key'] = api_key
    params['language'] = _get_language()

    query = urlencode(params)
    url = f'{_BASE_URL}{endpoint}?{query}'

    cache_key = endpoint + '?' + urlencode({key: value for key, value in params.items() if key != 'api_key'})
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached

    try:
        req = Request(url, headers={'User-Agent': 'AniCat/1.0 Kodi'})
        with urlopen(req, timeout=_TIMEOUT) as resp:
            data = json.loads(resp.read().decode('utf-8'))
        _cache_set(cache_key, data)
        return data
    except URLError as e:
        xbmc.log(f'[AniCat] TMDB request failed: {endpoint}', xbmc.LOGWARNING)
        return None
    except Exception as e:
        xbmc.log(f'[AniCat] TMDB response error: {endpoint}', xbmc.LOGWARNING)
        return None


# ------------------------------------------------------------------
# Imágenes
# ------------------------------------------------------------------

def poster_url(path, size='w342'):
    """Construye la URL completa de un póster."""
    if not path:
        return ''
    return f'{_IMG_BASE}/{size}{path}'


def fanart_url(path, size='w1280'):
    """Construye la URL completa de un fanart."""
    if not path:
        return ''
    return f'{_IMG_BASE}/{size}{path}'


# ------------------------------------------------------------------
# Búsqueda
# ------------------------------------------------------------------

def search_series(query, year=None):
    """
    Busca series en TMDB.
    Devuelve lista de dicts: {tmdb_id, title, year, poster_url, fanart_url, overview}.
    """
    params = {'query': query}
    if year:
        params['first_air_date_year'] = year

    data = _api_get('/search/tv', params)
    if not data:
        return []

    results = []
    for item in data.get('results', [])[:20]:
        tmdb_id = item.get('id', 0)
        poster = poster_url(item.get('poster_path', ''))
        # Obtener fanart de los detalles (más lento pero más preciso)
        fanart = fanart_url(item.get('backdrop_path', ''))
        first_air = item.get('first_air_date', '')
        results.append({
            'tmdb_id': tmdb_id,
            'title': item.get('name', ''),
            'original_title': item.get('original_name', ''),
            'year': first_air[:4] if first_air else '',
            'poster_url': poster,
            'fanart_url': fanart,
            'overview': item.get('overview', ''),
        })

    xbmc.log(f'[AniCat] TMDB search_series "{query}": {len(results)} resultados', xbmc.LOGDEBUG)
    return results


def search_movie(query, year=None):
    """
    Busca películas en TMDB.
    Devuelve lista de dicts: {tmdb_id, title, year, poster_url, fanart_url, overview}.
    """
    params = {'query': query}
    if year:
        params['year'] = year

    data = _api_get('/search/movie', params)
    if not data:
        return []

    results = []
    for item in data.get('results', [])[:20]:
        release = item.get('release_date', '')
        results.append({
            'tmdb_id': item.get('id', 0),
            'title': item.get('title', ''),
            'original_title': item.get('original_title', ''),
            'year': release[:4] if release else '',
            'poster_url': poster_url(item.get('poster_path', '')),
            'fanart_url': fanart_url(item.get('backdrop_path', '')),
            'overview': item.get('overview', ''),
        })

    xbmc.log(f'[AniCat] TMDB search_movie "{query}": {len(results)} resultados', xbmc.LOGDEBUG)
    return results


# ------------------------------------------------------------------
# Detalles
# ------------------------------------------------------------------

def get_series_details(tmdb_id):
    """
    Obtiene detalles completos de una serie: temporadas, episodios, imágenes.
    Devuelve dict con 'seasons' como lista de dicts.
    """
    data = _api_get(f'/tv/{tmdb_id}')
    if not data:
        return None

    seasons = []
    for s in data.get('seasons', []):
        if s.get('season_number', 0) == 0:
            continue  # saltar especiales
        seasons.append({
            'season_number': s['season_number'],
            'name': s.get('name', f'Temporada {s["season_number"]}'),
            'episode_count': s.get('episode_count', 0),
            'poster_url': poster_url(s.get('poster_path', '')),
        })

    return {
        'tmdb_id': tmdb_id,
        'title': data.get('name', ''),
        'overview': data.get('overview', ''),
        'poster_url': poster_url(data.get('poster_path', '')),
        'fanart_url': fanart_url(data.get('backdrop_path', '')),
        'seasons': seasons,
        'number_of_seasons': data.get('number_of_seasons', 0),
        'number_of_episodes': data.get('number_of_episodes', 0),
        'status': data.get('status', ''),
        'genres': [g['name'] for g in data.get('genres', [])],
    }


def get_season_episodes(tmdb_id, season_number):
    """
    Obtiene los episodios de una temporada concreta.
    Devuelve lista de dicts: {episode_number, name, overview, still_url, air_date}.
    """
    data = _api_get(f'/tv/{tmdb_id}/season/{season_number}')
    if not data:
        return []

    episodes = []
    for ep in data.get('episodes', []):
        episodes.append({
            'episode_number': ep.get('episode_number', 0),
            'name': ep.get('name', ''),
            'overview': ep.get('overview', ''),
            'still_url': poster_url(ep.get('still_path', ''), size='w300'),
            'air_date': ep.get('air_date', ''),
        })
    return episodes


def get_movie_details(tmdb_id):
    """Obtiene detalles completos de una película."""
    data = _api_get(f'/movie/{tmdb_id}')
    if not data:
        return None

    release = data.get('release_date', '')
    return {
        'tmdb_id': tmdb_id,
        'title': data.get('title', ''),
        'original_title': data.get('original_title', ''),
        'year': release[:4] if release else '',
        'overview': data.get('overview', ''),
        'poster_url': poster_url(data.get('poster_path', '')),
        'fanart_url': fanart_url(data.get('backdrop_path', '')),
        'runtime': data.get('runtime', 0),
        'genres': [g['name'] for g in data.get('genres', [])],
        'rating': data.get('vote_average', 0),
    }


# ------------------------------------------------------------------
# Helper: buscar y guardar mapeo para una carpeta del Drive
# ------------------------------------------------------------------

def _title_key(title):
    from resources.lib.catalog_utils import normalized_title
    return ' '.join(re.findall(r"\w+", normalized_title(title)))


def match_score(query, candidate, year=''):
    key = _title_key(query)
    scores = []
    for title in (candidate.get('title', ''), candidate.get('original_title', '')):
        other = _title_key(title)
        if not key or not other:
            continue
        # Sequels must not silently inherit the first film's poster.
        if re.findall(r'\b\d+\b', key) != re.findall(r'\b\d+\b', other):
            scores.append(0.0)
            continue
        if key == other:
            scores.append(1.0)
        elif len(key) < 5:
            scores.append(0.0)
        else:
            scores.append(max(SequenceMatcher(None, key, other).ratio(),
                              0.96 if set(key.split()) == set(other.split()) else 0.0))
    score = max(scores, default=0.0)
    if year and candidate.get('year') and str(year) != str(candidate['year']):
        score -= 0.18
    return score


def select_match(query, candidates, year=''):
    ranked = sorted(((match_score(query, item, year), item) for item in candidates),
                    key=lambda pair: pair[0], reverse=True)
    if not ranked or ranked[0][0] < 0.78:
        return None
    if len(ranked) > 1 and ranked[0][0] - ranked[1][0] < 0.06:
        return None
    return ranked[0][1]


def resolve_metadata(item_id, drive_id, raw_name, content_type='series', cancelled=None):
    """Resolve films and shows separately; cache successful and empty searches."""
    from resources.lib.core.name_parser import parse_search_name
    from resources.lib.core import progress
    kind = 'movie' if content_type in ('movie', 'movies') else 'series'
    movie_folder = content_type == 'movies'
    manual = _cache_get('manual:%s:%s:%s' % (kind, item_id, _get_language()))
    if manual:
        return manual
    scope = 'movie-folder' if movie_folder else kind
    version = 'v4' if movie_folder else 'v3'
    key = 'resolve:%s:%s:%s:%s:%s' % (version, scope, item_id, _get_language(), raw_name)
    cached = _cache_get(key)
    if cached is not None:
        return cached or None
    if not _get_api_key():
        return None
    parsed = parse_search_name(raw_name)
    best = None
    matched_kind = kind
    for candidate_kind in ([kind, 'series'] if movie_folder else [kind]):
        search = search_movie if candidate_kind == 'movie' else search_series
        for query in parsed['queries'][:2]:
            if cancelled and cancelled():
                return None
            results = search(query, year=parsed['year'] or None)
            best = select_match(query, results, parsed['year'])
            if not best and parsed['year'] and not (cancelled and cancelled()):
                results = search(query)
                best = select_match(query, results, parsed['year'])
            if best:
                matched_kind = candidate_kind
                break
        if best:
            break
    if not best:
        # Retry unresolved names sooner than successful metadata (including outages).
        if not (cancelled and cancelled()):
            _cache_set(key, {}, ttl=3600)
        return None
    details = get_movie_details(best['tmdb_id']) if matched_kind == 'movie' else get_series_details(best['tmdb_id'])
    merged = dict(best)
    for field, value in (details or {}).items():
        if value:
            merged[field] = value
    merged['thumb_url'] = merged.get('poster_url', '')
    merged['content_type'] = matched_kind
    _cache_set(key, merged)
    _cache_set('item:%s:%s:%s' % (kind, item_id, _get_language()), merged)
    if kind == 'series':
        progress.save_series_map(item_id, drive_id, merged['tmdb_id'], merged['title'],
                                 merged['thumb_url'], merged.get('fanart_url', ''))
    return merged


def resolve_and_cache_series(folder_id, drive_id, raw_folder_name):
    return resolve_metadata(folder_id, drive_id, raw_folder_name, 'series')


def cached_metadata(item_id, kind):
    return (_cache_get('manual:%s:%s:%s' % (kind, item_id, _get_language()))
            or _cache_get('item:%s:%s:%s' % (kind, item_id, _get_language())))


def get_watchlist_with_metadata():
    """Reuse resolved artwork locally, including TV matches for movie folders."""
    from resources.lib.core import progress
    rows = []
    for saved in progress.get_watchlist():
        row = dict(saved)
        kind = 'movie' if row.get('content_type') in ('movie', 'movies') else 'series'
        metadata = cached_metadata(row['folder_id'], kind)
        if metadata:
            row['source_name'] = row.get('source_name') or row.get('title', '')
            row.update(title=metadata.get('title') or row.get('title', ''),
                       thumbnail=metadata.get('thumb_url') or metadata.get('poster_url') or '',
                       fanart=metadata.get('fanart_url', ''), tmdb_id=metadata.get('tmdb_id', 0))
            if any(row.get(key) != saved.get(key) for key in ('title', 'thumbnail', 'fanart', 'tmdb_id', 'source_name')):
                # Keep the resolved cover when the temporary TMDB cache expires.
                _update_saved_metadata({'id': row['folder_id'], 'name': row['source_name'],
                                        'display_title': row['title'], 'thumb': row['thumbnail'],
                                        'fanart': row['fanart'], 'tmdb_id': row['tmdb_id']})
        rows.append(row)
    return rows


def save_manual_metadata(source, candidate):
    from resources.lib.core import progress
    kind = 'movie' if source.get('content_type') in ('movie', 'movies') else 'series'
    matched_kind = candidate.get('content_type', kind) if source.get('content_type') == 'movies' else kind
    details = get_movie_details(candidate['tmdb_id']) if matched_kind == 'movie' else get_series_details(candidate['tmdb_id'])
    metadata = dict(candidate)
    metadata.update({key: value for key, value in (details or {}).items() if value})
    metadata['thumb_url'] = metadata.get('poster_url', '')
    metadata['content_type'] = matched_kind
    _cache_set('manual:%s:%s:%s' % (kind, source['id'], _get_language()), metadata, ttl=10 * 365 * 86400)
    _apply_metadata(source, metadata)
    if kind == 'series':
        progress.save_series_map(source['id'], source.get('drive_id', ''), metadata['tmdb_id'],
                                 metadata['title'], metadata['thumb_url'], metadata.get('fanart_url', ''))
    _update_saved_metadata(source)
    return metadata


def _apply_metadata(source, metadata):
    from resources.lib.core.name_parser import parse_search_name
    raw = source.get('folder_name') or source['name']
    source.update(display_title=metadata.get('title') or parse_search_name(raw)['title'],
                  thumb=metadata.get('thumb_url', ''), fanart=metadata.get('fanart_url', ''),
                  meta=metadata.get('overview', ''), tmdb_id=metadata.get('tmdb_id', 0),
                  year=metadata.get('year', ''))


def _update_saved_metadata(source):
    from resources.lib.core import progress
    with progress._db_lock:
        conn = progress.get_db_connection()
        try:
            conn.execute('''UPDATE watchlist SET title=?, thumbnail=?, fanart=?, tmdb_id=?,
                            source_name=CASE WHEN COALESCE(source_name, '')='' THEN ? ELSE source_name END
                            WHERE folder_id=?''',
                         (source['display_title'], source['thumb'], source['fanart'],
                          source['tmdb_id'], source.get('folder_name') or source['name'], source['id']))
            conn.commit()
        finally:
            conn.close()


def has_manual_metadata(source):
    kind = 'movie' if source.get('content_type') in ('movie', 'movies') else 'series'
    return bool(_cache_get('manual:%s:%s:%s' % (kind, source['id'], _get_language())))


def reset_manual_metadata(source):
    """Remove this item's overrides and derived cache, then resolve its original name."""
    from resources.lib.core import progress
    kind = 'movie' if source.get('content_type') in ('movie', 'movies') else 'series'
    prefixes = ['manual:%s:%s:' % (kind, source['id']), 'item:%s:%s:' % (kind, source['id']),
                'resolve:v3:%s:%s:' % (kind, source['id']),
                'resolve:v4:movie-folder:%s:' % source['id']]
    with progress._db_lock:
        conn = progress.get_db_connection()
        try:
            for prefix in prefixes:
                conn.execute('DELETE FROM tmdb_cache WHERE substr(cache_key, 1, ?) = ?', (len(prefix), prefix))
            if kind == 'series':
                conn.execute('DELETE FROM series_map WHERE folder_id = ?', (source['id'],))
            conn.commit()
        finally:
            conn.close()
    # Clear the old title/art even if the automatic lookup is unavailable.
    _apply_metadata(source, {})
    _update_saved_metadata(source)
    raw = source.get('folder_name') or source['name']
    metadata = resolve_metadata(source['id'], source.get('drive_id', ''), raw,
                                source.get('content_type', 'series')) or {}
    _apply_metadata(source, metadata)
    _update_saved_metadata(source)
    return metadata


def enrich_catalog(items, cancelled=None):
    """Resolve catalog entries with bounded parallel requests and cached results."""
    from concurrent.futures import ThreadPoolExecutor
    from resources.lib.core.name_parser import parse_search_name
    def enrich(source):
        item = dict(source)
        raw = item.get('folder_name') or item.get('name', '')
        metadata = {}
        if not (cancelled and cancelled()):
            try:
                metadata = resolve_metadata(item['id'], item.get('drive_id', ''), raw,
                                            item.get('content_type', 'series'), cancelled=cancelled) or {}
            except Exception:
                xbmc.log('[AniCat] Metadata unavailable for an item; keeping catalog accessible', xbmc.LOGWARNING)
        item['display_title'] = metadata.get('title') or item.get('display_title') or parse_search_name(raw)['title']
        # A missing poster is preferable to an unrelated video frame.
        item['thumb'] = metadata.get('thumb_url') or (item.get('thumb', '') if item.get('content_type') == 'series' else '')
        item['fanart'] = metadata.get('fanart_url') or item.get('fanart', '')
        item['meta'] = metadata.get('overview') or item.get('meta', '')
        item['tmdb_id'] = metadata.get('tmdb_id', 0)
        item['year'] = metadata.get('year', '')
        return item
    with ThreadPoolExecutor(max_workers=4) as pool:
        return list(pool.map(enrich, items))
