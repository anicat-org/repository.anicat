# -*- coding: utf-8 -*-
"""
AniCat HomeWindow — portada principal con accesos y filas de contenido.
"""

import os
import json

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.core import progress
from resources.lib.ui.windows.card_art import set_card_art, is_direct_movie


addon = xbmcaddon.Addon()
_addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
_default_thumb = os.path.join(_addon_path, 'resources', 'media', 'icon.png')
_default_fanart = os.path.join(_addon_path, 'resources', 'media', 'fanart.jpg')

WINDOW_XML = 'anicat_home.xml'

CTRL_NAV = 50
CTRL_CONTINUE = 100
CTRL_WATCHLIST = 200
CTRL_SETTINGS = 8
CTRL_CLOSE = 9
ACTION_CONTEXT_MENU = 117

_CATEGORIES = [
    {
        'label': 'Pel·lícules',
        'subtitle': 'Explora el catàleg de pel·lícules',
        'mode': 'movies',
        'icon': 'DefaultMovies.png',
    },
    {
        'label': 'Sèries',
        'subtitle': 'Explora el catàleg de sèries i anime',
        'mode': 'series',
        'icon': 'DefaultTVShows.png',
    },
]


class HomeWindow(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(HomeWindow, self).__init__(*args, **kwargs)
        self._result = None
        self._has_continue = False
        self._has_watchlist = False

    def onInit(self):
        self.setProperty('SelectedFanart', _default_fanart)
        self.setProperty('SelectedTitle', 'AniCat')
        self.setProperty('SelectedSubtitle', "El teu catàleg d'anime en català")
        self._populate_navigation()
        self._populate_continue_watching()
        self._populate_watchlist()
        initial_control = (
            CTRL_CONTINUE if self._has_continue
            else CTRL_WATCHLIST if self._has_watchlist
            else CTRL_NAV
        )
        self.setFocusId(initial_control)
        self._update_selection(initial_control)

    def _populate_navigation(self):
        control = self.getControl(CTRL_NAV)
        control.reset()
        for category in _CATEGORIES:
            item = xbmcgui.ListItem(category['label'])
            item.setArt({
                'icon': category['icon'],
                'thumb': _default_thumb,
                'fanart': _default_fanart,
            })
            item.setProperty('Action', 'mode')
            item.setProperty('Mode', category['mode'])
            item.setProperty('Subtitle', category['subtitle'])
            control.addItem(item)
        control.selectItem(0)

    def _series_art(self, series_id, thumbnail='', fanart=''):
        mapping = progress.get_series_map(series_id) if series_id else None
        thumbnail = thumbnail or (mapping or {}).get('thumb_url', '')
        fanart = fanart or (mapping or {}).get('fanart_url', '')
        return thumbnail or _default_thumb, fanart or thumbnail or _default_fanart

    def _card(self, label, subtitle, thumbnail, fanart, action, properties=None,
              progress_percent=0):
        item = xbmcgui.ListItem(label)
        set_card_art(item, thumbnail, fanart, landscape=action == 'play')
        item.setProperty('Action', action)
        item.setProperty('Subtitle', subtitle)
        progress_percent = max(0, min(100, int(progress_percent)))
        item.setProperty('Progress', str(progress_percent))
        item.setProperty('PercentPlayed', str(progress_percent))
        item.setProperty('ProgressWidth', str(int(204 * progress_percent / 100)))
        item.getVideoInfoTag().setResumePoint(float(progress_percent), 100.0)
        for key, value in (properties or {}).items():
            item.setProperty(key, str(value or ''))
        return item

    def _empty_card(self, label, landscape=False):
        item = self._card(
            label,
            '',
            _default_thumb,
            _default_fanart,
            'none',
        )
        if landscape:
            set_card_art(item, landscape=True)
        return item

    def _populate_continue_watching(self):
        from resources.lib.core.resume_frames import frame_for_progress
        from resources.lib.core.tmdb_client import cached_metadata
        control = self.getControl(CTRL_CONTINUE)
        control.reset()
        items = progress.get_continue_watching_items(20)
        self._has_continue = bool(items)
        for data in items:
            is_episode = data.get('type') == 'episode'
            series_id = data.get('series_id', '')
            metadata = cached_metadata(series_id if is_episode else data['file_id'],
                                       'series' if is_episode else 'movie') or {}
            mapping = (progress.get_series_map(series_id) or {}) if is_episode and series_id else {}
            fanart = metadata.get('fanart_url') or mapping.get('fanart_url') or data.get('fanart', '')
            if fanart and fanart in (metadata.get('thumb_url'), mapping.get('thumb_url'), data.get('thumbnail')):
                fanart = ''
            # Only the card uses the captured frame; the page retains TMDB fanart.
            thumbnail = frame_for_progress(data) or fanart
            fanart = fanart or _default_fanart
            percent = data.get('progress_percent', 0)
            subtitle = f'{percent}% reproduït'
            if is_episode and data.get('episode_number', 0):
                subtitle = f'Episodi {data["episode_number"]} · {subtitle}'
            if data.get('queued') and not percent:
                subtitle = 'Següent episodi · Per començar'
            drive_id = addon.getSetting(
                'series_drive_id' if is_episode else 'movies_drive_id'
            )
            control.addItem(self._card(
                data.get('title') or data['file_id'],
                subtitle,
                thumbnail,
                fanart,
                'play',
                {
                    'FileId': data['file_id'],
                    'DriveId': drive_id,
                    'ContentType': 'episode' if is_episode else 'movie',
                    'SeriesId': series_id,
                    'EpisodeNumber': data.get('episode_number', 0),
                },
                percent,
            ))
        if not items:
            control.addItem(self._empty_card('Encara no has començat cap vídeo', landscape=True))
        control.selectItem(0)

    def _populate_watchlist(self):
        control = self.getControl(CTRL_WATCHLIST)
        control.reset()
        from resources.lib.core.tmdb_client import get_watchlist_with_metadata
        items = get_watchlist_with_metadata()
        self._has_watchlist = bool(items)
        for data in items:
            thumbnail, fanart = self._series_art(
                data['folder_id'] if data.get('content_type', 'series') == 'series' else '',
                data.get('thumbnail', ''),
                data.get('fanart', ''),
            )
            control.addItem(self._card(
                data.get('title') or data['folder_id'],
                'Pel·lícula · Reproduir' if is_direct_movie(data) else 'Veure més tard',
                thumbnail,
                fanart,
                'watchlist_item',
                {
                    'FolderId': data['folder_id'],
                    'DriveId': data.get('drive_id', ''),
                    'SavedItem': json.dumps(data),
                    'IsDirectMovie': 'true' if is_direct_movie(data) else '',
                },
            ))
        if not items:
            control.addItem(self._empty_card('La teva llista és buida'))
        control.selectItem(0)

    def _selected_item(self, control_id):
        try:
            return self.getControl(control_id).getSelectedItem()
        except (RuntimeError, AttributeError):
            return None

    def _update_selection(self, control_id):
        item = self._selected_item(control_id)
        if not item:
            return
        self.setProperty('SelectedTitle', item.getLabel())
        self.setProperty('SelectedSubtitle', item.getProperty('Subtitle'))
        self.setProperty(
            'SelectedFanart',
            item.getArt('fanart') or item.getArt('thumb') or _default_fanart,
        )

    def _select_item(self, control_id):
        item = self._selected_item(control_id)
        if not item:
            return
        action = item.getProperty('Action')
        if action == 'none':
            return
        if action == 'mode':
            self._result = {
                'action': 'mode',
                'mode': item.getProperty('Mode'),
            }
        elif action == 'watchlist_item':
            from resources.lib.ui.windows.window_router import watchlist_source
            self._result = {'action': 'watchlist_item',
                            'item': watchlist_source(json.loads(item.getProperty('SavedItem')))}
        elif action == 'play':
            self._result = {
                'action': 'play',
                'file_id': item.getProperty('FileId'),
                'drive_id': item.getProperty('DriveId'),
                'content_type': item.getProperty('ContentType'),
                'folder_id': item.getProperty('SeriesId'),
                'folder_name': item.getLabel(),
                'episode_number': int(item.getProperty('EpisodeNumber') or 0),
            }
        elif action == 'series':
            self._result = {
                'action': 'series',
                'folder_id': item.getProperty('FolderId'),
                'drive_id': item.getProperty('DriveId'),
                'folder_name': item.getLabel(),
                'series_title': item.getLabel(),
                'series_fanart': item.getArt('fanart'),
            }
        self.close()

    def _refresh_row(self, control_id, selected_position):
        if control_id == CTRL_CONTINUE:
            self._populate_continue_watching()
        elif control_id == CTRL_WATCHLIST:
            self._populate_watchlist()
        control = self.getControl(control_id)
        item_count = control.size()
        control.selectItem(min(selected_position, max(0, item_count - 1)))
        self.setFocusId(control_id)
        self._update_selection(control_id)

    def _open_context_menu(self, control_id):
        from resources.lib.ui.windows.context_menu import choose
        if control_id not in (CTRL_CONTINUE, CTRL_WATCHLIST):
            return
        control = self.getControl(control_id)
        item = control.getSelectedItem()
        if not item or item.getProperty('Action') == 'none':
            return
        selected_position = control.getSelectedPosition()
        if control_id == CTRL_CONTINUE:
            options = [{'label': 'Eliminar de Seguir veient', 'icon': 'remove'}]
            if item.getProperty('ContentType') == 'episode' and item.getProperty('SeriesId'):
                options.append({'label': 'Veure la sèrie', 'icon': 'folder'})
            choice = choose(options, item.getLabel(), owner=self)
            if choice == 1 and len(options) > 1:
                series_id = item.getProperty('SeriesId')
                mapping = progress.get_series_map(series_id) or {}
                episodes = progress.get_episode_playlist(series_id)
                series_title = mapping.get('title') or next((ep.get('series_name') for ep in episodes
                                                             if ep.get('series_name')), 'Sèrie')
                self._result = {'action': 'series', 'folder_id': series_id,
                                'drive_id': mapping.get('drive_id') or item.getProperty('DriveId'),
                                'folder_name': series_title, 'series_title': series_title,
                                'series_fanart': mapping.get('fanart_url') or item.getArt('fanart')}
                self.close()
                return
            if choice != 0:
                return
            progress.mark_as_unwatched(item.getProperty('FileId'))
        else:
            if choose([{'label': 'Eliminar de La meva llista', 'icon': 'remove'}],
                      item.getLabel(), owner=self) != 0:
                return
            progress.remove_from_watchlist(item.getProperty('FolderId'))
        self._refresh_row(control_id, selected_position)

    def onFocus(self, control_id):
        if control_id in (CTRL_NAV, CTRL_CONTINUE, CTRL_WATCHLIST):
            self._update_selection(control_id)

    def onAction(self, action):
        action_id = action.getId()
        if action_id == ACTION_CONTEXT_MENU:
            self._open_context_menu(self.getFocusId())
            return
        if action_id in (
            xbmcgui.ACTION_PREVIOUS_MENU,
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_STOP,
        ):
            self._result = {'action': 'close'}
            self.close()

    def onClick(self, control_id):
        if control_id in (CTRL_NAV, CTRL_CONTINUE, CTRL_WATCHLIST):
            self._select_item(control_id)
        elif control_id == CTRL_SETTINGS:
            self._result = {'action': 'settings'}
            self.close()
        elif control_id == CTRL_CLOSE:
            self._result = {'action': 'close'}
            self.close()

    def get_result(self):
        return self._result

    def get_selected_mode(self):
        result = self._result or {}
        return result.get('mode') if result.get('action') == 'mode' else None


def show_home():
    win = HomeWindow(WINDOW_XML, _addon_path, 'Default', '720p')
    win.doModal()
    result = win.get_result()
    del win
    return result
