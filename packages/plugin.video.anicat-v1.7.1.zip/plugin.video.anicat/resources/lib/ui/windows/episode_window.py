# -*- coding: utf-8 -*-
"""
AniCat EpisodeWindow — llistat d'episodis amb thumb i barra de progrés.
"""

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()
_addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))

WINDOW_XML = 'anicat_episodes.xml'

CTRL_LIST       = 50
CTRL_TITLE      = 10
CTRL_SUBTITLE   = 11
CTRL_CLOSE      = 9

# Amplada total de la barra de progrés (px, ha de coincidir amb XML width=1160)
_BAR_WIDTH = 1160


class EpisodeWindow(xbmcgui.WindowXML):
    """
    Finestra de llista d'episodis.

    Args:
        episodes:     llista de dicts:
                        id, name, episode_number, season_number,
                        thumb, fanart, resume_time, total_time, drive_id
        series_title: nom de la sèrie (capçalera)
        subtitle:     temporada / versió activa
    """

    def __init__(self, *args, **kwargs):
        self._episodes     = kwargs.pop('episodes', [])
        self._series_title = kwargs.pop('series_title', 'Episodis')
        self._subtitle     = kwargs.pop('subtitle', '')
        self._result       = None
        super(EpisodeWindow, self).__init__(*args, **kwargs)

    def onInit(self):
        try:
            self.getControl(CTRL_TITLE).setLabel(self._series_title)
            self.getControl(CTRL_SUBTITLE).setLabel(self._subtitle)
        except Exception:
            pass
        self._populate_list()
        self.setFocusId(CTRL_LIST)

    def _populate_list(self):
        lst = self.getControl(CTRL_LIST)
        lst.reset()
        for ep in self._episodes:
            ep_num  = ep.get('episode_number', 0)
            sn_num  = ep.get('season_number', 0)
            resume  = ep.get('resume_time', 0) or 0
            total   = ep.get('total_time', 0) or 0
            pct     = int(resume / total * 100) if total > 0 else 0
            px      = int(_BAR_WIDTH * pct / 100) if pct > 0 else 0

            if ep_num > 0 and sn_num > 0:
                ep_label = f'S{sn_num:02d}E{ep_num:02d}'
            elif ep_num > 0:
                ep_label = f'Ep. {ep_num:02d}'
            else:
                ep_label = ''

            li = xbmcgui.ListItem(ep.get('name', ''))
            li.setArt({
                'thumb':  ep.get('thumb', ''),
                'fanart': ep.get('fanart', ''),
            })
            li.setProperty('EpLabel',     ep_label)
            li.setProperty('HasProgress', '1' if pct > 2 else '')
            li.setProperty('ProgressPct', f'{pct}%' if pct > 0 else '')
            li.setProperty('ProgressPx',  str(px))
            li.setProperty('Watched',     '1' if ep.get('watched') else '')
            li.setProperty('ItemId',      ep.get('id', ''))
            li.setProperty('DriveId',     ep.get('drive_id', ''))
            lst.addItem(li)

    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK,
                         xbmcgui.ACTION_STOP):
            self._result = None
            self.close()

    def onClick(self, control_id):
        if control_id == CTRL_LIST:
            idx = self.getControl(CTRL_LIST).getSelectedPosition()
            if 0 <= idx < len(self._episodes):
                self._result = self._episodes[idx]
                self.close()
        elif control_id == CTRL_CLOSE:
            self._result = None
            self.close()

    def get_result(self):
        return self._result


def show_episodes(episodes, series_title='Episodis', subtitle=''):
    """
    Mostra la EpisodeWindow i retorna l'episodi seleccionat o None.
    """
    win = EpisodeWindow(
        WINDOW_XML, _addon_path, 'Default', '720p',
        episodes=episodes, series_title=series_title, subtitle=subtitle,
    )
    win.doModal()
    result = win.get_result()
    del win
    return result
