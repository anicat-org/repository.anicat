"""Google desktop OAuth and locally owned tokens; no token calls to Ani.cat."""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import tempfile
import time
from contextlib import closing
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlencode, urlsplit
from urllib.request import Request, build_opener

SCOPE = 'https://www.googleapis.com/auth/drive.readonly'


def _aes():
    from Cryptodome.Cipher import AES
    return AES


def seal(key, value, context):
    cipher = _aes().new(key, _aes().MODE_GCM)
    cipher.update(context.encode())
    ciphertext, tag = cipher.encrypt_and_digest(json.dumps(value).encode())
    return base64.b64encode(cipher.nonce + tag + ciphertext).decode()


def unseal(key, value, context):
    raw = base64.b64decode(value, validate=True)
    if len(raw) < 33:
        raise ValueError('Invalid encrypted data')
    cipher = _aes().new(key, _aes().MODE_GCM, nonce=raw[:16])
    cipher.update(context.encode())
    return json.loads(cipher.decrypt_and_verify(raw[32:], raw[16:32]))


def profile():
    import xbmcaddon
    import xbmcvfs
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


def save(tokens):
    validate(tokens)
    os.makedirs(profile(), exist_ok=True)
    with closing(sqlite3.connect(os.path.join(profile(), 'drive-local.lock'), timeout=10)) as lease:
        lease.execute('BEGIN IMMEDIATE')
        _save(tokens)


def _save(tokens):
    key_path = os.path.join(profile(), 'drive-local.key')
    try:
        with open(key_path, 'rb') as stream:
            key = stream.read()
    except FileNotFoundError:
        key = secrets.token_bytes(32)
        _write(key_path, key)
    _write(os.path.join(profile(), 'drive-local.enc'), seal(key, tokens, 'anicat-drive-v1').encode())


def load():
    try:
        with open(os.path.join(profile(), 'drive-local.key'), 'rb') as stream:
            key = stream.read()
        with open(os.path.join(profile(), 'drive-local.enc'), 'r') as stream:
            result = unseal(key, stream.read(), 'anicat-drive-v1')
        validate(result)
        return result
    except FileNotFoundError:
        return None


def validate(tokens):
    if not isinstance(tokens, dict):
        raise ValueError('Invalid Google authorization')
    if set(tokens) - {'client_id', 'client_secret', 'refresh_token', 'access_token', 'expires_at'}:
        raise ValueError('Unexpected authorization fields')
    for field in ('client_id', 'refresh_token', 'access_token'):
        if not isinstance(tokens.get(field), str) or not 1 <= len(tokens[field]) <= 8192:
            raise ValueError('Incomplete Google authorization')
    if not re.fullmatch(r'[A-Za-z0-9._-]+\.apps\.googleusercontent\.com', tokens['client_id']):
        raise ValueError('Invalid desktop client')
    if not isinstance(tokens.get('client_secret', ''), str) or len(tokens.get('client_secret', '')) > 512:
        raise ValueError('Invalid desktop client')
    if type(tokens.get('expires_at')) not in (int, float) or not 0 < tokens['expires_at'] < 9999999999:
        raise ValueError('Invalid expiry')


def google(url, data=None, token=None):
    from resources.lib.core.pairing import _NoRedirect
    headers = {'Accept': 'application/json', 'User-Agent': 'AniCAT-Kodi-Local/1'}
    if token:
        headers['Authorization'] = 'Bearer ' + token
    body = urlencode(data).encode() if data is not None else None
    if body is not None:
        headers['Content-Type'] = 'application/x-www-form-urlencoded'
    with build_opener(_NoRedirect()).open(Request(url, data=body, headers=headers), timeout=15) as response:
        raw = response.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise ValueError('Google response too large')
        return json.loads(raw)


class DesktopAuthorization:
    def __init__(self, client_id, client_secret=''):
        if not re.fullmatch(r'[A-Za-z0-9._-]+\.apps\.googleusercontent\.com', client_id):
            raise ValueError('Configura un client OAuth de tipus escriptori.')
        self.client_id, self.client_secret = client_id, client_secret
        self.state = secrets.token_urlsafe(32)
        self.verifier = secrets.token_urlsafe(48)
        self.code = None
        self.error = False
        owner = self

        class Callback(BaseHTTPRequestHandler):
            def setup(self):
                super().setup()
                self.connection.settimeout(2)

            def log_message(self, *args):
                pass  # Authorization codes must never be logged.

            def do_GET(self):
                parsed = urlsplit(self.path)
                query = parse_qs(parsed.query)
                valid = (self.headers.get('Host') == '127.0.0.1:' + str(owner.server.server_port)
                         and parsed.path == '/callback' and len(query.get('state', [])) == 1
                         and hmac.compare_digest(query['state'][0], owner.state)
                         and owner.code is None and not owner.error)
                self.send_response(200 if valid else 400)
                self.send_header('Content-Type', 'text/plain; charset=utf-8')
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                if valid:
                    owner.code = query.get('code', [None])[0]
                    owner.error = not owner.code
                self.wfile.write(b'Torna a Kodi.' if valid else b'Invalid authorization.')

        self.server = HTTPServer(('127.0.0.1', 0), Callback)
        self.server.timeout = 0.25
        self.redirect = 'http://127.0.0.1:%d/callback' % self.server.server_port
        challenge = base64.urlsafe_b64encode(hashlib.sha256(self.verifier.encode()).digest()).decode().rstrip('=')
        self.url = 'https://accounts.google.com/o/oauth2/v2/auth?' + urlencode({
            'client_id': client_id, 'redirect_uri': self.redirect, 'response_type': 'code',
            'scope': SCOPE, 'access_type': 'offline', 'prompt': 'consent',
            'state': self.state, 'code_challenge': challenge, 'code_challenge_method': 'S256'})

    def poll(self):
        self.server.handle_request()
        if self.error:
            raise ValueError('Autorització cancel·lada a Google.')
        if not self.code:
            return None
        result = google('https://oauth2.googleapis.com/token', {
            'client_id': self.client_id, 'client_secret': self.client_secret,
            'code': self.code, 'code_verifier': self.verifier,
            'redirect_uri': self.redirect, 'grant_type': 'authorization_code'})
        if SCOPE not in result.get('scope', '').split():
            raise ValueError('Google no ha autoritzat la lectura de Drive.')
        tokens = dict(client_id=self.client_id, client_secret=self.client_secret,
                      refresh_token=result.get('refresh_token'), access_token=result.get('access_token'),
                      expires_at=time.time() + int(result['expires_in']))
        validate(tokens)
        return tokens

    def close(self):
        self.server.server_close()


def refresh(tokens):
    result = google('https://oauth2.googleapis.com/token', {
        'client_id': tokens['client_id'], 'client_secret': tokens.get('client_secret', ''),
        'refresh_token': tokens['refresh_token'], 'grant_type': 'refresh_token'})
    updated = dict(tokens, access_token=result['access_token'], expires_at=time.time() + int(result['expires_in']))
    if result.get('refresh_token'):
        updated['refresh_token'] = result['refresh_token']
    validate(updated)
    return updated


def install(tokens):
    """Import only a short-lived access token into Cloud Drive Common."""
    from resources.lib.core import pairing
    import xbmcaddon
    validate(tokens)
    if tokens['expires_at'] - time.time() < 1200:
        tokens = refresh(tokens)
    user = google('https://www.googleapis.com/drive/v3/about?fields=user(permissionId,displayName)', token=tokens['access_token'])['user']
    identity = user['permissionId']
    drives = [{'id': identity, 'name': '', 'type': ''}]
    page = ''
    for _ in range(20):
        result = google('https://www.googleapis.com/drive/v3/drives?' + urlencode({'pageSize': 100, 'pageToken': page}), token=tokens['access_token'])
        drives.extend({'id': d['id'], 'name': d['name'], 'type': 'drive#drive'} for d in result.get('drives', []))
        page = result.get('nextPageToken', '')
        if not page:
            break
    if page:
        raise ValueError('Massa pàgines de Drive; no s’ha importat una llista incompleta.')
    payload = {'account': {'id': identity, 'name': user.get('displayName') or 'Drive local'}, 'drives': drives,
               'access_token': tokens['access_token'], 'expires_in': int(tokens['expires_at'] - time.time())}
    account = pairing._drive_account({'host': 'local', 'device_id': 'local'}, payload)
    account['anicat_local'] = True
    addon = xbmcaddon.Addon()
    required = {addon.getSetting(kind + '_drive_id') for kind in ('movies', 'series') if addon.getSetting(kind + '_folder_id')}
    pairing._import_account(pairing._account_manager(), account, required - {''})
    save(tokens)


def ensure_access(drive_id=None):
    from resources.lib.core import pairing
    manager = pairing._account_manager()
    account = manager.get_accounts().get(pairing.ACCOUNT_ID)
    if not account or account.get('anicat_local') is not True:
        return False
    if drive_id and drive_id not in {d['id'] for d in account['drives']}:
        return True
    tokens = load()
    if not tokens:
        raise ValueError('Torna a connectar Google Drive en aquest Kodi.')
    if tokens['expires_at'] - time.time() < 1200:
        tokens = refresh(tokens)
        save(tokens)
    account['access_tokens'] = {'access_token': tokens['access_token'], 'refresh_token': '',
                                'expires_in': int(tokens['expires_at'] - time.time()), 'date': time.time()}
    pairing._save_account(manager, account)
    return True
